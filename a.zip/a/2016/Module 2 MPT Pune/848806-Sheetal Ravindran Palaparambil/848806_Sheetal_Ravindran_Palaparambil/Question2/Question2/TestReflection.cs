﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Question2
{
    /// <summary>
    /// Employee :848806
    /// Employee Name :Sheetal Ravindran Palaparambil
    /// Description :The class that prints the metadata about the DoWork method
    /// Date of creation :19/09/2016
    /// </summary>
    class TestReflection
    {
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("Question2Library.dll");
            Type squareType = myAssembly.GetType("Question2Library.Test");

            MethodInfo sqMethod = squareType.GetMethod("DoWork");

            Console.WriteLine("Name :" + sqMethod.Name);                             //Method Name
            Console.WriteLine("Return Type :" + sqMethod.ReturnType);                //Return Type
            Console.WriteLine("Is Static :" + sqMethod.IsStatic);                    //Method is static or not
            Console.WriteLine("Get Parameters :" + sqMethod.GetParameters());       //Get Parameters
            Console.WriteLine("Member Type :" + sqMethod.MemberType+ "\n");         //Member Type

            Console.WriteLine("Enter the number:");
            int val = Convert.ToInt32(Console.ReadLine());
            object calcObj = myAssembly.CreateInstance("Question2Library.Test");
            MethodInfo squareMethod = squareType.GetMethod("DoWork");
            int square = (int)squareMethod.Invoke(calcObj, new object[] {val});
            Console.WriteLine("Square of a number :" + square);

            Console.ReadKey();

        }
    }
}
