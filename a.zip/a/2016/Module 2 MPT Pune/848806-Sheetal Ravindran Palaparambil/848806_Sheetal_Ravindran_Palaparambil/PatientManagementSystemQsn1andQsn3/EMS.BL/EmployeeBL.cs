﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using EMS.Entity;           //Reference of Patient Entity
using EMS.Exception;        //Reference of Patient Exception
using EMS.DAL;              //Reference of Patient Data Access Layer 

namespace EMS.BL
{
    /// <summary>
    /// Employee ID :848806
    /// Employee Name :Sheetal Ravindran Palaparambil
    /// Description : This is a Business Layer for Patient  
    /// Date of creation : 19/09/2016
    /// </summary>
    public class EmployeeBL
    {
         //Function to validate the patient data
        public static bool ValidatePatient(Patient pat)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();
            
            try
            {
                //Validating Patient ID should be 3 digits
                if (pat.PatientID > 999)
                {
                    msg.Append("Patient ID should be 3 digits\n");
                    validPatient = false;
                }

                //Validating Patient Name should have alphabets and spaces only and it should start with capital letter
                if(!Regex.IsMatch(pat.PatientName,"[A-Z][a-z ]+"))
                {
                    msg.Append("Patient Name should have alphabets and spaces only and it should start with capital letter\n");
                    validPatient = false;     
                }

                //Validating Phone number should have 10 digits and it should start with 7 or 8 or 9
                if (!Regex.IsMatch(pat.PhoneNo, "[123456789][0-9]{9}"))
                {
                    msg.Append("Phone no should have 10 digits and it should not start with 0\n");
                    validPatient = false;
                }

                //Validating Age should be within 18 and 60 
                if (pat.Age <0 ||pat.Age >100)
                {
                    msg.Append("Patient Age cannot be negative and greater than 100");
                    validPatient = false;
                }

                if (validPatient == false)
                    throw new PatientException(msg.ToString());
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }
        //Validating before adding patients
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPatient))
                {

                    newPatient.PatientID = ++Patient.PatID;
                    patientAdded = PatientDAL.AddPatient(newPatient);

                }

                else
                {
                    throw new PatientException("Please provide valid data");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Validating before searching patient details
        public static Patient SearchPatient(int patID)
        {
            Patient patientSearched = null;

            try
            {
                patientSearched = PatientDAL.SearchPatient(patID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        public static List<Patient> DisplayAllPatient()
        {
            List<Patient> patientList = PatientDAL.DisplayAllPatient();
            return patientList;
        }
        //Function for seralize patient
        public static bool SerializePatient()
        {
            bool patSerialized = false;
            try
            {
                patSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return patSerialized;
        }
        public static List<Patient> DeserializePatient()
        {
            List<Patient> patientList = null;

            try
            {
                patientList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientList;
        }
    }
}
