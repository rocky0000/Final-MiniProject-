﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;               //Reference for Patient Entity
using EMS.Exception;            //Reference for Patient Exception
using EMS.BL;                   //Reference for Patient Business Layer


namespace EMS.PL
{
    /// <summary>
    /// Employee ID :848806
    /// Employee Name :Sheetal Ravindran Palaparambil
    /// Description :This is the description for Patient Physical Layer
    /// Date of Creation :19/09/2016
    /// </summary>
    class PatientPL
    {
        //Add Patient Method
        public static void AddPatient()
        {
            Patient newPatient = new Patient();

            try
            {
                newPatient.PatientID = 0;
     
                Console.Write("Enter Patient Name :");
                newPatient.PatientName = Console.ReadLine();
                Console.Write("Enter Phone no :");
                newPatient.PhoneNo = Console.ReadLine();
                Console.Write("Enter Patient Age :");
                newPatient.Age = Convert.ToInt32(Console.ReadLine());
              
                bool patientAdded = EmployeeBL.AddPatient(newPatient);
                if (patientAdded)
                    Console.WriteLine("Patient Details added successfully");
                else
                    throw new PatientException("Employee not Added");

            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to search the patient using patient id
        public static void SearchPatient()
        {
            try
            {
                int patID;
                Console.WriteLine("Enter Patient Id for patient which you would like to search(ID starts with 100)");
                patID = Convert.ToInt32(Console.ReadLine());

                Patient pat = EmployeeBL.SearchPatient(patID);

                if (pat != null)
                {
                    Console.WriteLine("Patient Id :" + pat.PatientID);
                    Console.WriteLine("Patient Name :" + pat.PatientName);
                    Console.WriteLine("Patient Phone no :" + pat.PhoneNo);
                    Console.WriteLine("Patient Age :" + pat.Age);
                    
                }
                else
                    throw new PatientException("Patient not found with patient id " + patID);
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DisplayAllPatient()
        {
            try
            {
                List<Patient> patientList = EmployeeBL.DisplayAllPatient();
                if (patientList.Count > 0)
                {
                    Console.WriteLine("************************************************************");
                    Console.WriteLine("Patient ID\t Patient Name\t Phone no\t Age\t City\t");
                    Console.WriteLine("************************************************************");
                    Console.WriteLine(); 

                    foreach (Patient pat in patientList)
                    {
                        Console.WriteLine(pat.PatientID+ "\t\t" + pat.PatientName + "\t\t" + pat.PhoneNo + "\t\t" + pat.Age);
                    }

                }
                else
                    throw new PatientException("");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }


        public static void SerializePatient()
        {

            try
            {
                bool patSerialized = EmployeeBL.SerializePatient();
                if (patSerialized)
                    Console.WriteLine("Patient data is serialized");
                else
                    throw new PatientException("Data is not Serialized");

            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        public static void DeserializePatient()
        {
            try
            {
                List<Patient> patientList = EmployeeBL.DeserializePatient();
                if (patientList != null)
                {
                    Console.WriteLine("******************************************************************");
                    Console.WriteLine("Patient ID\t Patient Name\t Phone no\t Age\t City\t");
                    Console.WriteLine("******************************************************************");

                    foreach (Patient pat in patientList)
                    {
                        Console.WriteLine(pat.PatientID + "\t\t" + pat.PatientName + "\t\t" + pat.PhoneNo + "\t\t" + pat.Age );
                    }
                }
                else
                    throw new PatientException("There is no data");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Function to print details 
        public static void PrintMenu()
        {
            Console.WriteLine("*****************************************************************");
            Console.WriteLine("1.Add Patient");
            Console.WriteLine("2.Search Patient");
            Console.WriteLine("3.Serialize All Search");
            Console.WriteLine("4.Deserialize All Search");
            Console.WriteLine("5.Exit");
            Console.WriteLine("*****************************************************************");
        }
        static void Main(string[] args)
        {
            int choice = 0;
            try
            {
                do
                {
                  PrintMenu();
                  Console.WriteLine("\nEnter your choice :");
                  choice = Convert.ToInt32(Console.ReadLine());

                  switch (choice)
                  {
                      case 1: AddPatient();
                          DisplayAllPatient();             
                          break;
                      case 2: SearchPatient();
                          break;
                      case 3: SerializePatient();
                          break;
                      case 4:DeserializePatient();
                          break;
                      case 5: Environment.Exit(0);
                          break;
                      default: Console.WriteLine("Please select provied option");
                          break;
                  }

                } while (choice != 5);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
