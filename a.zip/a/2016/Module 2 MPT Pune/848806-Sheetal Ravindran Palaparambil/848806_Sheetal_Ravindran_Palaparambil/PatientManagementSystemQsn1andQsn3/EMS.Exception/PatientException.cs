﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Exception
{
    /// <summary>
    /// Employee ID :848806
    /// Employee Name :Sheetal Ravindran Palaparambil
    /// Description :This is the Exception Class for Patient
    /// Date of Creation :
    /// </summary>
    public class PatientException:ApplicationException
    {
         public PatientException()
            : base()
        { }
        public PatientException(string msg)
            : base(msg)
        { }
    }
}
