﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;           //Reference to Patient Entity
using EMS.Exception;        //Reference to Patient Exception
using System.Runtime.Serialization.Formatters.Binary; //Reference to Patient Serialization
using System.IO;           

namespace EMS.DAL
{
    /// <summary>
    /// Employee ID :848806
    /// Employee Name :Sheetal Ravindran Palaparambil
    /// Description :This is Data Access Layer for Patient
    /// Date of Creation :19/09/2016
    /// </summary>
    public class PatientDAL
    {
        //Function to add new patient to the list of patients
        static List<Patient> patientList = new List<Patient>();

        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                //Adding Patient details to patient list
                patientList.Add(newPatient);
                patientAdded = true;
            }

            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function for searching patient details from list of Patients
        public static Patient SearchPatient(int patientID)
        {
            Patient patientSearched = null;
            try
            {
                //searching Patient details
                patientSearched = patientList.Find(patient => patient.PatientID == patientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        public static List<Patient> DisplayAllPatient()
        {
            return patientList;
        }


        public static bool SerializePatient()
        {
            bool patientSerialized = false;
            try
            {
                if (patientList.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binFormat = new BinaryFormatter();
                    binFormat.Serialize(fs, patientList);
                    patientSerialized = true;
                    fs.Flush();
                    fs.Close();

                }
                else
                    throw new PatientException("No Patient data so cannot be seralized");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPatient = null;

            try
            {

                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormat = new BinaryFormatter();
                desPatient = (List<Patient>)binFormat.Deserialize(fs);
                fs.Flush();
                fs.Close();

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return desPatient;
        }
        
    }
}
