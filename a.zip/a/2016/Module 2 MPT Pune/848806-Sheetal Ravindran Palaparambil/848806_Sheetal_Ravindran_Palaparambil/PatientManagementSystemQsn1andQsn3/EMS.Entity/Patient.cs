﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Employee ID :848806
    /// Employee Name :Sheetal Ravindran Palaparambil
    /// Description :This is Entity class for Patient
    /// Date of Creation :19/09/2016
    /// </summary>
    
    [Serializable]
    public class Patient
    {
        public static int PatID = 99;

        //Property for Get or Set Patient ID
        public int PatientID { get; set; }

        //Property for Get or Set Patient Name
        public string PatientName { get; set; }

        //Property for Get or Set Patient Phone Number
        public string PhoneNo { get; set; }

        //Property for Get or Set Patient Age
        public int Age { get; set; }

    }
}
