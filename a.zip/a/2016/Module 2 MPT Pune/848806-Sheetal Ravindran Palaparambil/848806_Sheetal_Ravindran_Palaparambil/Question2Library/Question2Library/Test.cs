﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2Library
{
    /// <summary>
    /// Employee ID :848806
    /// Employee Name :Sheetal Ravindran Palaparambil
    /// Description :The library that contains method which calculates square of a number 
    /// Date of creation :19/09/2016
    /// </summary>
    public class Test
    {
        public int DoWork(int number)
        {
            int result = number * number;
            return result;
        }
    }
}
