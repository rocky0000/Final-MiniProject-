﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoWorkMethodLibraryQ2
{
    /// <summary>
    /// Employee ID      :94275
    /// Employee Name    :Rishikesh Naresh Vaghela
    /// Description      :This is the Library for calculating the
    ///                   Square of a number
    /// Date Of Creation :19/09/2016
    /// </summary>
    //Creation of Class Test
    public class Test
    {
        //Creating Method DoWork
        public int DoWork(int parameter)
        {
            int square;
            square = parameter * parameter;
            return square; //returns calculated value to DoWork Method
        }
    }
}
