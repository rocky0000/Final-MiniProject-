﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;      //namespace used for Reflection
using DoWorkMethodLibraryQ2;

namespace DoWorkMethodQ2
{
    /// <summary>
    /// Employee ID      :94275
    /// Employee Name    :Rishikesh Naresh Vaghela
    /// Description      :This is the Console application for calculating 
    ///                   the Square of a number using Reflections
    /// Date Of Creation :19/09/2016
    /// </summary>
    public class Program
    {
        static void Main(string[] args)
        {
            //Making Use of following Library
            Assembly myAssembly = Assembly.LoadFrom("DoWorkMethodLibraryQ2.dll");

            //Using the Class Test from the Library used
            Type paraType = myAssembly.GetType("DoWorkMethodLibraryQ2.Test");

            //MethodInfo object Created
            MethodInfo[] paraMethod = paraType.GetMethods();

            int i = 0;
            //For Printing Metadata
            foreach (MethodInfo m in paraMethod)
            {
                i++;
                //Prints Method Name
                Console.WriteLine("Method Name : " + m.Name);
                //Prints Return Type
                Console.WriteLine("Return Type : " + m.ReturnType);
                //Prints if the Method is Static
                Console.WriteLine("Is Static : " + m.IsStatic);
                if(i==1)
                {
                  //Prints Parameter Name
                  Console.WriteLine("Parameter Names: " + m.GetParameters().ElementAt(0).Name);
                  //Prints Parameter Types
                  Console.WriteLine("Parameter Type : " + m.GetParameters().ElementAt(0).ParameterType);              
                  Console.WriteLine();
                }
            }

            //Creating An Object
            object calcObj = myAssembly.CreateInstance("DoWorkMethodLibraryQ2.Test");

            //Hardcoded Value Added to Square a Number:
            MethodInfo paraMethods = paraType.GetMethod("DoWork");
            int answer = (int)paraMethods.Invoke(calcObj, new object []{ 4 });
            Console.WriteLine("\nSquare of the Number: " + answer);

            //User Input Taken For Squaring a Number:
            Console.WriteLine("\nEnter a Number: ");
            int x = Convert.ToInt32(Console.ReadLine());

            MethodInfo paraMethod1 = paraType.GetMethod("DoWork");
            int Result = (int)paraMethod1.Invoke(calcObj, new object[] { x });
            Console.WriteLine("\nSquare of the Number: " + Result);
        }
    }
}

