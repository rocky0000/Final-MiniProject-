﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDC.Entity;      //Reference of Entity Taken
using PDC.Exception;   //Reference of Exception Taken
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;   //namespace used for Binary serialization

namespace PDC.DAL
{
    ///<summary>
    /// Employee ID      :94275 
    /// Employee Name    :Rishikesh Naresh Vaghela
    /// Description      :This is the Data Access Layer for Patient Details 
    /// Date of Creation :19/09/2016   
    ///</summary>
    public class PatientDAL
    {
        //Create List OF Employees
        static List<Patient> patientList = new List<Patient>();

        //Function to add new Patient to the List of Patient
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;

            //to check for all the exception
            try
            {
                //Adding Patient
                patientList.Add(newPatient);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientAdded;
        }

        //Function for searching for an Patient from the list
        public static Patient SearchPatient(string patname)
        {
            Patient patientSearched = null;

            //to check for all exception
            try
            {
                //Searching Patient
                patientSearched = patientList.Find(pat => pat.patientName == patname);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //Function to Serialise Patient
        public static bool SerializePatient()
        {
            bool patientSerialized = false;

            //to check for all exception
            try
            {
                if (patientList.Count > 0)
                {
                    //serailizing patient
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(fs, patientList);
                    patientSerialized = true;
                    fs.Close();
                }
                else
                    throw new PatientException("No Patient Data,so Cannot serialise");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }

        //Function to Deserialize Patient
        public static List<Patient> DeserializedPatient()
        {
            List<Patient> despat = null;

            //to check for all exception
            try
            {
                //deserializing patient
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                despat = (List<Patient>)bin.Deserialize(fs);
                fs.Close();               
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return despat;
        }

    }
}
