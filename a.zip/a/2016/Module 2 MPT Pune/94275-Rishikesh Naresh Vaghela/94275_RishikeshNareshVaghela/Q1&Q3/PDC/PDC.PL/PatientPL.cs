﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDC.Entity;     //Reference for Entity Taken 
using PDC.Exception;  //Reference for Exception Taken 
using PDC.BL;         //Reference for BL Taken 

namespace PDC.PL
{
    /// <summary>
    /// Employee ID      :94275 
    /// Employee Name    :Rishikesh Naresh Vaghela
    /// Description      :This is the Presentation Layer for Patient Details 
    /// Date of Creation :19/09/2016
    /// </summary>
    class PatientPL
    {
        static int PatientID = 100;  //For Auto Generation of Patient ID

        //Function to Add an Patient
        public static void AddPatient()
        {
            Patient newpatient = new Patient();

            //Adding Patient
            try
            {
                newpatient.patientId = PatientID++;  //Auto Increments Patient ID
 
                //to get patient name
                Console.Write("Enter Patient Name: ");
                newpatient.patientName = Console.ReadLine();
                //to get patient phone number
                Console.Write("Enter Phone Number: ");
                newpatient.phoneNumber = Console.ReadLine();
                //to get patient age
                Console.Write("Enter Age of the Patient: ");
                newpatient.age = Convert.ToInt32(Console.ReadLine());


                bool patientAdded = PatientBL.AddPatient(newpatient);

                if (patientAdded)
                    Console.WriteLine("Patient Added Successfully");
                else
                    throw new PatientException("Patient Not Added");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to search for an Patient
        public static void SearchPatient()
        {
            //to check for all exception
            try
            {
                string patname;
                Console.WriteLine("Enter the Patient Name whom you would like to Search: ");
                patname = Console.ReadLine();

                Patient pat = PatientBL.SearchPatient(patname);

                if (pat != null)
                {
                    Console.WriteLine("Patient ID: " + pat.patientId);
                    Console.WriteLine("Patient Name: " + pat.patientName);
                    Console.WriteLine("Phone Number: " + pat.phoneNumber);
                    Console.WriteLine("Patient Age: " + pat.age);
                }
                else
                    throw new PatientException("Patient With Patient name" + patname + "Not Found");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to Serailze Patient
        public static void SerializePatient()
        {
            //to check for all exception
            try
            {
                bool patSerialised = PatientBL.SerializedPatient();
                if (patSerialised)
                    Console.WriteLine("Patient Data is Serilaised");
                else
                    throw new PatientException("Patient Data is Not Serilasied");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to Deseralize Patient
        public static void DeserialisePatient()
        {
            //to check for all exception
            try
            {
                List<Patient> patientList = PatientBL.DeserializedPatient();
                //if patient list is present
                if (patientList != null)
                {
                    Console.WriteLine("*******************************************************************");
                    Console.WriteLine("Patient ID \tPatient Name \t Phone Number \t Age");
                    Console.WriteLine("*******************************************************************");

                    //getting each patient data
                    foreach (Patient pat in patientList)
                    {
                        Console.WriteLine( + pat.patientId + "\t\t" + pat.patientName + "\t" + pat.phoneNumber + "\t" + pat.age);
                    }
                }
                //throw an exception
                else
                    throw new PatientException("There is no Data");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //function for menu
        public static void PrintMenu()
        {
            //Menu           
            Console.WriteLine("\n***************************");
            Console.WriteLine("1. Add Patient");
            Console.WriteLine("2. Search Patient");
            Console.WriteLine("3. Serialize Patient");
            Console.WriteLine("4. Deserialize Patient");
            Console.WriteLine("5. Exit");
            Console.WriteLine("***************************");
        }


        static void Main(string[] args)
        {
            {
                Console.WriteLine("\t\t***WELCOME TO PATIENT MANAGEMENT SYSTEM***");
                int choice = 0;

                try
                {
                    do
                    {
                        PrintMenu();
                        Console.Write("\nEnter Your Choice: ");
                        choice = Convert.ToInt32(Console.ReadLine());

                        switch (choice)
                        {
                            case 1: AddPatient();
                                break;
                            case 2: SearchPatient();
                                break;
                            case 3: SerializePatient();
                                break;
                            case 4: DeserialisePatient();
                                break;
                            case 5: Environment.Exit(0);
                                break;
                            default: Console.WriteLine("Please provide valid Choice");
                                break;
                        }
                    }
                    while (choice != 5);
                }
                catch (SystemException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                Console.ReadKey();
            }
        }
    }
}
        