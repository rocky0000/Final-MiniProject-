﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDC.Entity
{
    /// <summary>
    /// Employee ID      :94275 
    /// Employee Name    :Rishikesh Naresh Vaghela
    /// Description      :This is the Entity for Patient Details
    /// Date of Creation :19/09/2016
    /// </summary>

    [Serializable]
    public class Patient
    {
        //Property for Get or Set for Patient ID
        public int patientId { get; set; }

        //Property for Get or Set for Patient Name
        public string patientName { get; set; }

        //Property for Get or Set for Patient Age
        public int age { get; set; }

        //Property for Get or Set for Patient Phone Number
        public string phoneNumber { get; set; }
    }

}
