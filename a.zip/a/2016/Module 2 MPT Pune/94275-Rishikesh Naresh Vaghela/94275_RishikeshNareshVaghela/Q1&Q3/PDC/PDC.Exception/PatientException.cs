﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDC.Exception
{
    /// <summary>
    /// Employee ID      :94275 
    /// Employee Name    :Rishikesh Naresh Vaghela
    /// Description      :This is the Exception for Patient Details 
    /// Date of Creation :19/09/2016
    /// </summary>
    public class PatientException:ApplicationException
    {
        //Default Constructor
        public PatientException()
            :base() //base is used to inherit properties from ApplicationException
        {}

        //Parameterized Constructor
        public PatientException(string msg)
            : base(msg)
        { }
    }
}
