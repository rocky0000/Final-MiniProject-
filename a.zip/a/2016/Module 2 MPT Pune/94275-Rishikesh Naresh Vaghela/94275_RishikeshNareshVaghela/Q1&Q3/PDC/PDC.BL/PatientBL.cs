﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDC.Entity;     //Reference of Entity Taken
using PDC.Exception;  //Reference of Exception Taken
using PDC.DAL;        //Reference of DAL Taken
using System.Text.RegularExpressions;    //used this namespace to validate Patient Name

namespace PDC.BL
{
    /// <summary>
    /// Employee ID      :94275 
    /// Employee Name    :Rishikesh Naresh Vaghela
    /// Description      :This is the Business Layer for Patient Deatils  
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientBL
    {
         //Function to validate the Patient details
        public static bool ValidatePatient(Patient pat)
        {
            bool validPatient = true;

            //To Display user defined Exception messages
            StringBuilder msg = new StringBuilder();

            //to check for all exception
            try 
            {
                //Validating Patient name
                if (!Regex.IsMatch(pat.patientName, "[A-Z][a-z ]+"))
                {
                    msg.Append("Patiente Name should have alphabets and spaces only and it should start with Capital Letter\n");
                    validPatient = false;
                }

                //Validating  Patient phone number
                if (!Regex.IsMatch(pat.phoneNumber, "[789][0-9]{9}") || pat.phoneNumber.Length > 10)
                {
                    msg.Append("Phone number should have 10 digits and it should start with 7 or 8 or 9\n");
                    validPatient = false;
                }

                //Validating Patient Age
                if (pat.age < 0 || pat.age > 100)
                {
                    msg.Append("Patient Age should be within 0 to 100\n");
                    validPatient = false;
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }

        //Function to Add an Patient
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;

            //to check for all exception
            try
            {
                //validating new patient details
                if (ValidatePatient(newPatient))
                {
                    patientAdded = PatientDAL.AddPatient(newPatient);
                }
                else
                {
                    throw new PatientException("Please Provide Valid Data For Patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function to Search for an Patient
        public static Patient SearchPatient(string patname)
        {
            Patient patientSearched = null;

            //to check for all exception
            try
            {
                //Search for an Patient
                patientSearched = PatientDAL.SearchPatient(patname);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //function to Serialise Patient
        public static bool SerializedPatient()
        {
            bool patSerialised = false;

            //to check for all exception
            try
            {
                patSerialised = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patSerialised;
        }

        //Function to Deserialize Patient
        public static List<Patient> DeserializedPatient()
        {
            List<Patient> patientList = null;

            //to check for all Exception
            try
            {
                patientList= PatientDAL.DeserializedPatient();
            }
            catch (PatientException ex)
            {
                throw ex;

            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientList;
        }

    }
}
