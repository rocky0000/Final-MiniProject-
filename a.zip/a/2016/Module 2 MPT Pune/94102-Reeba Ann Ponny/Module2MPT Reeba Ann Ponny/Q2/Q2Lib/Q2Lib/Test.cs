﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2Lib
{
    /// <summary>
    /// Employee ID:94102
    /// Employee Name:Reeba Ann Ponny
    /// Description: This is Test class containing DoWork method
    /// Date of creation: 19/9/2016
    /// </summary>
    public class Test
    {
        public int DoWork(int parameter)
        {
            return parameter * parameter;
        }
    }
}
