﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Q2metadata
{
    /// <summary>
    /// Employee ID:94102
    /// Employee Name:Reeba Ann Ponny
    /// Description: This is Program for printing metadata about DoWork method
    /// Date of creation: 19/9/2016
    /// </summary>
    class Program
    {
        
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("Q2Lib.dll");

            Type tstType = myAssembly.GetType("Q2Lib.Test");

            MethodInfo[] tstMethods = tstType.GetMethods();

            //Printing the metadata of DoWork Method
            Console.WriteLine("The metadata of the DoWork method is as shown below:");
            foreach (MethodInfo t in tstMethods)
            {
                Console.WriteLine("\nMethod Name : " +t.Name);
                Console.WriteLine("Return Type : " + t.ReturnType.Name);
                Console.WriteLine("Is Static : "   + t.IsStatic);
                Console.WriteLine("Parameter name:" + t.GetParameters());
                Console.WriteLine("Parameter types:" + t.ReturnParameter);
               
            }
            //Calling DoWork method
            object Obj = myAssembly.CreateInstance("Q2Lib.Test");
            MethodInfo sqr = tstType.GetMethod("DoWork");
            int result = (int)sqr.Invoke(Obj, new object[] { 10 });
            Console.WriteLine("\nSquare =" + result);

            Console.ReadKey();
           
            }


        }
    }

