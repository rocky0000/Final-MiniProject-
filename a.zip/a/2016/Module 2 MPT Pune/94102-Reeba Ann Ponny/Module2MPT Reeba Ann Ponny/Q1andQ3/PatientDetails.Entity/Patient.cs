﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDetails.Entity
{
     /// <summary>
        /// Employee ID:94102
        /// Employee Name:Reeba Ann Ponny
        /// Description: This iS Entity Layer
        /// Date of creation: 19/9/2016
        /// </summary>
    [Serializable]
    public class Patient
    {
        //property for Get or Set Patient ID
        public int PatientID { get; set; }
        //property for Get or Set Patient Name
        public string PatientName { get; set; }
        //property for Get or Set Patient Phone Number
        public string PhoneNo { get; set; }
        //property for Get or Set Patient Age
        public int Age { get; set; }
       
    }
}

    

