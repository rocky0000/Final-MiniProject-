﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientDetails.Entity;//Reference to Patient entity
using PatientDetails.Exception;//Reference to Patient Exception
using PatientDetails.BL;//Reference to Patient Business Layer

namespace PatientDetails.PL
{
    /// <summary>
    ///  Employee ID:94102
    /// Employee Name:Reeba Ann Ponny
    /// Description: This is Presentation Layer for Patient
    /// Date of creation: 19/9/2016
    /// </summary>
    
    class PatientPL
    {
        static int count = 101;
        
        //function to add Patient details in the patient data
        public static void AddPatient()
        {
            Patient newPat = new Patient();
            try
            {  
                newPat.PatientID = count;

                Console.Write("Enter Patient Name:");
                newPat.PatientName = Console.ReadLine();
                Console.Write("enter phone number");
                newPat.PhoneNo = Console.ReadLine();
                Console.Write("enter age");
                newPat.Age = Convert.ToInt32(Console.ReadLine());
                

                count++;

                bool patientAdded = PatientBL.AddPatient(newPat);
                if (patientAdded)
                    Console.WriteLine("Patient details added successfully");
                else
                    throw new PatientException("Patient details not added");


            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Function to search patient details in patients list
        public static void SearchPatient()
        {
            try
            {
                int patID;
                Console.WriteLine("Enter the patient's id to search a patients' details");
                patID = Convert.ToInt32(Console.ReadLine());
                Patient pat = PatientBL.SearchPatient(patID);
                if (pat != null)
                {
                    Console.WriteLine("Patient id:" + pat.PatientID);
                    Console.WriteLine("Patient name:" + pat.PatientName);
                    Console.WriteLine("Patient phone number:" + pat.PhoneNo);
                    Console.WriteLine("Patient age:" + pat.Age);
                }
                   
                else
                    throw new PatientException("Patient not found with Patient id:" + patID);

            }

            catch (PatientException ex)
            {

                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Serialization
        public static void SerializePatient()
        {
            try
            {
                bool patSerialized = PatientBL.SerializePatient();
                if (patSerialized)
                    Console.WriteLine("Patient data is serialized");
                else
                    throw new PatientException("Patient Data is not Serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Deserialization
        public static void DeserializePatient()
        {
            try
            {
                List<Patient> patList = PatientBL.DeserializePatient();

                if (patList != null)
                {
                    Console.WriteLine("**************************************************************************************");
                    Console.WriteLine("Patient ID \t Patient Name \t Phone No \t Age ");
                    Console.WriteLine("**************************************************************************************");
                    foreach (Patient pat in patList)
                    {
                        Console.WriteLine(pat.PatientID + "\t\t" + pat.PatientName + "\t\t" + pat.PhoneNo + "\t" + pat.Age);
                    }
                }
                else
                {
                   
                    throw new PatientException("There is no data");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Function to display the operations which can be performed
        public static void PrintMenu()
        {
            Console.WriteLine("\n************************************");
            Console.WriteLine("1. Add Patient Details");
            Console.WriteLine("2. Search Patient Details");
            Console.WriteLine("3. Serialize Patient Details");
            Console.WriteLine("4. Deserialize Patient Details");
            Console.WriteLine("5. Exit");
            Console.WriteLine("***************************************");
        }

        static void Main(string[] args)
        {
             int choice = 0;

            try
            {
                do
                {
                    PrintMenu();

                    Console.Write("\nEnter Your Choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;
                        case 2: SearchPatient();
                            break;
                        case 3: SerializePatient();
                            break;
                        case 4: DeserializePatient();
                            break;
                        case 5: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("Please provide valid choice");
                            break;
                    }
                } while (choice != 5);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}

        

