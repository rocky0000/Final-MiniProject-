﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using PatientDetails.Entity;//Reference to Patient entity
using PatientDetails.Exception;//Reference to Patient Exception
using PatientDetails.DAL;//Reference to Patient Data Access Layer(DAL)

namespace PatientDetails.BL
{
    /// <summary>
    ///  Employee ID:94102
    /// Employee Name:Reeba Ann Ponny
    /// Description: This is BL Class for Patient
    /// Date of creation: 19/9/2016
    /// </summary>
    public class PatientBL
    {
         //function to validate data
        public static bool ValidatePatient(Patient pat)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();
            
            try
            {
                 //To validate patient's name for alphabets and starting letter capital
                if (!Regex.IsMatch(pat.PatientName, "[A-Z][a-z ]+"))
                {
                    msg.Append("Patient name should contain only alphabets,spaces and it should start with capital letter");
                    validPatient = false;
                }
                //To validate Patient's phone number for 10 digits and first digit should not be zero
                if (!Regex.IsMatch(pat.PhoneNo, "[789][0-9]{9}"))
                {
                    msg.Append("Phone number should contain exactly 10 digits and it Should start with 7 or 8 or 9");
                    validPatient = false;
                }
                //To validate Patient's age which can should not be greater than 100 and should not be negative
                if (pat.Age <0 || pat.Age > 100)
                {
                    msg.Append("Age should be between 0 and 100");
                    validPatient = false;
                }
                if (validPatient == false)
                    throw new PatientException(msg.ToString());

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }
        public static bool AddPatient(Patient newPat)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPat))
                {
                    patientAdded = PatientDAL.AddPatient(newPat);
                }
                else
                {
                    throw new PatientException("Please provide valid data for the patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }
        public static Patient SearchPatient(int patID)
        {
            Patient patientSearched = null;
            try
            {
                patientSearched = PatientDAL.SearchPatient(patID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }
        public static bool SerializePatient()
        {
            bool patSerialized = false;

            try
            {
                patSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            return patSerialized;
        }

        public static List<Patient> DeserializePatient()
        {
            List<Patient> patList = null;

            try
            {
                patList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patList;
        }


    }
}
