﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDetails.Exception
{
    /// <summary>
    /// Employee ID:94102
    /// Employee Name:Reeba Ann Ponny
    /// Description: This is Exception 
    /// Date of creation: 19/9/2016
    /// </summary>
    public class PatientException:ApplicationException
    {
 public PatientException()
            : base()
        { }
        public PatientException(string msg)
            : base(msg)
        { }

    }
}

