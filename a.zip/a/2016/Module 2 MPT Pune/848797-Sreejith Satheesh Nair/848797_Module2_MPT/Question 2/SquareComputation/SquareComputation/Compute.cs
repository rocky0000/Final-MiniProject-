﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SquareofNumber;     //Reference to Test class
using System.Reflection;  

namespace SquareComputation
{
    class Compute
    {
        static void Main(string[] args)
        {
            Assembly squareAssembly = Assembly.LoadFrom("SquareofNumber.dll");

            Type squareType = squareAssembly.GetType("SquareofNumber.Test");

            //To get all the methods
            MethodInfo[] squareMethod = squareType.GetMethods();

            //object created to call Test class as it is not static
            object squareObj = squareAssembly.CreateInstance("SquareofNumber.Test");

            MethodInfo square = squareType.GetMethod("DoWork");
            int result = (int)square.Invoke(squareObj, new object[] { 4 });

            Console.WriteLine("Square of the number passed as parameter: " + result + "\n");


            int i = 0;
            Console.WriteLine("\nMetadata about DoWork method is as follows:");
            foreach (MethodInfo method in squareMethod)
            {
                i++;
                //Prints method name
                Console.WriteLine("\n\nMethod name: " + method.Name);
                //Prints return type of method
                Console.WriteLine("Return Type: " + method.ReturnType.Name);
                //Prints if method is static or not
                Console.WriteLine("Is Static: " + method.IsStatic);
                if(i == 1)
                {
                    //Prints the parameter names passed in the method
                    Console.WriteLine("Parameter Name : " + method.GetParameters().ElementAt(0).Name);
                    //Prints the type of parameters passed in the method
                    Console.WriteLine("Parameter Type : " + method.GetParameters().ElementAt(0).ParameterType);

                }
            }


           
        }
    }
}
