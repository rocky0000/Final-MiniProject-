﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SquareofNumber
{
    public class Test
    {
        //Method which takes  one parameter
        public int DoWork(int number)
        {
           return number * number;  //returns the square of the parameter passed
        }
     

    }
}
