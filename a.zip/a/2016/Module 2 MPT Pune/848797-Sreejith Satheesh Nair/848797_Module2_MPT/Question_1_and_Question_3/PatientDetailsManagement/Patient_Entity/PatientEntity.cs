﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patient_Entity
{
    /// <summary>
    /// Employee ID      : 848797
    /// Employee Name    : Sreejith Nair
    /// Description      : This is entity class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
 
    
    [Serializable]
    public class PatientEntity
    {
        int patient_id ;
        string patient_name;
        int age;
        string phone_number;


        //Property for Get or set Patient ID
        public int PatientID
        {
            get { return patient_id; }
            set { patient_id = value; }
        }

        //Property for Get or set Patient Name
        public string PatientName
        {
            get { return patient_name;}
            set { patient_name = value;} 
        }

        //Property for Get or set Age
        public int Age
        {
            get { return age;}
            set { age = value ;} 
        }

        //Property for Get or set Phone Number
        public string PhoneNumber
        {
            get { return phone_number ;}
            set { phone_number = value;} 
        }
    }
}
