﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Patient_Entity;        //Reference to Patient Entity
using Patient_Exception;     //Reference to Patient Exception
using Patient_DAL;           //Reference to Data Access Layer
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Patient_BL
{
    /// <summary>
    /// Employee ID      : 848797
    /// Employee Name    : Sreejith Nair
    /// Description      : This is Business Layer class for PatientBL
    /// Date of Creation : 19/09/2016
    /// </summary>

    public class PatientBL
    {

        //Function to validate patient data
        public static bool ValidatePatient(PatientEntity patient)
        {
            bool validPatient = true;

            StringBuilder msg = new StringBuilder();

            try 
            {
                
                //Validating patient name for alphabets
                if (!Regex.IsMatch(patient.PatientName, "[A-Z][a-z ]+"))
                {
                    msg.Append("Patient name should have alphabets and spaces only and it should begin with a capital letter\n");
                    validPatient = false;
                }

                //Validating phone number for 10 digits
                if (!Regex.IsMatch(patient.PhoneNumber, "[1-9][0-9]{9}"))
                {
                    msg.Append("Phone number should have 10 digits and it should not begin with 0");
                    validPatient = false;
                }

                //Validating age 
                if (patient.Age < 0 || patient.Age > 100)
                {
                    msg.Append("Patient age cannot be negative and cannot be greater than 100\n");
                    validPatient = false;
                }

                if (validPatient == false)
                {
                    throw new PatientException(msg.ToString());
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validPatient;
        }


        //Function to add Patient to the list
        public static bool AddPatient(PatientEntity newPatient)
        {
            bool patientAdded = false;

            try
            {
                if (ValidatePatient(newPatient))
                {
                    patientAdded = PatientDAL.AddPatient(newPatient);
                }
                else
                {
                    throw new PatientException("Please provide valid data for patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function to search patient from the list
        public static PatientEntity SearchPatient(string patient_name)
        {
            PatientEntity patientSearch = null;

            try
            {
                patientSearch = PatientDAL.SearchPatient(patient_name);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearch;
        }

        //Function to serialize patient details
        public static bool SerializePatient()
        {
            bool patientSerialized = false;

            try
            {
                patientSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }


        //Function to serialize patient details
        public static List<PatientEntity> DeserializePatient()
        {
            List<PatientEntity> patientList = null;

            try
            {
                patientList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return patientList;
        }




    }
}
