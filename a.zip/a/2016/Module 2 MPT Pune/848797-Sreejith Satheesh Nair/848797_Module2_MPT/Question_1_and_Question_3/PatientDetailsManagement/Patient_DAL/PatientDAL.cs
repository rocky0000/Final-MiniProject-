﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Patient_Entity;         //Reference to Patient Entity
using Patient_Exception;      //Reference to Patient Exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Patient_DAL
{
    /// <summary>
    /// Employee ID      : 848797
    /// Employee Name    : Sreejith Nair
    /// Description      : This is Data Access Layer class for PatientDAL
    /// Date of Creation : 19/09/2016
    /// </summary>

    public class PatientDAL
    {

        static List<PatientEntity> patientList = new List<PatientEntity>();

        //Function to add new patient to the list of patient
        public static bool AddPatient(PatientEntity newPatient)
        {
            bool patientAdded = false;

            try
            {
                //Adding patient
                patientList.Add(newPatient);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientAdded;
        }

        //Function to search patient from the list of patients
        public static PatientEntity SearchPatient(string patient_name)
        {
            PatientEntity patientSearch = null;

            try
            {
                //searching patient
                patientSearch = patientList.Find(patient => patient.PatientName == patient_name);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearch;
        }


        //Function to serialize the patient details
        public static bool SerializePatient()
        {
            bool patientSerialized = false;

            try
            {
                if (patientList.Count > 0)
                {
                    FileStream fstream = new FileStream(@"..\..\Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binaryFormat = new BinaryFormatter();
                    binaryFormat.Serialize(fstream, patientList);
                    patientSerialized = true;
                    fstream.Close();
                }
                else
                {
                    throw new PatientException("No patient data, so cannot serialize");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }

        //Function to Deserialize the patient details
        public static List<PatientEntity> DeserializePatient()
        {
            List<PatientEntity> deserializePatient = null;

            try
            {
              
                FileStream fstream = new FileStream(@"..\..\Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binaryFormat = new BinaryFormatter();
                deserializePatient = (List<PatientEntity>)binaryFormat.Deserialize(fstream);
                fstream.Close();
            }

            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return deserializePatient;

        }

    }
}
