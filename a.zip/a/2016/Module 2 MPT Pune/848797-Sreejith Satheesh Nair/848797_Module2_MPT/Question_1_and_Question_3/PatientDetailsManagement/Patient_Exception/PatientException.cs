﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patient_Exception
{
    /// <summary>
    /// Employee ID      : 848797
    /// Employee Name    : Sreejith Nair
    /// Description      : This is exception class for PatientException
    /// Date of Creation : 19/09/2016
    /// </summary>

    public class PatientException : ApplicationException
    {
        //constructor with no parameter
        public PatientException()
            : base()
        { }
    
        //constructor with one parameter 
        public PatientException(string msg)
            : base(msg)
        { }

    }
}
