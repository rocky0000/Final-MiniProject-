﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Patient_Entity;        //Reference to Patient Entity
using Patient_Exception;     //Reference to Patient Exception
using Patient_BL;           //Reference to Business Layer
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Patient_PL
{
    /// <summary>
    /// Employee ID      : 848797
    /// Employee Name    : Sreejith Nair
    /// Description      : This is Presentation Layer class for PatientPL
    /// Date of Creation : 19/09/2016
    /// </summary>

    class PatientPL
    {
        //Function to add patient
        static int autoGenerate = 101;
        public static void AddPatient()
        {
            PatientEntity newPatient = new PatientEntity();
            
            try
            {
                newPatient.PatientID = autoGenerate;
               
                Console.Write("Enter Patient Name :");
                newPatient.PatientName = Console.ReadLine();
                Console.Write("Enter Age :");
                newPatient.Age = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Phone number :");
                newPatient.PhoneNumber = Console.ReadLine();



                bool patientAdded = PatientBL.AddPatient(newPatient);

                if (patientAdded)
                {
                    Console.WriteLine("Patient added successfully");
                    autoGenerate= autoGenerate + 1;
                }
                else
                {
                    throw new PatientException("Patient not added");
                }

            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to search patient
        public static void SearchPatient()
        {
            try
            {
                string patient_name;
                Console.WriteLine("Enter patient name for the patient which you would like to search");
                patient_name = Console.ReadLine();

                PatientEntity patient = PatientBL.SearchPatient(patient_name);

                if (patient != null)
                {
                    Console.WriteLine("Patient ID :" + patient.PatientID);
                    Console.WriteLine("Patient Name :" + patient.PatientName);
                    Console.WriteLine("Phone Number :" + patient.PhoneNumber);
                    Console.WriteLine("Age :" + patient.Age);
                    

                }
                else
                {
                    throw new PatientException("Patient not found with Patient Name: " + patient_name);
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to serialize patient details
        public static void SerializePatient()
        {
            try
            {
                bool patientSerialized = PatientBL.SerializePatient();
                if (patientSerialized)
                {
                    Console.WriteLine("patient data is serialized");
                }
                else
                {
                    throw new PatientException("patient data is not serialized");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        //Function to Deserialize patient details
        public static void DeserializePatient()
        {
            try
            {
                List<PatientEntity> patientList = PatientBL.DeserializePatient();
                if (patientList != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("Patient ID \t Patient Name \t Phone Number \t\t Age ");
                    Console.WriteLine("******************************************************************************");
                    foreach (PatientEntity patient in patientList)
                    {
                        Console.WriteLine(patient.PatientID + "\t\t" + patient.PatientName + "\t\t" + patient.PhoneNumber + "\t\t" + patient.Age);
                    }
                }
                else
                {
                    throw new PatientException("Patient data is not Deserialized");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }


        //Funtion to show the menu to the user who handles the application
        public static void PrintMenu()
        {
            Console.WriteLine("\n*****************************************");
            Console.WriteLine("1. Add Patient Details");
            Console.WriteLine("2. Search Patient Details");
            Console.WriteLine("3. Serialize Patient Details");
            Console.WriteLine("4. Deserialize Patient Details");
            Console.WriteLine("5. Exit");
            Console.WriteLine("*****************************************");
        }


        static void Main(string[] args)
        {
            int choice = 0;

            try
            {
                do
                {
                    PrintMenu();

                    Console.WriteLine("\nEnter Your Choice");
                    choice = Convert.ToInt32(Console.ReadLine());
                    //use of switch case to select any one of the options given
                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;
                        case 2: SearchPatient();
                            break;
                        case 3: SerializePatient();
                            break;
                        case 4: DeserializePatient();
                            break;
                        case 5: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("Please select valid option");
                            break;
                    }

                } while (choice != 5);

            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
