﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using QuestionNo2;

namespace Test
{
    /// <summary>
    /// Employee Id: 94125
    /// Employee Nmae: Sayali More
    /// Description:This is the Program class for calling the dowork function from QuestionNo2 Library.
    /// Date Of Creation:19/09/2016
    /// </summary> 
   
    class Program
    {
        static void Main(string[] args)
        {
            QuestionNo2.Test test=new QuestionNo2.Test();

            int number,square;

            //Loads the Assembly from QuestionNo2
            Assembly myAssembly = Assembly.LoadFrom("QuestionNo2.dll");
            //Loads the Type from Test Class 
            Type testType = myAssembly.GetType("QuestionNo2.Test");
            //To get the Method Info about the methods in Test Class 
            MethodInfo testMethods = testType.GetMethod("DoWork");

            //To ask and accept the numbe rto fimnd it's square 
            Console.WriteLine("Enter the number whose square is to be found :");
            number=Convert.ToInt32(Console.ReadLine());
            //To Invoke or call a method  DoWork  from test class 
            square=(int)testMethods.Invoke(test,new object[]{number} );
            //To Display the result obtained
            Console.WriteLine("Square :"+square);

            //Displays the method Details
            Console.WriteLine("Method Name : " + testMethods.Name);
            Console.WriteLine("Return Type : " + testMethods.ReturnType.Name);
            if (testMethods.IsStatic)
            {
                Console.WriteLine("This Method DoWork is Static.");
            }
            else
            {
                Console.WriteLine("This is an Instance Method.");
            }

            //To get parameter details
            ParameterInfo[] parameter=testMethods.GetParameters();

            foreach (ParameterInfo param in parameter)
            {
                Console.WriteLine("Parameter Name : " + param.Name);
                Console.WriteLine("Parameter Type :" + param.ParameterType);

            }
            Console.ReadKey();


        }
    }
}
