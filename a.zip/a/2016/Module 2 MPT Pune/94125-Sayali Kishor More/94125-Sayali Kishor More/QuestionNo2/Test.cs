﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuestionNo2
{
    /// <summary>
    /// Employee Id: 94125
    /// Employee Nmae: Sayali More
    /// Description:This is the Test class for Calculating the square of a number.
    /// Date Of Creation:19/09/2016
    /// </summary>
    
    public class Test
    {
        //Method to calculate the square of the number passed as a parameter
        public static int DoWork(int parameter)
        {
            int square = (parameter * parameter);
            //returns the result
            return square;
        }
    }
}
