﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using HMS.Entity;    //Reference to PatientDetails Entity
using HMS.Exception; //Reference to PatientDetails Exception
using HMS.DAL;       //Reference to PatientDetails DAL

namespace HMS.BL
{
    /// <summary>
    /// Employee Id: 94125
    /// Employee Nmae: Sayali More
    /// Description:This is the Bussiness Layer(BL) class for Patient Details.
    /// Date Of Creation:19/09/2016
    /// </summary>
    
    public class PatientDetailsBL
    {
        //Function to ValidateEmployee 
        public static bool ValidateEmployee(PatientDetails pat)
        {
            bool validDetail = true;
            StringBuilder msg = new StringBuilder();

            //Try block to throw exception if occurs
            try
            {
                //this condition checks if the patient Id is a three digit number 
                if (pat.PatientId < 100 || pat.PatientId > 999)
                {
                    msg.Append("Employee Id should be a 3 digits number\n");
                    //returns false if it is not a three digit number
                    validDetail = false;
                }

                //this condition checks if the patient Name contains only alphabets and should start with a Capital Letter
                if (!Regex.IsMatch(pat.PatientName, "[A-Z][a-z]+"))
                {
                    msg.Append("Employee name should contain alphabets and spaces only and it should start with capital letter");
                    //returns false if the PatientName contains anything else than alphabets or spaces  or if the first letter is not capital
                    validDetail = false;
                }

                if (!Regex.IsMatch(pat.PatientPhoneNo, "[789][0-9]{9}"))
                {
                    msg.Append("Phone No. should start with 7  or 8 or 9 and it should have only 10 digits");
                    //returns false if it is not in the required format
                    validDetail = false;
                }

                //checks if the age is valid
                if (pat.PatientAge < 1| pat.PatientAge > 100)
                {
                    msg.Append("Age should neither be negative nor greater then 100");
                    validDetail = false;
                }
            }

                catch (PatientDetailsException ex)
                {
                throw ex;
                 }
                catch (SystemException se)
                {
                throw se;
                }
                return validDetail;
        }
   

              

        //function to check validity and Add Patient Details
        public static bool AddPatient(PatientDetails newDetail)
        {
            bool detailAdded = false;

            //to throw exception
            try 
            { 
                //checks the validity of the new record
                if(ValidateEmployee(newDetail))
                {
                      detailAdded=PatientDetailsDAL.AddPatient(newDetail);
                }
                else
                {
                    throw new PatientDetailsException("Please provide valid data ");
                }
            }

            // Catches user Defined Exception
            catch (PatientDetailsException ex)
            {
                throw ex;
            }

            //Catches System Exception
            catch (SystemException se)
            {
                throw se;
            }
            return detailAdded;
        }


        //Function to check validity and Search Patient Details depending on the patient Id (patId) provided by the user
        public static PatientDetails SearchPatient(int patId) 
        {
            PatientDetails detailSearched = null;

            //To throw Exception
            try
            {

                detailSearched = PatientDetailsDAL.SearchPatient(patId);
            }

            // to catch user defined exception
            catch (PatientDetailsException ex)
            {
                throw ex;
            }
            //to catch system exceptions
            catch (SystemException se)
            {
                throw se;
            }
            return detailSearched;
        }


        //Function to serialize the patient details
        public static bool SerializePatientDetails()
        {
            bool detailSerialize = false;
            //To throw Exception
            try
            {
                detailSerialize = PatientDetailsDAL.SerializePatientDetails();

            }

             // to catch user defined exception
            catch (PatientDetailsException ex)
            {
                throw ex;
            }

            //to catch system exceptions        
            catch (SystemException se)
            {
                throw se;
            }
            return detailSerialize;
        }

        //Function to deserialize the patient details
        public static List<PatientDetails> DeserializePatientDetails()
        {
            List<PatientDetails> deserial = null;
            //To throw Exception
            try
            {
                deserial = PatientDetailsDAL.DeserializePatientDetails();
            }

            // to catch user defined exception
            catch (PatientDetailsException ex)
            {
                throw ex;
            }

            //to catch system exceptions
            catch (SystemException se)
            {
                throw se;
            }
            return deserial;
        }
    }
}
