﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.Entity;    //Reference to PatientDetails Entity
using HMS.Exception; //Reference to PatientDetails Exception
using HMS.DAL;       //Reference to PatientDetails DAL  
using HMS.BL;        //Reference to PatientDetails BL

namespace HMS.PL
{
    /// <summary>
    /// Employee Id: 94125
    /// Employee Nmae: Sayali More
    /// Description:This is the Presentaion Layer(PL) class for Patient Details.
    /// Date Of Creation:19/09/2016
    /// </summary>

    class PatientDetailsPL
    {
        static int count = 100;    //to autogenerate the Patient Id

        //Function to accept user details and call AddEmployee Function from BL
        public static bool AddPatient()
        {
            bool detailAdded=false;
            PatientDetails newDetail = new PatientDetails();

            try
            {
            
                Console.Write("Patient Id :");
                Console.WriteLine(count);
                newDetail.PatientId = count;
                Console.Write("Enter Patient Name :");
                newDetail.PatientName = Console.ReadLine();
                Console.Write("Enter Patient Age :");
                newDetail.PatientAge = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Patient Phone No :");
                newDetail.PatientPhoneNo = Console.ReadLine();

                detailAdded = PatientDetailsBL.AddPatient(newDetail);
                if (detailAdded)
                {
                    Console.WriteLine("Patient Details Added Successfully!!");
                    
                }
                else
                {

                    throw new PatientDetailsException("Patient detail was not added..");
                }
            }
            catch (PatientDetailsException ex)
            {
                //To display the user defined exception thrown
                Console.WriteLine(ex.Message); 
            }
            catch (SystemException se)
            {
                //To display the system exception thrown
                Console.WriteLine(se.Message);
            }
            return detailAdded;
        }

        //Function to accept user inputs and call search method
        public static void SearchPatient()
        {
            try
            {
                Console.WriteLine("Enter Patient ID for Patient whose record you would like to search :");
                int Id = Convert.ToInt32(Console.ReadLine());

                PatientDetails pat = PatientDetailsBL.SearchPatient(Id);
                //Checks if the patient with the mentioned patient id is present
                if (pat != null)
                {
                    //if its true it displays the result
                    Console.WriteLine("*****************************************************************");
                    Console.WriteLine("Patient ID:\tPatient Name:\tPatient Age:\tPatient Phone No.:");
                    Console.WriteLine("*****************************************************************");
                    Console.WriteLine(pat.PatientId + "\t\t" + pat.PatientName + "\t\t" + pat.PatientAge+ "\t" + pat.PatientPhoneNo);
                }
                else
                    throw new PatientDetailsException("Employee not found with Patient ID " + Id +"Please check the Id Entered");
            }
            catch (PatientDetailsException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException se)
            {
                Console.WriteLine(se.Message);
            }
        }

        //Function to Serialize the details of patients
        public static void SerializePatientDetails()
        {
            try
            {
                bool detailSerialize = PatientDetailsBL.SerializePatientDetails();
                //checks if the Serialization is performed
                if (detailSerialize)
                    Console.WriteLine("Patient Data is Serialized.");
                else
                    throw new PatientDetailsException("Employee data not serialized");
            }
            catch (PatientDetailsException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException se)
            {
                Console.WriteLine(se.Message);
            }
           
        }

        //Function to Deserialize the details of patients
        public static void DeserializePatientDetails()
        {
            try
            {
                List<PatientDetails> deserial = PatientDetailsBL.DeserializePatientDetails();
                //Checks if deserialization is done
                if (deserial != null)
                {
                    Console.WriteLine("************************************************************");
                    Console.WriteLine("Patient ID:\tPatient Name:\tPatient Age:\tPatient Phone No.:");
                    Console.WriteLine("************************************************************");

                    foreach (PatientDetails pd in deserial)
                    {
                        Console.WriteLine(pd.PatientId + "\t\t" + pd.PatientName + "\t\t" + pd.PatientAge + "\t" + pd.PatientPhoneNo);
                    }
    
                }
            }
            catch (PatientDetailsException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException se)
            {
                Console.WriteLine(se.Message);
            }
        }


        //Function to print the menu for the user to make a choice
        public static void PrintMenu()
        {
            Console.WriteLine("1.Add Patient Details");
            Console.WriteLine("2.Search Patient Details");
            Console.WriteLine("3.Serialize Employee");
            Console.WriteLine("4.Deserialize Employee");
            Console.WriteLine("5.Exit");
        }


        static void Main(string[] args)
        {
            try
            {
                int ch = 0;
                do
                {
                    //Prints the menu
                    PrintMenu();
                    Console.WriteLine("Enter your choice :");
                    ch = Convert.ToInt32(Console.ReadLine());

                    switch (ch)
                    {
                        case 1:
                            bool detailAdded=AddPatient();
                            //checks if the add detail function is performed and increments the counter for the new detail only if it is performed
                            if (detailAdded)
                            {
                                count++;
                            }
                            break;
                        case 2:
                            SearchPatient();
                            break;
                        case 3:
                            SerializePatientDetails();
                            break;
                        case 4:
                            DeserializePatientDetails();
                            break;
                        case 5:
                            Environment.Exit(1);
                            break;
                        default:
                            Console.WriteLine("Please enter the appropriate choice");
                            break;

                    }
                    Console.WriteLine("\n");
                    //Continues the loop till the user doesn't choose exit option 
                } while (ch != 5);
            }
            catch (SystemException se)
            {
                Console.WriteLine(se.Message);
            }

            Console.ReadKey();

        }
    }
}
