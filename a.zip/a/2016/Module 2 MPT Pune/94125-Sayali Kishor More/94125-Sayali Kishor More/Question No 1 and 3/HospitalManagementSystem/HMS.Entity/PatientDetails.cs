﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Entity
{
    /// <summary>
    /// Employee Id: 94125
    /// Employee Nmae: Sayali More
    /// Description:This is the Entity class for Patient Details.
    /// Date Of Creation:19/09/2016
    /// </summary>

        [Serializable]
    public class PatientDetails
    {
    
        //Property for Get or Set Patient ID
        public int PatientId { get; set; }
        //Property for Get or Set Patient Name
        public string PatientName { get; set; }
        //Property for Get or Set Patient Age
        public int PatientAge { get; set; }
        //Property for Get or Set Patient Phone No.
        public string PatientPhoneNo { get; set; }

    }
}
