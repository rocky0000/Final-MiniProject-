﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using HMS.Entity;     //Reference to PatientDetails Entity
using HMS.Exception;  //Reference to PatientDetails Exception

namespace HMS.DAL
{
    /// <summary>
    /// Employee Id: 94125
    /// Employee Nmae: Sayali More
    /// Description:This is the Data Access Layer(DAL) class for Patient Details.
    /// Date Of Creation:19/09/2016
    /// </summary>
    
    public class PatientDetailsDAL
    {
        static List<PatientDetails> patientList = new List<PatientDetails>(); //PatientDetails List Instantiated

        public static bool AddPatient(PatientDetails newDetail) //Function To Add new Patient Detail to the List of Patients
        {
            bool detailAdded = false; //To show the status of the function

            //Try block to throw exception if occurs
            try
            {
                //Adding Patient Details
                patientList.Add(newDetail);
                detailAdded = true;

            }
            // To catch User Defined Exception
            catch (PatientDetailsException ex)
            {
                throw ex;
            }
            // To catch System Exception which cannot be handled by User Defined Exception
            catch (SystemException se)
            {
                throw se;
            }
            return detailAdded; //Returns the status of the operation i.e. true if detail added  or false if it was not added
        }


        //Function to search the Patient Details
        public static PatientDetails SearchPatient(int patientId)
        {
            PatientDetails detailSearched = null;  

            //Try block to throw exception if occurs
            try
            {
                //assigns the patient detail record object refernce of the patient to be searched
                detailSearched = patientList.Find(pat => pat.PatientId == patientId);

            }
            //catch block to catch the exception and handle it if user defined exception thrown by the try block
            catch (PatientDetailsException ex)
            {
                throw ex;
            }

           //catch block to catch the exception and handle it if system exception thrown by the try block
            catch (SystemException se)
            {
                throw se;
            }
            return detailSearched;
        }


        //Function to serialize patient details
        public static bool SerializePatientDetails()
        {
            bool detailSerialize = false;

            //Try block to throw exception if occurs
            try
            {
                if (patientList.Count > 0)
                {
                    FileStream fs = new FileStream(@"..\..\..\PatientDetails.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binformat = new BinaryFormatter();
                    binformat.Serialize(fs, patientList);
                    detailSerialize = true;
                    fs.Close();

                }
                else
                    throw new PatientDetailsException("THIS CANNOT BE SERIALIZED");
            }

           //catch block to catch the exception and handle it if user defined exception thrown by the try block
            catch (PatientDetailsException ex)
            {
                throw ex;
            }

           //catch block to catch the exception and handle it if system exception thrown by the try block
            catch (SystemException se)
            {
                throw se;
            }
            return detailSerialize;
        }
        public static List<PatientDetails> DeserializePatientDetails()
        {
            
            List<PatientDetails> deserial = null;

            //Try block to throw exception if occurs
            try
            {

                FileStream fs = new FileStream(@"..\..\..\PatientDetails.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binformat = new BinaryFormatter();
                deserial = (List<PatientDetails>)binformat.Deserialize(fs);
                fs.Close();

            }

           //catch block to catch the exception and handle it if user defined exception thrown by the try block
            catch (PatientDetailsException ex)
            {
                throw ex;
            }

            //catch block to catch the exception and handle it if system exception thrown by the try block
            catch (SystemException se)
            {
                throw se;
            }
            return deserial;
        }
    }
}
