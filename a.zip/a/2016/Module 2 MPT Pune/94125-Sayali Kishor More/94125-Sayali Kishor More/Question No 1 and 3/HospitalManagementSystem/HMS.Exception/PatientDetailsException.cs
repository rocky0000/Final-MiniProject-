﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Exception
{
    /// <summary>
    /// Employee Id: 94125
    /// Employee Nmae: Sayali More
    /// Description:This is the Exception class for Patient Details.
    /// Date Of Creation:19/09/2016
    /// </summary>

    public class PatientDetailsException :ApplicationException  
    {
         public PatientDetailsException()
            : base()
        { }
        public PatientDetailsException(string msg)
            : base(msg)
        { }
    }
}
