﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patient.Exception
{
    /// <summary>
    /// Employee ID     : 848829
    /// Employee Name   : Shamail Mulla
    /// Description     : This class has a user defined exception class for the
    ///                     Patient Management System
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientException: ApplicationException
    {
        public PatientException()
            : base()
        { }

        public PatientException(string errorMsg)
            : base(errorMsg)
        { }
    }
}
