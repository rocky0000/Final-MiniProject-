﻿/*********************************************************************************************
 * THIS IS THE PRESENTATION LAYER  *
*********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Patient.BL; //Contains the main business logic of the management system
using Patient.DAL; //This layer returns results (or data) back after performing the particular task
using Patient.Exception; //User defined exception class
using PatientEntity; //Contains patient data fields and properties

namespace Patient.PL
{
    /// <summary>
    /// Employee ID     : 848829
    /// Employee Name   : Shamail Mulla
    /// Description     : This class accepts all the data from the user and also 
    ///                     displays the deserialised data.
    ///                     User choice of action is also taken in this layer.
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientPL
    {
        //This method accepts patient name, phone, age and sends it to the BL layer for
        //validation before it can be added to the patient records
        public static void AddPatientRecord()
        {
            PatientEntity.Patient newPatientRecord = new PatientEntity.Patient();

            try
            {
                //Taking all the data from the user
                Console.Write("Enter Patient Name : ");
                newPatientRecord.PatientName = Console.ReadLine();
                Console.Write("Enter Phone No : ");
                newPatientRecord.PhoneNo = Console.ReadLine();
                Console.Write("Enter Age : ");
                newPatientRecord.Age = Convert.ToInt32(Console.ReadLine());

                //Calling business layer method to validate and add record
                bool patientRecordAdded = PatientBL.AddPatient(newPatientRecord);

                if (patientRecordAdded)
                {
                    Console.WriteLine("\nPatient ID\tPatient Name\t\tPhone No\t\tPatient Age");
                    
                    Console.WriteLine("\n" + newPatientRecord.PatientID + "\t\t" + newPatientRecord.PatientName + "\t\t" + newPatientRecord.PhoneNo + "\t\t" + newPatientRecord.Age+"\n");

                    Console.WriteLine("Patient Record Added Successfully\n");
                }
                else
                    throw new PatientException("\nSorry, Patient Record could not be Added.");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //This method takes from the user a record to search by ID
        //The ID is passed to the BL (business logic) layer to search
        //If the record is found, the BL layer returns the entire record
        //Otherwise null is returned
        public static void SearchPatientRecord()
        {
            try
            {
                int patientSearchID;
                Console.WriteLine("Enter Patient ID for the patient You Would Like to Search: ");
                Console.Write("(Records start from index 1)");
                patientSearchID = Convert.ToInt32(Console.ReadLine());

                PatientEntity.Patient searchPatient = PatientBL.SearchPatient(patientSearchID);

                if (searchPatient != null)
                {
                    Console.WriteLine("Patient ID\t: " + searchPatient.PatientID);
                    Console.WriteLine("Patient Name\t: " + searchPatient.PatientName);
                    Console.WriteLine("Patient Number\t: " + searchPatient.PhoneNo);
                    Console.WriteLine("Patient Aget\t: " + searchPatient.Age);
                }
                else
                    throw new PatientException("Patient not found with Paitent ID : " + patientSearchID);
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //This method serialises the patient records list using binary serialisation
        public static void SerializePatientData()
        {
            try
            {
                bool patientSerialized = PatientBL.SerializePatientData();
                if (patientSerialized)
                    Console.WriteLine("\nPatient data is serialized!");
                else
                    throw new PatientException("\nPatient Data is not Serialized.");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //This method receives the list of patient records from the BL (business logic) layer
        //and prints the patient records if it has been successfully deserialised.
        //If BL layer returns null, an exception is thrown with the appropriate message
        public static void DeserializePatient()
        {
            try
            {
                List<PatientEntity.Patient> patientList = PatientBL.DeserializePatient();

                if (patientList.Count>0)
                {
                    Console.WriteLine("\n\n********************************************************************************");
                    Console.WriteLine("Patient ID\tPatient Name\t\tPhone No\t\tPatient Age");
                    Console.WriteLine("********************************************************************************");
                    foreach (PatientEntity.Patient patient in patientList)
                    {
                        Console.WriteLine(patient.PatientID + "\t\t" + patient.PatientName + "\t\t" + patient.PhoneNo + "\t\t" + patient.Age);
                    }
                }
                else
                    throw new PatientException("\nThere is no patient data.");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //This method is called everytime the user wants to perform some operation on the
        //patient records. The available functions are adding, searching, serialising and
        //desrialising patient records.
        public static void PrintMenu()
        {
            Console.WriteLine("\n************************");
            Console.WriteLine("1. Add Patient");
            Console.WriteLine("2. Search Patient");
            Console.WriteLine("3. Serialize Patient");
            Console.WriteLine("4. Deserialize Patient");
            Console.WriteLine("5. Exit");
            Console.WriteLine("************************");
        }

        static void Main(string[] args)
        {
            int choice;

            try
            {
                do
                {
                    Console.Write("\nEnter Your Choice : ");

                    //Display the menu for the user
                    PrintMenu();

                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {//Calling the appropriate functions
                        case 1: AddPatientRecord();
                            break;

                        case 2: SearchPatientRecord();
                            break;

                        case 3: SerializePatientData();
                            break;

                        case 4: DeserializePatient();
                            break;

                        case 5: //To exit the program
                            break;

                        default: Console.WriteLine("Please provide a valid choice (1-5)");
                            break;
                    }
                } while (choice != 5);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
