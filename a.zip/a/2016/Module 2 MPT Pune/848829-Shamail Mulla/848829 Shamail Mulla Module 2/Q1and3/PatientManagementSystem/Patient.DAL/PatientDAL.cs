﻿/*********************************************************************************************
 * THIS IS THE DATA ACCESS LAYER LAYER  *
*********************************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary; //For binary serialisation
using System.IO;
using Patient.Exception; //User defined exception class
using PatientEntity; //Contains patient data fields and properties

namespace Patient.DAL
{
    /// <summary>
    /// Employee ID     : 848829
    /// Employee Name   : Shamail Mulla
    /// Description     : This class containts the following actions:
    ///                 1) Adding a record to the list
    ///                 2) searching in the current list for a record by patient ID
    ///                 3) serialisation of a data using binary serialisation
    ///                 4) deserialisation of a binary serialised txt file
    ///                 
    ///                 The data taken from the list is sent to PatientBL.cs
    /// 
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientDAL
    {
        static List<PatientEntity.Patient> patientList = new List<PatientEntity.Patient>();

        //This method takes a valid patient record from the BL layer and adds it to the list.
        //Method returns a true value if the record was succesfully added to the list.
        //Otherwise false is returned back to the BL layer.
        public static bool AddPatient(PatientEntity.Patient newPatient)
        {
            bool patientAdded = false;

            try
            {
                //Adding a new patient to the list
                //Using named arguments to add a record
                patientList.Add(
                                new PatientEntity.Patient() 
                                { 
                                    //Using named arguments to add a new record
                                    PatientID = newPatient.PatientID, 
                                    PatientName = newPatient.PatientName, 
                                    PhoneNo = newPatient.PhoneNo,
                                    Age = newPatient.Age 
                                }
                               );
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientAdded;
        }

        //This method receives valid patient ID from the BL layer and seaerches through the patient list for it
        //If the patient ID is found in the list, it returns the record
        //If there is no such record then null is returned
        public static PatientEntity.Patient SearchPatient(int searchPatientID)
        {
            PatientEntity.Patient patientSearched = null;

            try
            {
                //Searching for a patient in the list using lambda function
                patientSearched = patientList.Find(patient => patient.PatientID == searchPatientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearched;
        }

        //If the patient records list is not empty, the data is serialised and the file is created
        //in the PatientManagementSystemFolder (path is specific in the variable 'patientFilePath'
        //If there are no records, an exception is thrown
        public static bool SerializePatient()
        {
            bool patientSerialized = false;

            try
            {
                if (patientList.Count > 0)
                {
                    string patientFilePath = @"..\..\..\PatientData.txt";
                    File.Delete(patientFilePath);
                    FileStream fstream = new FileStream(patientFilePath, FileMode.CreateNew, FileAccess.Write);
                    BinaryFormatter binaryFormat = new BinaryFormatter();
                    binaryFormat.Serialize(fstream, patientList);
                    patientSerialized = true;
                    fstream.Close();
                    
                }
                else
                    throw new PatientException("\nThere are no patient records in the system, so cannot serialize");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSerialized;
        }

        public static List<PatientEntity.Patient> DeserializePatient()
        {
            List<PatientEntity.Patient> desPatient = null;

            try
            {
                string patientFilePath = @"..\..\..\PatientData.txt";
                if (File.Exists(patientFilePath))
                {
                    FileStream fstream = new FileStream(patientFilePath, FileMode.Open, FileAccess.Read);
                    BinaryFormatter binFormat = new BinaryFormatter();
                    desPatient = (List<PatientEntity.Patient>)binFormat.Deserialize(fstream);
                    fstream.Close();
                }
                else
                    throw new PatientException("There is no binary file to deserialise at the given location");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desPatient;
        }

    }
}
