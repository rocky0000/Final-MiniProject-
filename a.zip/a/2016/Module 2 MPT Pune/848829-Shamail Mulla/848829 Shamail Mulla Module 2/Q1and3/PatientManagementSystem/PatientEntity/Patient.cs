﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientEntity
{
    [Serializable]
    /// <summary>
    /// Employee ID     : 848829
    /// Employee Name   : Shamail Mulla
    /// Description     : This Entity Class has all the fields and properties maintained 
    ///                     which will be used to store patient data
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class Patient
    {
        public static int pID = 0;        

        public int PatientID { get; set; }

        public string PatientName { get; set; }

        public string PhoneNo { get; set; }

        public int Age { get; set; }
    }
}
