﻿/*********************************************************************************************
 * THIS IS THE BUSINESS LOGIC LAYER  *
*********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using PatientEntity; //Contains patient data fields and properties
using Patient.Exception; //User defined exception class
using Patient.DAL; //This layer returns results (or data) back after performing the particular task

namespace Patient.BL
{
    /// <summary>
    /// Employee ID     : 848829
    /// Employee Name   : Shamail Mulla
    /// Description     : This class has the business logic of Patient Management System
    ///                     Validations for adding a new patient are performed here 
    ///                     for every record.
    ///                     
    ///                     The data from this layer is passed to PatientPL.cs
    /// 
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientBL
    {
        //Function to validate the patient data
        public static bool ValidatePatient(PatientEntity.Patient patient)
        {
            bool validPatient = true;
            StringBuilder errorMsg = new StringBuilder();

            try
            {
                //Validating patient name
                if (!Regex.IsMatch(patient.PatientName, "[A-Za-z ]+"))
                {
                    errorMsg.Append("Patient Name should have only alphabets and spaces\n");
                    validPatient = false;
                }

                //Validating patient contact number
                if (!Regex.IsMatch(patient.PhoneNo, "[1-9][0-9]{9}"))
                {
                    errorMsg.Append("Phone No should have 10 digits and it should start start from any number 1-9\n");
                    validPatient = false;
                }

                //Validating patient age
                if (patient.Age<0 || patient.Age > 100)
                {
                    errorMsg.Append("Patient Age should be between 0 to 100 years old\n");
                    validPatient = false;
                }

                //If data is not valid then throw exception with the error message
                if (validPatient == false)
                    throw new PatientException(errorMsg.ToString());
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            //True value will be returned if the details provided are valid
            return validPatient;
        }

        //Add a patient record to the list
        public static bool AddPatient(PatientEntity.Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                //Only if all the patient data is valid then patient ID is assigned
                //Patient ID is auto-incremented
                //Patient record is then added to the list
                if (ValidatePatient(newPatient))
                {
                    newPatient.PatientID = ++PatientEntity.Patient.pID;
                    patientAdded = Patient.DAL.PatientDAL.AddPatient(newPatient);
                }
                else
                {
                    throw new PatientException("\nPlease provide valid data for adding patient record");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            //returns false if patient data was not valid
            return patientAdded;
        }

        //This method sends the employee ID to the DAL layer to perform the search
        //If the record is found, it is returned
        //Otherwise a null is returned from the DAL layer
        public static PatientEntity.Patient SearchPatient(int searchPatientID)
        {
            PatientEntity.Patient patientSearchRecord = null;

            try
            {
                patientSearchRecord = PatientDAL.SearchPatient(searchPatientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            //If the patient isn't found, by default null value is returned
            //Otherwise the patient data retrieved from the DAL layer is returned to
            //the variable 'patientSearchRecord'
            return patientSearchRecord;
        }

        //If the DAL (data access layer) has sucessfully serialised the patient records
        //The file gets created in the specified path and true value is returned
        //Otherwise false is returned by the DAL layer
        public static bool SerializePatientData()
        {
            bool patientSerialized = false;

            try
            {
                patientSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            //If serialisation doesn't happen, false is returned back to the PL layer
            return patientSerialized;
        }

        //If the DAL layer is able to successfully deserialise the patient data file from the
        //given file location, the list of patient records is returned
        //Otherwise a null value is returned.
        public static List<PatientEntity.Patient> DeserializePatient()
        {
            List<PatientEntity.Patient> patientList = null;

            try
            {
                patientList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            //By default, if deserialisation fails, null is returned
            //Otherwise the entire list of patient records is returned and sent to the 
            //PL (presentation layer) for displaying.
            return patientList;
        }
    }
}
