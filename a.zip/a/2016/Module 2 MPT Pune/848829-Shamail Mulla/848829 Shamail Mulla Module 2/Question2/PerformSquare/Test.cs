﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerformSquare
{
    /// <summary>
    /// Employee ID     : 848829
    /// Employee Name   : Shamail Mulla
    /// Description     : This class contains 1 method to calculate the square of a given integer.                      
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class Test
    {
        public int DoWork(int parameter)
        {
            return parameter * parameter;
        }
    }
}
