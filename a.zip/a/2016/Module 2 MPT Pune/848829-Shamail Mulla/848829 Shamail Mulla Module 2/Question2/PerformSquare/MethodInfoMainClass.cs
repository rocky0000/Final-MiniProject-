﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace PerformSquare
{

    /// <summary>
    /// Employee ID     : 848829
    /// Employee Name   : Shamail Mulla
    /// Description     : This class accepts all the data from the user and also 
    ///                     displays the results.
    ///                     
    /// Date of Creation : 19/09/2016
    /// </summary>
    class MethodInfoMainClass
    {
        static void Main(string[] args)
        {
            //Creating an object of the test class
            //So that DoWork() method can be called
            Test testObj = new Test();

            //Extracting method information about DoWork() method
            Type t = typeof(Test);
            MethodInfo doWorkInfo = t.GetMethod("DoWork");

            //Storing Metadata of the DoWork() method
            string methodName = doWorkInfo.Name;
            Type returnType = doWorkInfo.ReturnType;
            bool isMethodStatic = doWorkInfo.IsStatic;            
            ParameterInfo[] paramsInfo = doWorkInfo.GetParameters();
            
            Console.WriteLine("Metadata");
            Console.WriteLine("\n\tMethod Name\t\t: " + methodName);
            Console.WriteLine("\tMethod Return Type\t: " + (returnType));
            Console.WriteLine("\tIs Method Static\t: " + isMethodStatic);
            Console.Write("\tParameters Information: ");
            //For every parameter taken by the method, details are displayed
            foreach (ParameterInfo pInfo in paramsInfo)
            {
                Console.Write("\n\t\tParameter Name\t: " + pInfo.Name);
                Console.Write("\n\t\tParameter Type\t: " + pInfo.ParameterType);
            }

            //Calling the DoWork() method to display its output
            int result = testObj.DoWork(3);
            Console.WriteLine("\n\nCalculate The square of 3\nOutput of DoWork() method: " + result + "\n");

        }
    }
}
