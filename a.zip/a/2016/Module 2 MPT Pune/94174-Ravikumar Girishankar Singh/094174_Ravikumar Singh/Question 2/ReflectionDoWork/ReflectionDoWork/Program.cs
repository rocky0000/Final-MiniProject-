﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestLibrary;
using System.Reflection;


namespace ReflectionDoWork
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("TestLibrary.dll"); //using testlibrary.dll
            Type calType = myAssembly.GetType("TestLibrary.Test");
            MethodInfo calMethod = calType.GetMethod("DoWork");

                //method name is
                Console.WriteLine("Method Name : " + calMethod.Name);

                //return type is
                Console.WriteLine("Return Type : " + calMethod.ReturnType);

                //static or instance ?
                Console.WriteLine("Is Static? : " + calMethod.IsStatic);

                //Parameter names
                Console.WriteLine("Parameter Name : " + calMethod.GetParameters().ElementAt(0).Name);
                
                //parameter types
                Console.WriteLine("Parameter Type : " + calMethod.GetParameters().ElementAt(0).ParameterType);               
                Console.WriteLine();
           

                object calcObj = myAssembly.CreateInstance("TestLibrary.Test");
                MethodInfo squareMethod = calType.GetMethod("DoWork");
                int result = (int)squareMethod.Invoke(calcObj, new object[] { 5 });
                Console.WriteLine("Square is : " + result);

                Console.ReadKey();
        }
        
    }
}
