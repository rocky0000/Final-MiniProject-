﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clinic.Entity;        //reference for entity class
using Clinic.Exception;     //reference for exception class
using Clinic.DL;            //reference for DL class
using System.Text.RegularExpressions;

namespace Clinic.BL
{
    /// <summary>
    ///  Employee Id - 94174
    ///  Employee Name - Ravikumar singh
    ///  Description - BL for Clinic solution
    ///  Date of creation - 19/09/2016 
    /// </summary>
  
    public class PatientBL
    {
        //function to validate patient data

        public static bool ValidatePatient(Patient patient)
        {
            bool validPatient = true;

            StringBuilder msg = new StringBuilder();
            try
            {

                //validating patient name 
                if (!Regex.IsMatch(patient.PatientName, "[A-Z a-z]+"))
                {
                    msg.Append("Name should have Alphabet only");
                    validPatient = false;
                }

                //validating phone number
                if (!Regex.IsMatch(patient.PatientPhoneNo, "[123456789][0-9]{9}") || patient.PatientPhoneNo.Length>10)
                {
                    msg.Append("Phone number should have 10 digit and it does not start with 0");
                    validPatient = false;
                }

                //validating age
                if (patient.PatientAge <= 0 || patient.PatientAge > 100)
                {
                    msg.Append("Age must be greater than 0 and less than 100");
                    validPatient = false;
                }
                if (validPatient == false)
                {
                    throw new PatientException(msg.ToString());
                }
            }

            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }

        //adding patient
        public static bool AddPatient(Patient newpatient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newpatient))
                {
                    patientAdded = PatientDL.AddPatient(newpatient);
                }
                else
                {
                    throw new PatientException("please provide valid data for patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //search patient
        public static Patient SearchPatient(int patientID)
        {
            Patient patientSearched = null;
            try
            {
                patientSearched = PatientDL.SearchPatient(patientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }


        //serializing patient
        public static bool SerializePatient()
        {
            bool patientSerialized = false;

            try
            {
                patientSerialized = PatientDL.SerializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            return patientSerialized;
        }


        //deserializing patient
        public static List<Patient> DeserializePatient()
        {
            List<Patient> patientList = null;

            try
            {
                patientList = PatientDL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientList;
        }

    }
}
