﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clinic.Entity;        //reference for entity class
using Clinic.Exception;     //reference for exception class
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Clinic.DL
{
    /// <summary>
    ///  Employee Id - 94174
    ///  Employee Name - Ravikumar singh
    ///  Description - DL for Clinic solution
    ///  Date of creation - 19/09/2016 
    /// </summary>
    public class PatientDL
    {
        static List<Patient> patientList = new List<Patient>();

        //Adding patient informations new patients

        public static bool AddPatient(Patient newpatient)
        {
            bool patientAdded = false;
            try
            {
                //adding patient
                patientList.Add(newpatient);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //searching patient details
        public static Patient SearchPatient(int patientID)
        {
            Patient patientSearch = null;
            try
            {
                //searching patient
                patientSearch = patientList.Find(patient => patient.PatientID == patientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearch;
        }

        //serializing patient class

        public static bool SerializePatient()
        {
            bool patientSerialize = false;
            try
            {
                if (patientList.Count > 0)
                {
                    FileStream fs = new FileStream(@"..\..\Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binFormat = new BinaryFormatter();
                    binFormat.Serialize(fs, patientList);
                    patientSerialize = true;
                    fs.Flush();
                    fs.Close();
                }
                else
                {
                    throw new PatientException("no patient data to serialize");
                }

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialize;

        }

        //deserializing patient class
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPatient = null;
            try
            {
                FileStream fs = new FileStream(@"..\..\Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormat = new BinaryFormatter();
                desPatient = (List<Patient>)binFormat.Deserialize(fs);
                fs.Flush();
                fs.Close();
            }
            catch (PatientException ex)
            { throw ex; }
            catch (SystemException ex)
            { throw ex; }
            return desPatient;
        }

    }
}
