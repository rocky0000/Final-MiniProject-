﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clinic.Exception
{
    /// <summary>
    ///  Employee Id - 94174
    ///  Employee Name - Ravikumar singh
    ///  Description - Exception for Patient class
    ///  Date of creation - 19/09/2016 
    /// </summary>


    public class PatientException : ApplicationException
    {
        public PatientException()
            : base()
        { }
        public PatientException(string msg)
            : base(msg)
        { }


    }
}
