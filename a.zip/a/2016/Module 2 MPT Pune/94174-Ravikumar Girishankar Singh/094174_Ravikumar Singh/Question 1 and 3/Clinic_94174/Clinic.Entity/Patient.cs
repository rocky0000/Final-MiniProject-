﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clinic.Entity
{
    /// <summary>
    ///  Employee Id - 94174
    ///  Employee Name - Ravikumar singh
    ///  Description - properties/entity for Patient
    ///  Date of creation - 19/09/2016 
    /// </summary>

    [Serializable]
    public class Patient
    {
        //Properties for patient details

        //get or set patient id
        public int PatientID { get; set; }

        //get or set patient name
        public string PatientName { get; set; }

        //get or set patient age
        public int PatientAge { get; set; }

        //get or set patient phone number
        public string PatientPhoneNo { get; set; }
    }
}
