﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clinic.Entity;        //reference for entity class
using Clinic.Exception;     //reference for exception class
using Clinic.BL;            //reference for BL class

namespace PatientPL
{   
    /// <summary>
    ///  Employee Id - 94174
    ///  Employee Name - Ravikumar singh
    ///  Description - PL for Clinic solution
    ///  Date of creation - 19/09/2016 
    /// </summary>
    
    class PatientPL
    {
        static int PatientID = 101;

        //adding patient details
        public static void AddPatient()
        {

            Patient newPatient = new Patient();
            try
            {
                Console.WriteLine("PatientId is: " + PatientID);                              
                Console.WriteLine("Enter Patient Name");
                newPatient.PatientName = Console.ReadLine();
                Console.WriteLine("Enter Patient Age");
                newPatient.PatientAge = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Patient's Phone Number");
                newPatient.PatientPhoneNo = Console.ReadLine();


                bool patientAdded = PatientBL.AddPatient(newPatient);

                if (patientAdded == true)
                {
                    newPatient.PatientID = PatientID++; 
                    Console.WriteLine("Patient details added successfully");
                }
                else
                {
                    throw new PatientException("patient details not added");
                }


            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //searching patient details

        public static void SearchPatient()
        {
            try
            {
                int patientID;
                Console.WriteLine("Enter Patient id to be searched");
                patientID = Convert.ToInt32(Console.ReadLine());

                Patient patient = PatientBL.SearchPatient(patientID);
                if (patient != null)
                {
                    Console.WriteLine("Patient Id" + patient.PatientID);
                    Console.WriteLine("Patient name" + patient.PatientName);
                    Console.WriteLine("Employee Age" + patient.PatientAge);
                    Console.WriteLine("Patient Phone no" + patient.PatientPhoneNo);                 
                }
                else
                {
                    throw new PatientException(" Patient with Id" + patientID + "not found ");
                }

            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //print menu for user
        public static void PrintMenu()
        {
            Console.WriteLine("\n************************");
            Console.WriteLine("1. Add Patient");
            Console.WriteLine("2. Search Patient");            
            Console.WriteLine("3. Serialize Patient");
            Console.WriteLine("4. Deserialize Patient");
            Console.WriteLine("5. Exit");
            Console.WriteLine("************************");
        }


        //serializing patient data
        public static void SerializePatient()
        {
            try
            {
                bool patientSerialized = PatientBL.SerializePatient();
                if (patientSerialized)
                    Console.WriteLine("Patient data is serialized");
                else
                    throw new PatientException("Patient Data is not Serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //deserializing patient data
        public static void Deserializepatient()
        {
            try
            {
                List<Patient> patientList = PatientBL.DeserializePatient();

                if (patientList != null)
                {
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("Patient ID \t Patient Name \t\t Patient Age \t\t Phone No ");
                    Console.WriteLine("************************************************************************************");
                    foreach (Patient patient in patientList)
                    {
                        Console.WriteLine(patient.PatientID + "\t\t" + patient.PatientName + "\t\t\t\t" + patient.PatientAge + "\t\t" + patient.PatientPhoneNo);
                    }
                }
                else
                    throw new PatientException("patient data is not available");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void Main(string[] args)
        {
            int choice = 0;           
            try
            {
                do
                {
                    //displaying print menu
                    PrintMenu();
                    Console.WriteLine("Please Enter Your Choice");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;
                        case 2: SearchPatient();
                            break;                       
                        case 3: SerializePatient();
                            break;
                        case 4: Deserializepatient();
                            break;
                        case 5: Environment.Exit(0);
                            break;

                        default: Console.WriteLine("Please Provide Valid Choice");
                            break;
                    }

                }
                while (choice != 5);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();

        }
    }
}
