﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Patient_Entity;//Reference to patient entity class
using Patient_Exception;//Reference to Patient exception class
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Patient_DAL
{
    /// <summary>
    /// Employee ID : 848800
    /// Employee Name: Shubham Padamwar
    /// Descriprion : This is Data Access Layer class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class Patient_DAL_class
    {

        static List<Patient_entity_class> patient_list = new List<Patient_entity_class>();

        //To insert new patient details to the list of patients
        public static bool AddPatient(Patient_entity_class newpatient)
        {
            bool patientAdded = false;

            try
            {
                //Adding employee
                patient_list.Add(newpatient);
                patientAdded = true;
            }
            catch (Patient_exception_class ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }


        //To search existing patient details from the list of patients
        public static Patient_entity_class PatientSearch(string patientname)
        {
            Patient_entity_class patientFound = null;
            try
            {
                //searching patient in list of patients
                patientFound = patient_list.Find(pati => pati.Patientname == patientname);
                if (patientFound != null)
                {
                    return patientFound;
                }
                else
                {
                    throw new Patient_exception_class("Patient name : " + patientname + " not found in Patients list");
                }
            }
            catch (Patient_exception_class ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }


        //To serialize the list of patient
        public static bool Serializepatient()
        {
            bool patiserialized = false;
            try
            {
                if (patient_list.Count > 0)
                {
                    FileStream fs = new FileStream(@"..\..\Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binform = new BinaryFormatter();
                    binform.Serialize(fs, patient_list);
                    patiserialized = true;
                    fs.Flush();
                    fs.Close();
                }
                else
                {
                    throw new Patient_exception_class("No Patient data found, so cannot serialize");
                }
            }
            catch (Patient_exception_class ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patiserialized;
        }


        //To deserialize the list of patient and display
        public static List<Patient_entity_class> DeserializedPatient()
        {
            List<Patient_entity_class> despati_list = null;
            try
            {
                FileStream fs = new FileStream(@"..\..\Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binform = new BinaryFormatter();
                despati_list = (List<Patient_entity_class>)binform.Deserialize(fs);
                fs.Flush();
                fs.Close();
            }
            catch (Patient_exception_class ex)
            {
                throw new Patient_exception_class("File not Found");
            }
            catch (SystemException ex)
            {
                throw new Patient_exception_class("File not Found");
            }
            return despati_list;
        }
    }
}
