﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Patient_Entity;//Reference to patient entity class
using Patient_Exception;//Reference to Patient exception class
using Patient_DAL;//Reference to Data Access Layer of Patient
using System.Text.RegularExpressions;

namespace Patient_BL
{
    /// <summary>
    /// Employee ID : 848800
    /// Employee Name: Shubham Padamwar
    /// Descriprion : This is Business Layer class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class Patient_BL_class
    {
        //Function to validate patient data
        public static bool ValidatePatient(Patient_entity_class pati)
        {
            bool validpatient = true;
            StringBuilder msg = new StringBuilder();

            try
            {
                //validating patient age
                if (pati.Patientage < 0 || pati.Patientage > 100)
                {
                    msg.Append("Patient age cannot be negative and greater then 100\n");
                    validpatient = false;
                }

                //validating patient name it should be alphabetic 
                if (!Regex.IsMatch(pati.Patientname , "[A-Za-z]+"))
                {
                    msg.Append("Patient name should have alphabets only\n");
                    validpatient = false;
                }

                //validating patient phone number 
                if (!Regex.IsMatch(pati.Patientnumber, "[1-9][0-9]{9}"))
                {
                    msg.Append("Phone number should have 10 digit and cannot begin with zero\n");
                    validpatient = false;
                }

                if (validpatient == false)
                {
                    throw new Patient_exception_class(msg.ToString());
                }
            }
            catch (Patient_exception_class ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validpatient;
        }
        //End of validate Function

        //function to add patient in list of patients
        public static bool AddPatient(Patient_entity_class newpati)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newpati))
                {
                    patientAdded = Patient_DAL_class.AddPatient(newpati);
                }
                else
                {
                    throw new Patient_exception_class("Please provide valid data for patient");
                }

            }
            catch (Patient_exception_class ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }
        //End of Addpatient Function

        //function to search patient in list of patients
        public static Patient_entity_class PatientSearch(string patiname)
        {
            Patient_entity_class patientsearched = null;
            try
            {
                patientsearched = Patient_DAL_class.PatientSearch(patiname);
            }
            catch (Patient_exception_class ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientsearched;
        }
        //End of PatientSearch Function

        //Method to serialize patient list
        public static bool Serializedpatient()
        {
            bool patiserialized = false;
            try
            {
                patiserialized = Patient_DAL_class.Serializepatient(); 
            }
            catch (Patient_exception_class ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patiserialized;
        }
        //End of Serializedpatient Method

        //Method to deserialize the patients list
        public static List<Patient_entity_class> deserializedpatient()
        {
            List<Patient_entity_class> patientserialized_list = null;
            try
            {
                patientserialized_list = Patient_DAL_class.DeserializedPatient();
            }
            catch (Patient_exception_class ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientserialized_list;
        }
        //End of deserializedpatient Method
    }
}
