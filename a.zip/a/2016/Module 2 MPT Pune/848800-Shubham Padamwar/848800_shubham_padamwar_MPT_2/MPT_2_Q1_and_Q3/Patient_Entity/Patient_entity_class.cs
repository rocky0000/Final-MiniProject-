﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patient_Entity
{
    /// <summary>
    /// Employee ID : 848800
    /// Employee Name: Shubham Padamwar
    /// Descriprion : This is entity class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    [Serializable]
    public class Patient_entity_class
    {
        int patientid;
        string patientname;
        string patientnumber;
        int patientage;

        //Property to autogenerate patientID
        public int Patientid
        {
            get { return patientid; }
            set { patientid = value; }
        }

        //Property to get or set patient age
        public int Patientage
        {
            get { return patientage; }
            set { patientage = value; }
        }

        //Property to get or set patient name
        public string Patientname 
        { 
            get {return patientname; }
            set{ patientname = value; }
        }

       //Property to get or set patient number
        public string Patientnumber 
        { 
            get {return patientnumber; }
            set {patientnumber = value; }
        }
    }
}
