﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patient_Exception
{
    /// <summary>
    /// Employee ID : 848800
    /// Employee Name: Shubham Padamwar
    /// Descriprion : This is Exception class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class Patient_exception_class :ApplicationException
    {
         //constructor with no parameter
        public Patient_exception_class()
            : base()
        { }

        //display exception msg
        public Patient_exception_class(string msg)
            : base(msg)
        { }

    }
}
