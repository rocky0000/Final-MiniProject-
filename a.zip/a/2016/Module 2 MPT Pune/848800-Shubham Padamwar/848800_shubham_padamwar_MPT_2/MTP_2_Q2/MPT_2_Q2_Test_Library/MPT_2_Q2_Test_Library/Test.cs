﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MPT_2_Q2_Test_Library
{
    public class Test
    {
        //Function which accept integer and returns square of it
        public int DoWork(int parameter)
        {
            int sq;//To hold square of parameter
            sq = parameter * parameter;
            return sq;
        }
    }
}
