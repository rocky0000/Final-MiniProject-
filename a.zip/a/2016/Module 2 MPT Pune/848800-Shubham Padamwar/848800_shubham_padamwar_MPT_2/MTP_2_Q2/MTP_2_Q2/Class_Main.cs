﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace MTP_2_Q2
{
    class Class_Main
    {
        
        static void Main(string[] args)
        {
            //User defined Assembly
            Assembly myAssembly = Assembly.LoadFrom("MPT_2_Q2_Test_Library.dll");

            //To get type of user defined assembly
            Type sqtype = myAssembly.GetType("MPT_2_Q2_Test_Library.Test");

            //Stores the methods used in User defined Assembly
            MethodInfo[] sqMethod = sqtype.GetMethods();

            int range = 0;
            foreach (MethodInfo m in sqMethod)
            {
                range++;
                Console.WriteLine();
                Console.WriteLine("Method Name : " + m.Name);
                Console.WriteLine("Return Type : " + m.ReturnType.Name);
                Console.WriteLine("Is Static : " + m.IsStatic);

                if (range == 1)//As only DoWork method contains parameter whereas ToString , Equals ,etc does not contain parameter it gives exception 
                {
                    Console.WriteLine("Parameter Name : " + m.GetParameters().ElementAt(0).Name);
                    Console.WriteLine("Parameter Type : " + m.GetParameters().ElementAt(0).ParameterType);
                }    
            }

            Console.WriteLine();
            //DoWrok method is non-static hence object reference is required
            object my_sq = myAssembly.CreateInstance("MPT_2_Q2_Test_Library.Test");

            //To access DoWork method defined in MPT_2_Q2_Test_Library.Test
            MethodInfo dowork_method = sqtype.GetMethod("DoWork");

            Console.WriteLine("Enter a number whose square you want to find:");
            int para = Convert.ToInt32(Console.ReadLine());

            //Display square of given number
            int sq_result = (int)dowork_method.Invoke(my_sq, new object[] {para});
            Console.WriteLine("Square of the given number is :" + sq_result);
        }
    }
}
