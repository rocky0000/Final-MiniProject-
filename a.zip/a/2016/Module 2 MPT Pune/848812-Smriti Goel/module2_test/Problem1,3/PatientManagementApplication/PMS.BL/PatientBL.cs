﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using PMS.Exception;//reference to employee Exception
using PMS.Entity;//reference to employee Entity
using PMS.DAL;//reference to employee Data Access Library

namespace PMS.BL
{
    /// <summary>
    /// Employee ID: 848812
    /// Employee Name:Smriti Goel
    /// Description:This is BL class for Employee
    /// Date of Creation: 19/09/2016
    /// </summary>
    public class PatientBL
    {
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to Validate Patient
        /// Date of creation:19/09/2016
        /// </summary>        
        public static bool ValidatePatient(Patient patient)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();
            try
            {
                //Checking if the patient Name contains aphabets only                
                if (!Regex.IsMatch(patient.PatientName, "[A-Z][a-z]{3}"))
                {
                    msg.Append("Patient Name should have aphabets and spaces only.It should start with capital letter.\n");
                    validPatient = false;
                }
                //Checking if the patient phone no. have 9 digits and should start with 7/8/9   
                if (!Regex.IsMatch(patient.PhoneNo, "[789][0-9]{9}"))
                {
                    msg.Append("Phone Number should have 9 digits. It should start with 7/8/9.\n");
                    validPatient = false;
                }
                //Checking if the patient age is not less than 0 and greater than 100
                if (patient.Age > 100 || patient.Age < 0)
                {
                    msg.Append("Patient age should between 0 to 100\n");
                    validPatient = false;
                }

                if (validPatient == false)
                    throw new PatientException(msg.ToString());

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }

        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to add new patient to the list of patients
        /// Date of creation:19/09/2016
        /// </summary>
        public static bool AddPatient(Patient patient)
        {

            bool patientAdded = false;
            try
            {
                //validating patient
                if (ValidatePatient(patient))
                {
                    patientAdded = PatientDAL.AddPatient(patient);
                }
                else
                    throw new PatientException("Please provide valid data for patient");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to search patient in the list of patients
        /// Date of creation:19/09/2016
        /// </summary>
        public static Patient SearchPatient(int patientID)
        {
            Patient patientSearched = null;
            try
            {
                //Calling searchPatient in DAL of patient
                patientSearched = PatientDAL.SearchPatient(patientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to serialize patients in the list of patients
        /// Date of creation:19/09/2016
        /// </summary>        
        public static bool SerializePatient()
        {
            bool patientSerialized = false;
            try
            {
                //Calling serializePatient in DAL of patient
                patientSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to deserialize patients in the list of patients
        /// Date of creation:19/09/2016
        /// </summary> 
        public static List<Patient> DeserializePatient()
        {
            List<Patient> patientList = null;
            try
            {
                //Calling deserializePatient in DAL of patient
                patientList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientList;
        }
    }
}

