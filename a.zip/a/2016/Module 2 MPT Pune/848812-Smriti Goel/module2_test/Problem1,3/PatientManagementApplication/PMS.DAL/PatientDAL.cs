﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Entity;//reference to patient Entity
using PMS.Exception;//reference to patient Exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace PMS.DAL
{
    /// <summary>
    /// Employee ID: 848812
    /// Employee Name:Smriti Goel
    /// Description:This is DAL class for Patient
    /// Date of Creation: 19/09/2016
    /// </summary>
    public class PatientDAL
    {
        public static List<Patient> patientList = new List<Patient>();
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to add new patient to the list of patients
        /// Date of creation:19/09/2016
        /// </summary>        
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                //Adding Patient
                patientList.Add(newPatient);
                patientAdded = true;               
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to search patient in the list of patients
        /// Date of creation:19/09/2016
        /// </summary>
        public static Patient SearchPatient(int patientID)
        {
            Patient patientSearched = null;
            try
            {
                //searching patient
                patientSearched = patientList.Find(patient => patient.PatientID == patientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to serialize list of patients
        /// Date of creation:19/09/2016
        /// </summary>
        public static bool SerializePatient()
        {
            bool patientSerialize = false;
            try
            {
                //checking if the entries are present in the list else throwing exception
                if (patientList.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binFormat = new BinaryFormatter();
                    //serializing patient data
                    binFormat.Serialize(fs, patientList);
                    fs.Close();
                    patientSerialize = true;
                }

                else throw new PatientException("No patient data cannot serialize");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialize;
        }
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to deserialize list of employees
        /// Date of creation:19/09/2016
        /// </summary>
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPatient = null;
            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormat = new BinaryFormatter();
                // deserializing patient data
                desPatient = (List<Patient>)binFormat.Deserialize(fs);
                
                fs.Close();

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return desPatient;
        }
       
    }
}
