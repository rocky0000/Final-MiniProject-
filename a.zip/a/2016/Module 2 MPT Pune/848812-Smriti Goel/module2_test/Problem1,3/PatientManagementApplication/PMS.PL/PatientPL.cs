﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Exception;//reference to patient Exception
using PMS.Entity;//reference to patient Entity
using PMS.DAL;//reference to patient Data access library
using PMS.BL;//reference to patient Business access library
namespace PMS.PL
{
    /// <summary>
    /// Employee ID: 848812
    /// Employee Name:Smriti Goel
    /// Description:This is PL class for patient
    /// Date of Creation: 19/09/2016
    /// </summary>
    public class PatientPL
    {
        public static int count=1;
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to add new patient to the list of patients
        /// Date of creation:19/09/2016
        /// </summary>        
        public static void AddPatient()
        {
            Patient newPatient = new Patient();
            try
            {
                //taking input data from user
                newPatient.PatientID = count++;
                Console.Write("Patient name:");
                newPatient.PatientName = Console.ReadLine();
                Console.Write("Enter Phone no:");
                newPatient.PhoneNo = Console.ReadLine();
                Console.Write("Enter Age:");
                newPatient.Age = Convert.ToInt32(Console.ReadLine());
                bool patientAdded = PatientBL.AddPatient(newPatient);
                if (patientAdded)
                    Console.WriteLine("Patient Added sucessfully");
                else
                    throw new PatientException("patient not added");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to search patient in the list of patients
        /// Date of creation:19/09/2016
        /// </summary>
        public static void SearchPatient()
        {
            try
            {
                int patientID;
                Console.WriteLine("Enter patientID for patient");
                patientID = Convert.ToInt32(Console.ReadLine());

                //searching the input data by calling searchpatient in PatientBL
                Patient patient = PatientBL.SearchPatient(patientID);

                //checking whether record is present or not
                if (patient != null)
                {
                    Console.WriteLine("Patient ID: " + patient.PatientID);
                    Console.WriteLine("Patient Name: " + patient.PatientName);
                    Console.WriteLine("Phone number: " + patient.PhoneNo);
                    Console.WriteLine("Age: " + patient.Age);
                }
                else throw new PatientException("Patient not found with PatientID " + patientID);
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to serialize list of patient
        /// Date of creation:19/09/2016
        /// </summary>
        public static void SerializePatient()
        {
            try
            {
                bool patientSerialized = PatientBL.SerializePatient();
                if (patientSerialized)
                    Console.WriteLine("Patient data is serialized");
                else throw new PatientException("patient data is not serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to deserialize list of patients
        /// Date of creation:19/09/2016
        /// </summary>
        public static void DeserializedPatient()
        {
            try
            {
                List<Patient> patientList = PatientBL.DeserializePatient();
                //checking whether record are present in list or not
                if (patientList != null)
                {
                    foreach (var patient in patientList)
                    {
                        Console.WriteLine("Patient ID: " + patient.PatientID);
                        Console.WriteLine("Patient Name: " + patient.PatientName);
                        Console.WriteLine("Phone number: " + patient.PhoneNo);
                        Console.WriteLine("Age: " + patient.Age);
                    }

                }
                else
                    throw new PatientException("There is no patient data");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to print menu
        /// Date of creation:19/09/2016
        /// </summary>
        public static void PrintMenu()
        {
            Console.WriteLine("*****************************************************************\n 1.Add Patient\n 2.Search Patient\n 3.Serialize patient\n 4.Deserialize patient\n 5.exit\n*****************************************************************");
        }
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description: Main to input choice from user
        /// Date of creation:19/09/2016
        /// </summary>
        static void Main(string[] args)
        {
            int choice = 0;
            try
            {
                do
                {
                    PrintMenu();

                    //inputting choice of the menu from the user
                    Console.Write("\nenter your choice:");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: AddPatient(); break;
                        case 2: SearchPatient(); break;
                        case 3: SerializePatient(); break;
                        case 4: DeserializedPatient(); break;
                        case 5: Environment.Exit(0); break;
                        default: Console.WriteLine("Please provide valid choice"); break;
                    }
                } while (choice != 8);
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

    }
}

