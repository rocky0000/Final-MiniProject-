﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Exception
{
    /// <summary>
    /// employeeID:848812
    /// Employee Name:Smriti Goel
    /// Description:This is Exception class for Patient
    /// Date of creation:19/09/2016
    /// </summary>
    public class PatientException: ApplicationException
    {
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:constructor to override base class constructor
        /// Date of creation:19/09/2016
        /// </summary>
        public PatientException()
            : base()
        { }
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:constructor to override base class constructor
        /// Date of creation:19/09/2016
        /// </summary>
        public PatientException(string msg)
            : base(msg)
        { }

    }
}
