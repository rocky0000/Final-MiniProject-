﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Entity
{
    [Serializable]
    public class Patient
    {
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:This is Entity class for Patient
        /// Date of creation:19/09/2016
        /// </summary>
        
        //property for get or set PatientID
        public int PatientID { get; set; }
        //property for get or set PatientName
        public string PatientName { get; set; }
        //property for get or set Age
        public int Age { get; set; }
        //property for get or set Phone number
        public string PhoneNo { get; set; }
       
       
    }
}
