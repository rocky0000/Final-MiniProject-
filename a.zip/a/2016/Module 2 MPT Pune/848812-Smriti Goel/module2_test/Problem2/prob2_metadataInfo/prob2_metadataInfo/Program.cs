﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace prob2_metadataInfo
{
    /// <summary>
    /// Employee ID: 848812
    /// Employee Name:Smriti Goel
    /// Description:This is  class for program
    /// Date of Creation: 19/09/2016
    /// </summary>
    class Program
    {
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description: main function to display details of function
        /// Date of creation:19/09/2016
        /// </summary> 
        static void Main(string[] args)
        {
            //creating reference for assembly of prob2_library 
            Assembly myAssembly = Assembly.LoadFrom("Prob2_library.dll");
            Type testType = myAssembly.GetType("Prob2_library.Test");

            MethodInfo testMethod = testType.GetMethod("DoWork");

            Console.WriteLine("Method Name:"+testMethod.Name);
            Console.WriteLine("Return type:" + testMethod.ReturnType);

            if (testMethod.IsStatic)
            {
                Console.WriteLine("The method is static.");
            }
            else
            {
                Console.WriteLine("The method is instance.");
            }

            ParameterInfo[] paraInfo;
            paraInfo=testMethod.GetParameters();
            foreach (var parameter in paraInfo)
	        {
	        Console.Write("Parameter name:" +parameter.Name);
            Console.WriteLine("\tParameter type:" +parameter.ParameterType);	 
	        }            
            Console.ReadKey();
        }
    }
}
