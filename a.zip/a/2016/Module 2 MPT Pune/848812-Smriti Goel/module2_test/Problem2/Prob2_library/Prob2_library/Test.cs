﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prob2_library
{
    /// <summary>
    /// Employee ID: 848812
    /// Employee Name:Smriti Goel
    /// Description:This is  class for test
    /// Date of Creation: 19/09/2016
    /// </summary>
    public class Test
    {
        /// <summary>
        /// employeeID:848812
        /// Employee Name:Smriti Goel
        /// Description:Function to calculate square of a number
        /// Date of creation:19/09/2016
        /// </summary>  
        public int DoWork(int parameter)
        {
            return parameter * parameter;             
        }
    }
}
