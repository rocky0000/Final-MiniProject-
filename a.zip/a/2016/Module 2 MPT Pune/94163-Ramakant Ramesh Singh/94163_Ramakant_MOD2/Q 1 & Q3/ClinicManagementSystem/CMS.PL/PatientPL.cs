﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Entity;       //Reference for Patient Entity
using CMS.Exception;    //Reference for Patient Exception
using CMS.BL;           //Reference for Patient Business Layer

namespace CMS.PL
{
    /// <summary>
    /// Employee ID : 94163
    /// Employee Name : Ramakant Singh
    /// Description : This is Presentation Layer Class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    class PatientPL
    {
        //Function to take values from the user for adding new Patients
        public static void AddPatient()
        {
            Patient newPat = new Patient();

            try
            {
                //Logic for taking details of patient from user using console
                Console.WriteLine("Enter Patient Name: ");
                newPat.PatientName = Console.ReadLine();

                Console.WriteLine("Enter Patient Phone No: ");
                newPat.PhoneNo = Console.ReadLine();

                Console.WriteLine("Enter Patient Age: ");
                newPat.Age = Convert.ToInt32(Console.ReadLine());

                bool PatientAdded = PatientBL.AddPatient(newPat);

                if (PatientAdded)
                {
                    Console.WriteLine("Patient Added succesfully");
                }
                else
                {
                    throw new PatientException("Patient not Added");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to Search Information of a Patient
        public static void SearchPatient()
        {
            try
            {
                Patient newPat = new Patient();
                  
                
                List<Patient> patList = PatientBL.PatientExist();
                if (patList.Count > 0)
                //Logic to Search Information of a Patient
                {
                    int patID;
                    Console.WriteLine("Enter Patient ID of Patient whose information you would like to Search : ");
                    patID = Convert.ToInt32(Console.ReadLine());
                    Patient PatientSearched = PatientBL.SearchPatient(patID);

                    if (PatientSearched != null)
                    {
                        Console.WriteLine("Patient ID: " + PatientSearched.PatientID);
                        Console.WriteLine("Patient Name: " + PatientSearched.PatientName);
                        Console.WriteLine("Patient Phone No: " + PatientSearched.PhoneNo);
                        Console.WriteLine("Patient Age: " + PatientSearched.Age);
                    }
                    else
                        throw new PatientException("Patient ID: " + PatientSearched.PatientID + " is not Found");
                }
                else
                    throw new PatientException("There is no data available for Patient");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to Serialize Information of a Patient
        public static void SerializedPatient()
        {
            try
            {
                //Logic for Serializing Information of a Patient
                bool patSerialized = PatientBL.SerializePatient();

                if (patSerialized)
                    Console.WriteLine("Patient Data is Serialized");
                else
                    throw new PatientException("Patient Data is not serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to Deserialize Information of a Patient
        public static void DeserializedPatient()
        {
            try
            {
                //Logic for Deserializing Information of a Patient
                List<Patient> patDeserialized = PatientBL.DeserializePatient();

                if (patDeserialized != null)
                {
                    Console.WriteLine("Patient Data is Deserialized\n\n");
                    Console.WriteLine("********************************************************************************");
                    Console.WriteLine("Patient ID \t Patient Name \t Patient PhoneNo \t Patient Age");
                    Console.WriteLine("********************************************************************************");
                    foreach (Patient pat in patDeserialized)
                    {
                        Console.WriteLine(+pat.PatientID + "\t\t" + pat.PatientName + "\t\t" + pat.PhoneNo + "\t\t" + pat.Age);
                    }
                }
                else
                    throw new PatientException("Patient Data is not Available");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to Print Menu for Clinic Management System
        public static void PrintMenu()
        {
            Console.WriteLine("\n********************");
            Console.WriteLine("1. Add Patient");
            Console.WriteLine("2. Search Patient");
            Console.WriteLine("3. Serialize");
            Console.WriteLine("4. Deserialize");
            Console.WriteLine("5. Exit");
            Console.WriteLine("********************");

        }
        static void Main(string[] args)
        {

            try
            {
                int choice = 0;
                do
                {
                    PrintMenu();

                    Console.Write("Enter Your Choice : \t");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;

                        case 2: SearchPatient();
                            break;

                        case 3: SerializedPatient();
                            break;

                        case 4: DeserializedPatient();
                            break;

                        case 5: Environment.Exit(0);
                            break;

                        default: Console.WriteLine("Enter Valid Choice");
                            break;

                    }
                }
                while (choice != 5);
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
