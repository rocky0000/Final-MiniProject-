﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Entity;      //Reference to Patient Entity
using CMS.Exception;   //Reference to Patient Exception
using System.IO;        //Loading IO Namespace IO for input output files access
using System.Runtime.Serialization.Formatters.Binary;  //Loading Serialization Namespace for Serialization and Deserialization


namespace CMS.DAL
{
    /// <summary>
    /// Employee ID : 94163
    /// Employee Name : Ramakant Singh
    /// Description : This is Data Access Layer Class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>

    public class PatientDAL
    {
        static List<Patient> patList = new List<Patient>();
        static int patientID = 1;
        //Function to add new Patient to the list of Patients
        public static bool AddPatient(Patient newPat)
        {
            bool PatientAdded = false;

            try
            {

                //Logic for Auto Generation of Patient ID
                newPat.PatientID = patientID;
                patientID++;

                //Logic for Adding Patient
                patList.Add(newPat);

                PatientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return PatientAdded;
        }

        //Function to search a Patient in the list of Patients
        public static Patient SearchPatient(int pID)
        {
            Patient patSearched = null;

            try
            {

                //Logic for searching a Patient
                patSearched = patList.Find(pat => pat.PatientID == pID);
            }

            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return patSearched;
        }

        //Function to Serialize the list of Patients
        public static bool SerializePatient()
        {
            bool patSerialized = false;
            try
            {
                //Logic for Serializing the list of Patients
                if (patList.Count > 0)
                {
                    FileStream fstream = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter br = new BinaryFormatter();
                    br.Serialize(fstream, patList);

                    patSerialized = true;

                    fstream.Close();
                }
                else
                    throw new PatientException("No Patient data to serialize");
            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return patSerialized;
        }

        //Function to Deserialize the list of Patients
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPat = null;

            try
            {
                //Logic for Deserializing the list of Patients
                if (patList.Count > 0)
                {
                    FileStream fstream = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                    BinaryFormatter br2 = new BinaryFormatter();
                    desPat = (List<Patient>)br2.Deserialize(fstream);

                    fstream.Close();
                }
                else
                    throw new PatientException("No Patient data to Deserialize");

            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return desPat;

        }

        public static List<Patient> PatientExist()
        {
            return patList;
        }
    }
}
