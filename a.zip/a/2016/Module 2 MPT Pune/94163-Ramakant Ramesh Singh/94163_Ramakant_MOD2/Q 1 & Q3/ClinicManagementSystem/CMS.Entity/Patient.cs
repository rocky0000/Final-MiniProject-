﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Entity
{
    [Serializable]
    /// <summary>
    /// Employee ID : 94163
    /// Employee Name : Ramakant Singh
    /// Description : This is Entity Class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class Patient
    {
        //Property for Get or Set Patient ID
        public int PatientID { get; set; }

        //Property for Get or Set Patient Name
        public string PatientName { get; set; }

        //Property for Get or Set Patient Age
        public int Age { get; set; }

        //Property for Get or Set Patient PhoneNo
        public string PhoneNo { get; set; }

    }
}
