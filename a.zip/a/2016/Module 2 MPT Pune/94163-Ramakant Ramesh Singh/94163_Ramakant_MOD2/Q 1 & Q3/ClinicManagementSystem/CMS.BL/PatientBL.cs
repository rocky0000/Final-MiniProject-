﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CMS.Entity;       //Reference to Patient Entity
using CMS.Exception;    //Reference to Patient Exception
using CMS.DAL;          //Reference to Patient Data Access Layer

namespace CMS.BL
{
    /// <summary>
    /// Employee ID : 94163
    /// Employee Name : Ramakant Singh
    /// Description : This is BL Class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientBL
    {
        //Function to Validate the Patient data
        public static bool ValidatePatient(Patient pat)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();

            try
            {

                //Logic for Validating Name of the Patient
                if (!Regex.IsMatch(pat.PatientName, "[a-z,A-Z]+"))
                {
                    msg.Append("Patient Name should have alphabets only\n");
                    validPatient = false;
                }

                //Logic for Validating  Phone number of Patient
                if (!Regex.IsMatch(pat.PhoneNo, "[1-9][0-9]{9}"))
                {
                    msg.Append("Phone no should have 10 digits and its first digit should be from 1 to 9 only\n");
                    validPatient = false;
                }

                //Logic for Validating that Patient Age is Between 0 and 100 
                if (pat.Age < 0 || pat.Age > 100)
                {
                    msg.Append("Patient Age should be in between 0 and 100 only \n");
                    validPatient = false;
                }

                if (validPatient == false)
                    throw new PatientException(msg.ToString());

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }

        //Function to validate Patient when added
        public static bool AddPatient(Patient newpat)
        {
            bool patientAdded = false;

            try
            {
                //Logic for validating Add Patient function
                if (ValidatePatient(newpat))
                {
                    patientAdded = PatientDAL.AddPatient(newpat);
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;

        }

        //Function to validate Patient when searched
        public static Patient SearchPatient(int pID)
        {
            Patient patientSearched = null;

            try
            {
                //Logic for validating SearchPatient function
                patientSearched = PatientDAL.SearchPatient(pID);
            }

            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearched;

        }

        //Function to validate Patient when Serialized
        public static bool SerializePatient()
        {
            bool patSerialized = false;
            try
            {
                //Logic for validating SerializePatient function
                patSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return patSerialized;
        }

        //Function to validate Patient when Deserialized
        public static List<Patient> DeserializePatient()
        {
            List<Patient> patDeserialized = null;
            try
            {
                //Logic for validating DeserializePatient function
                patDeserialized = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return patDeserialized;
        }

        public static List<Patient> PatientExist()
        {
            //Logic for validating DisplayAllEmployee function
            List<Patient> patList = PatientDAL.PatientExist();

            return patList;
        }

    }
}
