﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Exception
{
    /// <summary>
    /// Employee ID : 94163
    /// Employee Name : Ramakant Singh
    /// Description : This is Exception Class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientException : ApplicationException
    {
        //UserDefined Exception
        public PatientException()
            : base()
        { }

        //UserDefined Exception Messege
        public PatientException(string msg)
            : base(msg)
        { }

    }
}
