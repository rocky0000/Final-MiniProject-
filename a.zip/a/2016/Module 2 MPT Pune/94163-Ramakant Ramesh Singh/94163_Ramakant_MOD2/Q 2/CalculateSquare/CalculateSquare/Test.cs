﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateSquare
{
    /// <summary>
    /// Employee ID : 94163
    /// Employee Name : Ramakant Singh
    /// Description : This is Test Class Library for Square Application
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class Test
    {
        public int DoWork(int number)
        {
            return (number * number);
        }
    }
}
