﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
namespace Square
{
    /// <summary>
    /// Employee ID : 94163
    /// Employee Name : Ramakant Singh
    /// Description : This is CalcSquare Class for Square Application
    /// Date of Creation : 19/09/2016
    /// </summary>
    class CalcSquare
    {
        static void Main(string[] args)
        {
            //Loads Assembly
            Assembly myAssembly = Assembly.LoadFrom("CalculateSquare.dll");
            Type squareType = myAssembly.GetType("CalculateSquare.Test");

            //Excpetion Handling
            try
            {
                //Logic for Application
                Console.WriteLine("Enter the Number: ");
                int number = Convert.ToInt32(Console.ReadLine());

                // creating Instance for class Test
                object calcObj = myAssembly.CreateInstance("CalculateSquare.Test");
                MethodInfo squareMethod = squareType.GetMethod("DoWork");

                int square = (int)squareMethod.Invoke(calcObj, new object[] { number });

                //Display the details of Method and value in console
                Console.WriteLine("Square of the number is: " + square);
                Console.WriteLine("Method Name: " + squareMethod.Name);
                Console.WriteLine("Return Type of Method " + squareMethod.Name + " is " + squareMethod.ReturnType);
                
                if (squareMethod.IsStatic)
                    Console.WriteLine(squareMethod.Name+" Method is Static ");
                else
                    Console.WriteLine(squareMethod.Name+" Method is Instance  ");
            
                Console.WriteLine(squareMethod.Name+ " Parameters Type and Name: " + squareMethod.GetParameters().GetValue(0));
                
                Console.WriteLine(squareMethod.Name+" Parameter type: " + squareMethod.ReturnParameter);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message+"\nEnter a Valid Number");
            }
           
        }
    }
}
