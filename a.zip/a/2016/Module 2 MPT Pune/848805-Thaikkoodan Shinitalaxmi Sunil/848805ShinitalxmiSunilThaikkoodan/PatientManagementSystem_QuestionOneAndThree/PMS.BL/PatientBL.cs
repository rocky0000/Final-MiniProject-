﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;   //Refernce for Validation
using PMS.Entity;                       //Reference to Patient Entity
using PMS.Exception;                    //Reference to Patient Exception
using PMS.DAL;                          //Reference to Patient DAL

namespace PMS.BL
{
    /// <summary>
    /// Employee Id:848805
    /// Employee Name:Shinitalaxmi T.S.
    /// Description:This is BL(business logic) class for Patient
    /// Date of Creation:16/09/2016
    /// </summary>
    public class PatientBL
    {
        //Function to validate Patient data
        public static bool ValidatePatient(Patient patient)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();
            try
            {
                //Check if Patient Name  does not contains alphabets and does not start with capital
                if (!Regex.IsMatch(patient.PatientName, "[A-Z][a-z]+"))
                {
                    msg.Append("Patient name should have alphabets only and it should start with capital letter \n");
                    validPatient = false;
                }
                //Check if Phone number is not 10 digits or does not start with7/8/9
                if (!Regex.IsMatch(patient.PhoneNo, "[1-9][0-9]{9}"))
                {
                    msg.Append("Phone number should have 10 digits and start with any number except 0 \n");
                    validPatient = false;
                }
                //check if age is not between 18-60.
                if (patient.Age <= 0 || patient.Age > 100)
                {
                    msg.Append("Age should be between below 100 and non-negative\n");
                    validPatient = false;
                }
                

                if (validPatient == false)
                    throw new PatientException(msg.ToString());
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }
        //Function to add a Patient to the Patient list
        public static bool AddPatient(Patient newpatient)
        {
            bool PatientAdded = false;
            try
            {
                if (ValidatePatient(newpatient))
                {
                    newpatient.PatientID = ++Patient.PID;

                    PatientAdded = PatientDAL.AddPatient(newpatient);
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return PatientAdded;
        }
        //Function to Search Patient in the Patient list
        public static Patient SearchPatient(int patientID)
        {
            Patient PatientSearched = null;

            try
            {
                //Use of named argument patientID.
                PatientSearched = PatientDAL.SearchPatient(patientID:patientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return PatientSearched;
        }

        //Function to display all patients
        public static List<Patient> DisplayPatient()
        {
            List<Patient> pList = PatientDAL.DisplayAllPatient();
            return pList;
        }

        //Serialization
        public static bool SerializePatient()
        {
            bool patientSerialized = false;
            try
            {
                patientSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }
        //Deserialize
        public static List<Patient> DeserializePatient()
        {
            List<Patient> patientList = null;
            try
            {
                patientList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientList;
        }
    }
}
