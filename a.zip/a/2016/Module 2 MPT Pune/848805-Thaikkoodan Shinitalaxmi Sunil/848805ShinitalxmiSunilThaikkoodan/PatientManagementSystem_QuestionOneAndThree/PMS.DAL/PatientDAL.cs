﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Entity;                                      //Reference to Patient Entity
using PMS.Exception;                                   //Reference to Patient Exception
using System.IO;                                       //Refernce For File IO
using System.Runtime.Serialization.Formatters.Binary;  //Refernce to Binary Formatter

namespace PMS.DAL
{
    /// <summary>
    ///Employee Id:848805
    /// Employee Name:Shinitalaxmi T.S.
    /// Description:This is DALclass for Patient
    /// Date of Creation:19/09/2016
    /// </summary>
    public class PatientDAL
    {
        static List<Patient> patientList = new List<Patient>();

        //Function to Add new Patient to the list of Patients.
        public static bool AddPatient(Patient newpatient)
        {
            bool PatientAdded = false;

            try
            {
                //Adding Patient.
                patientList.Add(newpatient);
                PatientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return PatientAdded;
        }

        //Function for searching Patient from the list of Patients
        public static Patient SearchPatient(int patientID)
        {
            Patient patientSearched = null;

            try
            {
                //Searching Patient
                patientSearched = patientList.Find(patient => patient.PatientID == patientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //Function to display all Patient IDs along with Patient Name.
        public static List<Patient> DisplayAllPatient()
        {
            return patientList;
        }

        //Function to serialize Patient class
        public static bool SerializePatient()
        {
            bool patientSerialized = false;

            try
            {
                if (patientList.Count > 0)
                {
                    //Creating a stream from the file object.
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                   
                    //Creating an instance of BinaryFormatter.
                    BinaryFormatter binFormat = new BinaryFormatter();
                    
                    //Calling serialize method of the instance passing it stream and object to serialize.
                        binFormat.Serialize(fs, patientList);

                    patientSerialized = true;
                    fs.Flush();
                    fs.Close();

                }
                else
                    throw new PatientException("No Patient Data.So cannot serialize.");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }

        //Function to deserialize Patient class
        public static List<Patient> DeserializePatient()
        {
            List<Patient> despatient = null;
            try
            {
                
                
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormat = new BinaryFormatter();
                despatient = (List<Patient>)binFormat.Deserialize(fs);
                fs.Flush();
                fs.Close();

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return despatient;
        }
    }
}
