﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Employee Id:848805
/// Employee Name:Shinitalaxmi T.S.
/// Description:PMS(Patient Management System)This system allows adding  a new patient and searching a patient.
///             It also performs Serialization to store object state using Binary Serialization.
/// Date of Creation:19/09/2016
/// </summary>
/// 
namespace PMS.Entity
{
    /// <summary>
    /// Patient Id:848805
    /// Patient Name:Shinitalaxmi T.S.
    /// Description:This is Entity class for Patient.
    /// Date of Creation:19/09/2016
    /// </summary>
    [Serializable]
    public class Patient
    {
        public static int PID = 99;
        //Property for Get or Set Patient ID
        public int PatientID { get; set; }

        //Property for Get or Set PatientName
        public string PatientName { get; set; }

        //Property for Get or Set PhoneNo
        public string PhoneNo { get; set; }

        //Property for Get or Set Age
        public int Age { get; set; }

        
    }
}
