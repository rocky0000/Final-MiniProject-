﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Entity;       //reference to Patient Entity
using PMS.Exception;    //reference to Patient Exception
using PMS.BL;           //reference to Eployee Business Layer

namespace PMS.PL
{
    /// <summary>
    /// Employee Id:848805
    /// Employee Name:Shinitalaxmi T.S.
    /// Description:This is Presentation class for Patient
    /// Date of Creation:19/09/2016
    /// </summary>
    class PatientPL
    {
        
       
            //Function to Add a new Patient to the Patient List.
        public static void AddPatient()
        {
            Patient newPatient = new Patient();

            try 
            {
               
                newPatient.PatientID = 0; 
                Console.Write("Enter Patient Name:  ");
                newPatient.PatientName = Console.ReadLine();
                Console.Write("Enter Phone Number:  ");
                newPatient.PhoneNo = Console.ReadLine();
                Console.Write("Enter Age:           ");
                newPatient.Age = Convert.ToInt32(Console.ReadLine());
                

                bool PatientAdded = PatientBL.AddPatient(newPatient);

                if (PatientAdded)
                    Console.WriteLine("Patient Added Successfully!!!\n");
                else
                    throw new PatientException("Patient not added");

            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Search a particular Patient in the Patient list.
        public static void SearchPatient()
        {
            try 
            {
                int patientID;
                DisplayPatient();

                Console.Write("Enter Patient ID for Patient which you would like to search: ");
                patientID = Convert.ToInt32(Console.ReadLine());

                //Use of named argument patientID.
                Patient patient = PatientBL.SearchPatient(patientID:patientID);
                if (patient != null)
                {
                    Console.WriteLine("Patient ID:  " + patient.PatientID);
                    Console.WriteLine("Patient Name:    " + patient.PatientName);
                    Console.WriteLine("Phone number:    " + patient.PhoneNo);
                    Console.WriteLine("Age:             " + patient.Age);
                    Console.WriteLine();
                }
                else
                {
                    throw new PatientException("Patient not found with Patient ID " + patientID);
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to display all Patients
        public static void DisplayPatient()
        {
            try
            {
                List<Patient> patientList = PatientBL.DisplayPatient();
                if (patientList.Count > 0)
                {
                    Console.WriteLine("*****************************************************");
                    Console.WriteLine("Patient ID\t Patient Name ");
                    Console.WriteLine("*****************************************************");
                    foreach (Patient patient in patientList)
                    {
                        Console.WriteLine(patient.PatientID + "\t\t" + patient.PatientName );
                    }
                }
                else throw new PatientException("There is no data available for Patient.");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Serialization Function
        public static void SerializePatient()
        {
            
            try
            {
                bool patientSerialized = PatientBL.SerializePatient();
                if(patientSerialized)
                    Console.WriteLine("Patient data is  serialized");
                else 
                    throw new PatientException("Patient Data is not Serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            
          }

        //Deserialization Function
        public static void DeserializePatient()
        {
            try
            {
                List<Patient> patientList = PatientBL.DeserializePatient();
                if (patientList != null)
                {
                    Console.WriteLine("******************************************************************");
                    Console.WriteLine("Patient ID\t Patient Name\tPhone Number\t\t Age ");
                    Console.WriteLine("******************************************************************");
                    foreach (Patient patient in patientList)
                    {
                        Console.WriteLine(patient.PatientID + "\t\t" + patient.PatientName + "\t\t" + patient.PhoneNo + "\t\t" + patient.Age );
                    }
                }
                else
                    Console.WriteLine("Patient data was not deserialized.");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        //Function to print menu
        public static void PrintMenu()
        {
            Console.WriteLine("*****************************");
            Console.WriteLine("1:Add Patient Details");
            Console.WriteLine("2:Search Patient Details");
            Console.WriteLine("3:Perform Serialization");
            Console.WriteLine("4:Perform DeSerialization");
            Console.WriteLine("5:Exit");
            Console.WriteLine("*****************************");
        }
        static void Main(string[] args)
        {
            int choice = 0;
            try
            {
                do
                {
                    PrintMenu();
                    Console.Write("Enter your choice: ");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;
                        case 2: SearchPatient();
                            break;
                        case 3: SerializePatient();
                            break;
                        case 4: DeserializePatient();
                            break;
                        case 5: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("Please provide valid choice.");
                            break;
                    }
                } while (choice != 5);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
