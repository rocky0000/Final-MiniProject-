﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Exception
{
    /// <summary>
    /// Employee Id:848805
    /// Employee Name:Shinitalaxmi T.S.
    /// Description:This is Exception class for Patient
    /// Date of Creation:19/09/2016
    /// </summary>
    public class PatientException:ApplicationException
    {
        public PatientException() : base() { }
        public PatientException(string msg) 
            :base(msg) { }
    }
}
