﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace TestReflection
{
    /// <summary>
    /// Employee Id:848805
    /// Employee Name:Shinitalaxmi T.S.
    /// Description:The main method prints the metadata for the DoWork method from assembly "TestClassLibrary.dll".
    /// Date of Creation:16/09/2016
    /// </summary>
    class TestReflectionMetadata
    {
        static void Main(string[] args)
        {
            //Loading the assembly
            Assembly myAssembly = Assembly.LoadFrom("TestClassLibrary.dll");

            //Get type information of class Test from the namespace TestClassLibrary
            Type testType = myAssembly.GetType("TestClassLibrary.Test");

            //Get method information about DoWork method
            MethodInfo testMethod = testType.GetMethod("DoWork");
            
            //Printing the method information(metadata)
            Console.WriteLine("Class Name:" + testType.FullName);
            Console.WriteLine("****************************Method Metadata******************************");
            Console.WriteLine("Method Name :        " + testMethod.Name+"\n");
            Console.WriteLine("Return Type :        " + testMethod.ReturnType.Name+"\n");
            Console.WriteLine("Is Static :          " + testMethod.IsStatic+"\n");
            ParameterInfo[] parameters = testMethod.GetParameters();
            foreach (ParameterInfo parameter in parameters)
	            {
                    Console.WriteLine("Parameter Name :    " + parameter.Name+"\n");
                    Console.WriteLine("Parameter Type :    " + parameter.ParameterType+"\n");
	            }
            Console.WriteLine("******************************************************************");

            Console.Write("Enter the value to be squared:   ");
            int number = Convert.ToInt32(Console.ReadLine());
            object testObj = myAssembly.CreateInstance("TestClassLibrary.Test");
            MethodInfo testMethod1 = testType.GetMethod("DoWork");
            int result = (int)testMethod1.Invoke(testObj, new object[] {number});
            
            Console.WriteLine("Squaring of {0} gives=> {1}: " ,number, result);
            Console.ReadKey();

            
        }
    }
}
