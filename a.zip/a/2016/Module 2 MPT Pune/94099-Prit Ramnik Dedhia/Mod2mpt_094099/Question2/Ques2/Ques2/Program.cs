﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Ques2
{
    /// <summary>
    /// Employee ID :094099
    /// Employee Name :Prit Dedhia
    /// Description :Reflection Method for Metadata and Square of the number
    /// Date of Creation :19/09/16
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("The following is the Metadata about the DoWork Method:\n\n");
            Assembly myAssembly = Assembly.LoadFrom("q2Test.dll");
            Type testType = myAssembly.GetType("q2Test.Test");
            MethodInfo[] testMethods = testType.GetMethods();
            //Getting Metadata about the DoWork Method            
            foreach (MethodInfo m in testMethods)
            {
                Console.WriteLine("Method Name : " + m.Name);
                Console.WriteLine("Return type : " + m.ReturnType);
                Console.WriteLine("Static : " + m.IsStatic);
                Console.WriteLine("Parameter Names :" + m.GetParameters());
                Console.WriteLine("Parameter types :" + m.ReturnParameter);
                
                Console.WriteLine();
            }

            //Calling the DoWork Method
            Console.WriteLine("Hence Calling the DoWork Method");
            object calcObjt = myAssembly.CreateInstance("q2Test.Test");
            MethodInfo dwobjt = testType.GetMethod("DoWork");
            int result = (int)dwobjt.Invoke(calcObjt,new object[]{15});
            Console.WriteLine("Square of the Number is :" + result);
            Console.ReadKey();
        }
    }
}
