﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q2Test
{
    /// <summary>
    /// Employee ID :094099
    /// Employee Name :Prit Dedhia
    /// Description :This is the Test Class for DoWork Method
    /// Date of Creation :19/09/16
    /// </summary>
    public class Test
    {
        public int DoWork(int parameter)
        {
            return parameter * parameter;
        }
    }
}
