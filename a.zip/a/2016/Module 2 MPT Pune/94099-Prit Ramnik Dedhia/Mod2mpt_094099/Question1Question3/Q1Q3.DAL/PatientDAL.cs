﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Q1Q3.Entity;  //Reference to Patient Entity
using Q1Q3.Exception;  //Reference to Patient Exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Q1Q3.DAL
{
    /// <summary>
    /// Employee Id :094099
    /// Employee Name :Prit Dedhia
    /// Description :This is DAL Class for Patient
    /// Date of Creation :19/09/16
    /// </summary>
    public class PatientDAL
    {
        static List<Patient> patlist = new List<Patient>();

        //Function to Add New Patient to the list of Patients
        public static bool AddPatient(Patient newPat)
        {
            bool patientAdded = false;
            try
            {
                //Adding Patient
                patlist.Add(newPat);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function for Searching the  Patient Details from the list of Patients
        public static Patient SearchPatient(int patID)
        {
            Patient patSearched = null;
            try
            {
                //Searching for Employee
                patSearched = patlist.Find(pat => pat.PatientID == patID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patSearched;
        }

        //Serialization
        public static bool SerializePatient()
        {
            bool patSerialized = false;

            try
            {
                if (patlist.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binFormat = new BinaryFormatter();
                    binFormat.Serialize(fs, patlist);
                    patSerialized = true;
                    fs.Close();
                }
                else
                    throw new PatientException("No Patient data so cannot serialize");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patSerialized;
        }

        //Deserialization
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPat = null;

            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormat = new BinaryFormatter();
                desPat = (List<Patient>)binFormat.Deserialize(fs);
                fs.Close();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desPat;
        }
    }
}
