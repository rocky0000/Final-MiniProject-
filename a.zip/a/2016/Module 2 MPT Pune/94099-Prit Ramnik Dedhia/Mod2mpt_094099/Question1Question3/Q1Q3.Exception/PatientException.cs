﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1Q3.Exception
{
    /// <summary>
    /// Employee ID :094099
    /// Employee Name :Prit Dedhia
    /// Description : This is Pateint Exception Library
    /// Date of Creation :19/09/16
    /// </summary>
    public class PatientException : ApplicationException
    {
        public PatientException()
            : base()
        { }
        public PatientException(string msg)
            : base(msg)
        { }
    }
}
