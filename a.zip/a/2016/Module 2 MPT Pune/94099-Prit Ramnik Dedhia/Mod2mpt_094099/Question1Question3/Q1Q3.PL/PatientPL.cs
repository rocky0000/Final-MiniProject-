﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Q1Q3.Entity;//Reference for Patient Entity
using Q1Q3.Exception;//Reference for Patient Exception
using Q1Q3.BL;//Reference for Business Layer
using System.Runtime.Serialization;

namespace Q1Q3.PL
{
    /// <summary>
    /// Employee ID :094099
    /// Employee Name :Prit Dedhia
    /// Description :Presentation Layer for Patient Details
    /// Date of Creation :19/09/16
    /// </summary>
    class PatientPL
    {
        //Function to Add Employee in the Employee data
        static int count = 101;        
        public static void AddPatient()
        {
            Patient newPat = new Patient();
            try
            {
                Console.Write("Patient ID generated is :" +count);
                Console.Write("\nEnter the above generated Patient ID :");
                newPat.PatientID = Convert.ToInt32(Console.ReadLine());
                //newPat.PatientID = count;

                Console.Write("\nEnter Patient Name :");
                newPat.PatientName = Console.ReadLine();

                Console.Write("\nEnter Age :");
                newPat.Age = Convert.ToInt32(Console.ReadLine());

                Console.Write("\nEnter Phone Number :");
                newPat.PhoneNo = Console.ReadLine();

                count++;

                bool patientAdded = PatientBL.AddPatient(newPat);

                if (patientAdded)
                    Console.WriteLine("Patient Added Sucessfully");
                else
                    throw new PatientException(" Patient Not Added ");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to Search the Patient from the Employee data
        public static void SearchPatient()
        {
            try
            {
                int patID;
                Console.Write("Enter Patient ID for Patient Which you would like to Search :");
                patID = Convert.ToInt32(Console.ReadLine());
                Patient pat = PatientBL.SearchPatient(patID);
                if (pat != null)
                {
                    Console.WriteLine("Patient ID :" + pat.PatientID);
                    Console.WriteLine("Patient Name :" + pat.PatientName);
                    Console.WriteLine("Age:" + pat.Age);
                    Console.WriteLine("Phone Number :" + pat.PhoneNo);
                }
                else
                    throw new PatientException("Patient does not found with Patient Id"+ patID);
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Serialization
        public static void SerializePatient()
        {
            try
            {
                bool patSerialized = PatientBL.SerializePatient();
                if (patSerialized)
                    Console.WriteLine("Patient data is serialized");
                else
                    throw new PatientException("Patient Data is not Serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Deserialize
        public static void DeserializePatient()
        {
            try
            {
                List<Patient> patList = PatientBL.DeserializePatient();

                if (patList != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("Patient ID   Patient Name       Age \t\t Phone No ");
                    Console.WriteLine("******************************************************************************");
                    foreach (Patient pat in patList)
                    {
                        Console.WriteLine(pat.PatientID + "\t\t" + pat.PatientName + "\t\t" + pat.Age + "\t\t" + pat.PhoneNo);
                    }
                }
                else
                    throw new PatientException("There is not data found");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to Display the Menu
        public static void PrintMenu()
        {
            Console.WriteLine("\n******************************");
            Console.WriteLine("1.Add Patient");
            Console.WriteLine("2.Search Patient");
            Console.WriteLine("3.Serialize Patient");
            Console.WriteLine("4.DeSerialize Patient");
            Console.WriteLine("5.Exit");
            Console.WriteLine("******************************");
        }

        //Main Method
        static void Main(string[] args)
        {
            int choice = 0;
            try
            {
                do
                {
                    PrintMenu();
                    Console.Write("Enter your Choice :");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;
                        case 2: SearchPatient();
                            break;
                        case 3: SerializePatient();
                            break;
                        case 4: DeserializePatient();
                            break;
                        case 5: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("Please Provide valid Choice");
                            break;
                    }
                }
                while (choice != 5);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
