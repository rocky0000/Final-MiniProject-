﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1Q3.Entity
{
    /// <summary>
    /// Employee ID :094099
    /// Employee Name :Prit Dedhia
    /// Description : Entity Class for Patient Details
    /// Date of Creation :19/09/16
    /// </summary>
    
    [Serializable]
    public class Patient
    {
        //Property for Get or Set Patient ID
        public int PatientID { get; set; }

        //Property for Get or Set Patient Name
        public string PatientName { get; set; }

        //Property for Get or Set Patient Age
        public int Age { get; set; }

        //Property for Get or Set Phone No
        public string PhoneNo { get; set; }
        
    }
}
