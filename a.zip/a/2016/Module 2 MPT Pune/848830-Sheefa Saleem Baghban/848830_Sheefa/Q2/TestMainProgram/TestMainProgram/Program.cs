﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace TestMainProgram
{
    class Program
    {

            //Main Function
        static void Main(string[] args)
        {
            int Number = 14;
            int num = SquareTestClass.Test.DoWork(ref Number);
            Console.WriteLine("Square of "+Number+" is : "+num);

            //---------------------------Using Reflections To Print Metadata-----------------------


            //Reference To Square Test Class 
            Assembly myAssembly = Assembly.LoadFrom("SquareTestClass.dll");

            Type testType = myAssembly.GetType("SquareTestClass.Test");

            MethodInfo testMethod = testType.GetMethod("DoWork");

            
            //Printing Method Name Using Reflections...
            Console.WriteLine("\nMethod Name : " +testMethod.Name);

            //Printing Return Type of the Method Using Reflections...
            Console.WriteLine("\nReturn Type of The Method : " + testMethod.ReturnType);

            //Printing Whether Method is Static Or Instance Type Using Reflections...
            Console.WriteLine("\nIs Static Type : " + testMethod.IsStatic+"\n\nHence is Not Of Instance Type!!");


            //Printing Parameter Name of the  Method Using Reflections...
            Console.WriteLine("\nParameter Name : " + testMethod.GetParameters().ElementAt(0).Name);

            //Printing Parameter type of the  Method Using Reflections...
            Console.WriteLine("\nParameter Type : n\n" + testMethod.GetParameters().ElementAt(0).ParameterType);
        }
    }
}
