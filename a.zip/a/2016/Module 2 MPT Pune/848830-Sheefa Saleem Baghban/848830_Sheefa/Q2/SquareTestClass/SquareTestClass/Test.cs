﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SquareTestClass
{
    public class Test
    {
        /// <summary>
        /// Employee ID :   848830
        /// Employee Name : Sheefa Baghban
        /// Description : Test Class Library
        /// Date Of Creation : 19/09/2016
        /// </summary>


        //Function to Calculate square of the Number Passed as parameter
        //using ref Parameter
        public static int DoWork(ref int Number)
        {
            int Square_of_Number;
            Square_of_Number = Number * Number;
            return Square_of_Number;
        }
    }
}
