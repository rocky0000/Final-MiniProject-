﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDS.Exception
{
    /// <summary>
    /// Employee ID : 848830
    /// Employee Name : Sheefa Baghban
    /// Description : Exception Class For Patient Details
    /// Date Of Creation : 19/09/2016
    /// </summary>
    

    public class PatientException : ApplicationException
    {
        //Default Constructor for Patient Exception Class
        public PatientException()
            : base()
        { }

        //Parameterized onstructor for Patient Exception Class
        public PatientException(string msg)
            : base(msg)
        { }
    }
}
