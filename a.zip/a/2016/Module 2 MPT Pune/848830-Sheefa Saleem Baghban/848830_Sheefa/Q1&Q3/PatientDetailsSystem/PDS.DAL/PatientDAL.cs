﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDS.Exception; //Reference to Patient Exception
using PDS.Entity;//Reference to Patient Entity
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;//Using Binary Formatters

namespace PDS.DAL
{
    /// <summary>
    /// Employee ID : 848830
    /// Employee Name : Sheefa Baghban
    /// Description : DAL Class For Patient
    /// Date Of Creation : 19/09/2016
    /// </summary>
    public class PatientDAL
    {

        //Creating Collection to store Details of the Patient.
        static List<PatientDetails> patientList = new List<PatientDetails>();

        //Function To Add new Patient to the List of Patients
        public static bool Add_Patient_Details(PatientDetails newPatient)
        {
            bool patientAdded = false;

            try
            {
                //Adding Patient
                patientList.Add(newPatient);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientAdded;
        }

        //Function for Searching An Employee From the List of Employees
        public static PatientDetails Search_Patient_Details(string name)
        {
            PatientDetails patientSearched = null;
            try
            {
                //Searching Patient//using Lamda Expressions
                patientSearched = patientList.Find(patient => patient.PatientName== name);
                    
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearched;
        }

        //Function To Display All Patients From the List of  Patients
        public static List<PatientDetails> DisplayAllPatients()
        {
            return patientList;
        }


        //Function To Serialize Patient Details Class
        public static bool SerializePatient()
        {
            bool patientSerialized = false;

            try
            {
                if (patientList.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    //Using Binary Serialisation 
                    BinaryFormatter binform = new BinaryFormatter();
                    binform.Serialize(fs, patientList);
                    patientSerialized = true;
                    fs.Close();
                }
                else
                    throw new PatientException("No Patient DATA Available...Hence cannot Serialize!!!");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }


        //Function To DeSerialize Patient Details Class
        public static List<PatientDetails> DeserializePatient()
        {
            List<PatientDetails> despatient = null;

            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binform = new BinaryFormatter();
                despatient = (List<PatientDetails>)binform.Deserialize(fs);
                fs.Flush();
                fs.Flush();
                fs.Close();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return despatient;
        }

    }
}
