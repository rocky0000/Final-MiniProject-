﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDS.Entity; //Reference to Patient Details Entity Class
using PDS.Exception; //Reference to Patient Details Exception Class
using PDS.BL;//Reference to Patient Details BL(Business Layer) Class

namespace PDS.PL
{
    /// <summary>
    /// Employee ID : 848830
    /// Employee Name : Sheefa Baghban
    /// Description : Presentation Layer(PL) For Patient Details Class
    /// Date Of Creation : 19/09/2016
    /// </summary>
    
    class PatientPL
    {
        static int count = 101;
        //Function To Add New Patient
        public static void Add_Patient_Details()
        {
            PatientDetails patient = new PatientDetails();

            try
            {
                //Taking Data From the User
                Console.WriteLine("-------------------ENTER PATIENT DETAILS---------------------");
                //AUTO Generating Patient ID
                patient.PatientID = count;
                Console.Write("Name : ");
                patient.PatientName = Console.ReadLine();
                Console.Write("Phone Number : ");
                patient.Phone_Number = Console.ReadLine();
                Console.Write("Age : ");
                patient.PatientAge = Convert.ToInt32(Console.ReadLine());


                bool patientAdded = PatientBL.Add_Patient_Details(patient);


                //Checking if patient Added 
                if (patientAdded)
                {
                    Console.WriteLine("Patient Added Successfully!!!");
                }
                else
                    throw new PatientException("Patient NOT Added!!");
            }

                //Handling Appropriate Exceptions
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function To Search An Employee
        public static void Search_Patient_Details()
        {
            try
            {
               string patientName;
                Console.Write("Enter Name Of The Patient To be Searched : ");
                patientName = Console.ReadLine();

                PatientDetails patient = PatientBL.Search_Patient_Details(patientName);
                //Checking If Patient List is Filled with some Data
                if (patientName != null)
                {
                    Console.WriteLine("-------------------PATIENT DETAILS----------------------");
                    Console.WriteLine("ID : " + patient.PatientID);
                    Console.WriteLine("Name : " + patient.PatientName);
                    Console.WriteLine("Phone Number: " + patient.Phone_Number);
                    Console.WriteLine("Age : " + patient.PatientAge);
                    

                }
                else
                    throw new PatientException("Patient With Patient ID " + patientName + " Not Found!!!!");

            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        //Function to Print the Menu
        public static void PrintMenu()
        {
            Console.WriteLine("\n\n----------------------------PATIENT DETAILS MANAGEMENT SYSTEM---------------");
            Console.WriteLine("\n========== MENU ===========");
            Console.WriteLine("\n\n1. Add Patient Details\n\n2. Search Patient Details\n\n3. Display All Patients\n\n4. Serialize\n\n5. Deserialize\n\n6.Exit");
            Console.WriteLine("\n============================");
        }

        //Function To Display ALL Patients
        public static void DisplayAllPatients()
        {
            try
            {
                List<PatientDetails> patientList = PatientBL.DisplayAllPatients();
                //Printing only if List Contains Data
                if (patientList.Count > 0)
                {
                    Console.WriteLine("=================================================================");
                    Console.WriteLine("Patient ID \t Patient Name \t Phone Number\t\t Age ");
                    Console.WriteLine("=================================================================");

                    foreach (PatientDetails pat in patientList)
                    {
                        Console.WriteLine(pat.PatientID + "\t\t" + pat.PatientName + "\t\t" + pat.Phone_Number + "\t\t" + pat.PatientAge );
                    }
                    Console.WriteLine("=================================================================\n\n");
                }
                else
                    throw new PatientException("No Data Available for Patients!!");

            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        //Function To Serialize Patient Detail Class
        public static void SerializePatients()
        {
            try
            {
                bool patientSerialized = PatientBL.SerializePatient();

                //Checking Object Serialized Properly Or No..
                if (patientSerialized)
                    Console.WriteLine("Patient Data is Serialized!!");
                else
                    throw new PatientException("Patient Data is not Serialized!!");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function To DeSerialize Patient Detail Class

        public static void DeserializePatients()
        {
            try
            {
                List<PatientDetails> patientList = PatientBL.DeserializePatient();
                //  Checking List Before Printing Data
                if (patientList != null)
                {
                    Console.WriteLine("\n\nPrinting Patient Details After Deserializing...\n\n");
                    Console.WriteLine("=================================================================");
                    Console.WriteLine("Patient ID \t Patient Name \t Phone Number\t\t Age ");
                    Console.WriteLine("=================================================================");

                    foreach (PatientDetails pat in patientList)
                    {
                        Console.WriteLine(pat.PatientID + "\t\t" + pat.PatientName + "\t\t" + pat.Phone_Number + "\t\t" + pat.PatientAge );
                    }
                    Console.WriteLine("=================================================================");
                }
                else
                    throw new PatientException("No Data Available for Patients!!");

            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void Main(string[] args)
        {
            int choice = 0;

            try
            {

                do
                {
                    PrintMenu();
                    Console.Write("\n Enter Your Choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1: Add_Patient_Details();
                                count++; //AUTO Incrementing only After Patient Added Successfully!!
                                break;
                        case 2: Search_Patient_Details();
                                break;
                        case 3: DisplayAllPatients();
                                break;
                        case 4: SerializePatients();
                                break;
                        case 5: DeserializePatients();
                                break;
                        case 6: Environment.Exit(0);
                                break;
                        
                        default: Console.WriteLine("Please Enter A Valid Choice!!!");
                            break;
                    }
                } while (choice != 6);

            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
