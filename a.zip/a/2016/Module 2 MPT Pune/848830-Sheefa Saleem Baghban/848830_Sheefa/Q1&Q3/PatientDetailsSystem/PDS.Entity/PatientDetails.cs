﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDS.Entity
{
    /// <summary>
    /// Employee ID : 848830
    /// Employee Name : Sheefa Baghban
    /// Description : Entity Class For Patient Details
    /// Date Of Creation : 19/09/2016
    /// </summary>

    //Making Patient Class Serializable
    [Serializable]
    public class PatientDetails
    {
        //declaring variables
        int patientID;
        string patientName;
        int patient_age;
        string phone_no;


        //Property For Get or Set Patient ID
        public int PatientID
        {
            get { return patientID; }
            set { patientID = value; }
        }

        //Property For Get or Set Patient Age
        public int PatientAge
        {
            get { return patient_age; }
            set { patient_age = value; }
        }

        //Property For Get or Set Patient Name
        public string PatientName
        {
            get { return patientName; }
            set { patientName = value; }
        }

        //Property For Get or Set Patient Phone Number
        public string Phone_Number
        {
            get { return phone_no; }
            set { phone_no = value; }
        }
    }
}
