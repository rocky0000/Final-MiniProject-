﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDS.Entity; //Reference to Patient Details Entity Class
using PDS.Exception; //Reference to Patient Details Exception Class
using PDS.DAL;//Reference to Patient Details Data Access Layer Class
using System.Text.RegularExpressions;//Reference To Regular Expression Class

namespace PDS.BL
{
    /// <summary>
    /// Employee ID : 848830
    /// Employee Name : Sheefa Baghban
    /// Description : BL(Business Layer) Class For Patient
    /// Date Of Creation : 19/09/2016
    /// </summary>
    public class PatientBL
    {
        public static bool ValidatePatient(PatientDetails patient)
        {
            bool validPatient = true;
            StringBuilder message = new StringBuilder();

            try
            {
                
                if (!Regex.IsMatch(patient.PatientName, "[A-Za-z]+"))
                {
                    message.Append("\n------------------- !! FORMATS REQUIRED !!----------------\n1.Patient Name should have Alphabets only !! \n");
                    validPatient = false;
                }

                //Validating Phone Number to be of 10 digits and start with either 7 or 8 or 9
                if (!Regex.IsMatch(patient.Phone_Number, "[1-9][0-9]{9}"))
                {
                    message.Append("2.Phone Number Should be 10 digits only and should not start with 0 !! \n");
                    validPatient = false;
                }

                //Validating Age to be between 18-60
                if (patient.PatientAge<0 || patient.PatientAge > 100)
                {
                    message.Append("3.Patient Age should NOT be Negative and Should be Less than 100 only !!\n\n");
                }

                if (validPatient == false)
                    throw new PatientException(message.ToString());
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }

        //Function to Validate the Add Patient Details Function in DAL Layer
        public static bool Add_Patient_Details(PatientDetails newPatient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPatient))
                {
                    patientAdded = PatientDAL.Add_Patient_Details(newPatient);
                    
                }
                else
                {
                    throw new PatientException("Please Provide valid data for the Pateint");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function To Validate Patient SEARCH Function in DAL Layer
        public static PatientDetails Search_Patient_Details(string name)
        {
            PatientDetails patientSearched = null;
            try
            {
                patientSearched = PatientDAL.Search_Patient_Details(name);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
           
            return patientSearched;
        }

        //Function To Validate Patient Display Function
        public static List<PatientDetails> DisplayAllPatients()
        {
            List<PatientDetails> patientList = PatientDAL.DisplayAllPatients();
            return patientList;
        }


        //Function To  Validate Serialize Patient Details Class
        public static bool SerializePatient()
        {
            bool patientSerialized = false;
            try
            {
                patientSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return patientSerialized;
        }


        //Function To  Validate DeSerialize Patient Details Class
        public static List<PatientDetails> DeserializePatient()
        {
            List<PatientDetails> patientList = null;

            try
            {
                patientList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientList;
        }
        

    }
}
