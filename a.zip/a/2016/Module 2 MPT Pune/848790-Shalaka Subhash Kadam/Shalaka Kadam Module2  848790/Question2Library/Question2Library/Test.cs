﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2Library
{
    public class Test
    {
        public int DoWork(int num1)
        {
            int square = num1 * num1;
            return square;
        }
    }
}
