﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;


namespace Quetsion2Reflection
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("Question2Library.dll"); //Loading the Assembly

            Type empType = myAssembly.GetType("Question2Library.Test");

            MethodInfo workMethods = empType.GetMethod("DoWork");

            //Type empType1 = myAssembly.GetType("Question2Library.Test.DoWork");

            //ParameterInfo empParams = empType1.GetType("num1");


            Console.WriteLine("Method Name is : " + workMethods.Name);
            Console.WriteLine("Return Type of Method is : " + workMethods.ReturnType);
            Console.WriteLine("Is  Method Static : " + workMethods.IsStatic);
            Console.WriteLine("Return Parameter of Method : " + workMethods.ReturnParameter);
            Console.WriteLine("Parameter Names : " + workMethods.GetParameters());
            Console.WriteLine("Return Type Name of Method : " + workMethods.ReturnType.Name);
           
            

            object calcObj = myAssembly.CreateInstance("Question2Library.Test"); //Creating an object of Test Class
            MethodInfo testMethod = empType.GetMethod("DoWork");
            int result = (int)testMethod.Invoke(calcObj, new object[] { 8 });
            Console.WriteLine("\n\nSquare of number is : " + result);

           

            Console.ReadKey();
        }
    }
}
