﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Entity
{
    /// <summary>
    /// Employee ID:848790
    /// Employee Name:Shalaka Kadam
    /// Description: This is Entity class for Patient
    /// Date of Creation: 19/09/2016
    /// </summary>

     [Serializable]
    public class Patient
    {
        //Property for Get or Set PatientID
        public int PatientID { get; set; }

        //Property for Get or Set Patientname
        public string Patientname { get; set; }

        //Property for Get or Set Phoneno
        public string Phoneno { get; set; }

        //Property for Get or Set Age
        public int Age { get; set; }
    }
}
