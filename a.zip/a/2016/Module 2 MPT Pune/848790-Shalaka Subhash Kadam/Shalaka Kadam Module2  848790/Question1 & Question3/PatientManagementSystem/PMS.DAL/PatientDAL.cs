﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Entity; // Reference to Patient Entity
using PMS.Exception; //Referenece to Patient Exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace PMS.DAL
{
    /// <summary>
    /// Employee ID:848790
    /// Employee Name:Shalaka Kadam
    /// Description: This is Data Access Layer class for PatientDAL
    /// Date of Creation: 19/09/2016
    /// </summary>
    public class PatientDAL
    {
        static int patientID = 101;

        static List<Patient> patList = new List<Patient>();

        //Function to add new Patient to the list of Patient
        public static bool AddPatient(Patient newPnt)
        {
            bool patientAdded = false;
            try
            {
                newPnt.PatientID = patientID;
                patientID++;

                //Adding New Patient
                patList.Add(newPnt);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return patientAdded;
        }

        //Function to search Patient from the list of Patient
        public static Patient SearchPatient(int patID)
        {
           Patient patSearched = null;

            try
            {
                //Searching Patient
                patSearched = patList.Find(patnt => patnt.PatientID == patID);


            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return patSearched;
        }


        //Function to serialize Patients 
        public static bool SerializePatient()
        {
            bool patserialized = false;
            try
            {
                if (patList.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter bif = new BinaryFormatter();
                    bif.Serialize(fs, patList);
                    patserialized = true;
                    fs.Close();

                }
                else
                    throw new PatientException("No Patient data so cannot serialize");
            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return patserialized;

        }

        //Function to Deserialize Patients 
        public static List<Patient> DeSerializePatient()
        {
            List<Patient> despat = null;

            try
            {

                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bif = new BinaryFormatter();
                despat = (List<Patient>)bif.Deserialize(fs);

                fs.Close();


            }

            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return despat;

        }

    }
}
