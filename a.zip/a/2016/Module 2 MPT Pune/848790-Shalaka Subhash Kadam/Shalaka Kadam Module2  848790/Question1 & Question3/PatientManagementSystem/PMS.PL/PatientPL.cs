﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Exception;//Referenece to Patient Exception
using PMS.Entity; // Reference to Patient Entity
using PMS.BL; // Reference to Patient BL

namespace PMS.PL
{
    /// <summary>
    /// Employee ID:848790
    /// Employee Name:Shalaka Kadam
    /// Description: This is Presentation class for PatientPL
    /// Date of Creation: 19/09/2016
    /// </summary>
    class PatientPL
    {
        public static void AddPatient()
        {
            Patient newPat = new Patient();

            try
            {
                
                Console.WriteLine("Enter Patient name:");
                newPat.Patientname = Console.ReadLine();
                Console.WriteLine("Enter Phone no:");
                newPat.Phoneno = Console.ReadLine();
                Console.WriteLine("Enter age:");
                newPat.Age= Convert.ToInt32(Console.ReadLine());


                bool patientAdded = PatientBL.AddPatient(newPat);

                if (patientAdded)
                    Console.WriteLine("Patient Added Succesfully to the Database");
                else
                    throw new PatientException("Patient was not Added");

            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchPatient()
        {
            try
            {
                int patID;
                Console.WriteLine("Enter PatientID FOR Patient whom you would like to Search:");
                patID = Convert.ToInt32(Console.ReadLine());

                Patient pat = PatientBL.SearchPatient(patID);

                if (pat != null)
                {
                    Console.WriteLine("Patient ID:" + pat.PatientID);
                    Console.WriteLine("Patient Name:" + pat.Patientname);
                    Console.WriteLine("Age:" + pat.Age);
                    Console.WriteLine("Phone number:" + pat.Phoneno);


                }
                else
                {
                    throw new PatientException("Patient not found with " + patID);
                }


            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializePatient()
        {
            try
            {
                bool patSerialized = PatientBL.SerialiizePatient();
                if (patSerialized)
                    Console.WriteLine("Patient data is serialized");
                else
                    Console.WriteLine("Patient data is not Serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeSerializePatient()
        {
            try
            {
                List<Patient> patList = PatientBL.DeSerialiizePatient();

                if (patList != null)
                {
                    Console.WriteLine("******************************************************");
                    Console.WriteLine("Employee ID \t Employee Name \t Age \t Phone no");
                    Console.WriteLine("******************************************************");

                    foreach (Patient pat in patList)
                    {
                        Console.WriteLine(pat.PatientID + "\t\t" + pat.Patientname + "\t\t" + pat.Age + "\t" + pat.Phoneno);
                    }

                }
                else
                    throw new PatientException("Ther is no data to serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("\n******************************************************");
            Console.WriteLine(" 1. Add Patient");          
            Console.WriteLine(" 2. Search Patient");
            Console.WriteLine(" 3. Serialize");
            Console.WriteLine(" 4. Deserialize");
            Console.WriteLine(" 5. Exit");
            Console.WriteLine("******************************************************");
        }



        static void Main(string[] args)
        {
            int choice = 0;
            string option;

            try
            {


                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;                  
                        case 2: SearchPatient();
                            break;
                        case 3: SerializePatient();
                            break;
                        case 4: DeSerializePatient();
                            break;
                        case 5: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("Please Provide Valid Choice");
                            break;
                    }

                    Console.WriteLine("Do you wish to perform more task?");
                    option = Console.ReadLine();

                } while (option == "yes");


            }


            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}

