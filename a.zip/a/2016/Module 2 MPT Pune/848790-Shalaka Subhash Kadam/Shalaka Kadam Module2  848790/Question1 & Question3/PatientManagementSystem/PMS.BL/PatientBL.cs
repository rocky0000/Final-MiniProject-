﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Entity;  // Reference to Patient Entity
using PMS.DAL; // Reference to Patient DAL
using PMS.Exception;//Referenece to Patient Exception
using System.Text.RegularExpressions;

namespace PMS.BL
{
    /// <summary>
    /// Employee ID:848790
    /// Employee Name:Shalaka Kadam
    /// Description: This is Entity class for PatientBL
    /// Date of Creation: 19/09/2016
    /// </summary>
    public class PatientBL
    {
        //Function to validate employee data
        public static bool ValidatePatient(Patient pat)
        {
            bool validPatient = true;

            StringBuilder msg = new StringBuilder();

            try
            {
               

                //Violating Patient Name
                if (!Regex.IsMatch(pat.Patientname, "[A-Z][a-z]+"))
                {
                    msg.Append("\nPatient name should have alphabets and spaces only and it should start with capital letter");
                    validPatient = false;
                }

                //Violating Patient Phone no
                if (!Regex.IsMatch(pat.Phoneno, "[789][0-9]{9}"))
                {
                    msg.Append("\nPhone no. should have 10 digits and it should start with 7 or 8 or 9 \n");
                    validPatient = false;
                }

                //Violating Patient Age
                if (pat.Age < 0 || pat.Age > 100)
                {
                    msg.Append("\nPatient Age should be positive and not  greater then 100");
                    validPatient = false;
                }

               

                if (validPatient == false)
                {
                    throw new PatientException(msg.ToString());
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return validPatient;


        }

        //Validation for adding new Patients
        public static bool AddPatient(Patient newPat)
        {
            bool patientadded = false;
            try
            {
                if (ValidatePatient(newPat))
                {
                    patientadded = PatientDAL.AddPatient(newPat);
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientadded;

        }

        //Validation for searching Patients
        public static Patient SearchPatient(int PatID)
        {
            Patient patientsearched = null;
            try
            {

                patientsearched = PatientDAL.SearchPatient(PatID);

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientsearched;
        }

        //Validation for serialization of Patients
        public static bool SerialiizePatient()
        {
            bool patSerialized = false;

            try
            {
                patSerialized = PatientDAL.SerializePatient();
            }

            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patSerialized;
        }

        //Validation for deserialization of Patients
        public static List<Patient> DeSerialiizePatient()
        {
            List<Patient> empList = null;

            try
            {
                empList = PatientDAL.DeSerializePatient();
            }

            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empList;
        }

    }
}
