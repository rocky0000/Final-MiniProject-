﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibrary
{
    public class Test
    {
        //DoWork method 

        public int DoWork(int num1)
        {
            return num1 * num1;
        }
    }
}