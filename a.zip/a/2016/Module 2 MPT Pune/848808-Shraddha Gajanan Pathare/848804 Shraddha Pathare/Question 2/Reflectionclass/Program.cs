﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;        // Reference for reflection library

namespace Reflectionclass
{
    class Program
    {
        static void Main(string[] args)
        {
            // To create object of assembly and load library

            Assembly myAssembly = Assembly.LoadFrom("ReflectionLibrary.dll");

            Type testType = myAssembly.GetType("ReflectionLibrary.Test");

            MethodInfo[] testMethods = testType.GetMethods();

            // Number to find square of

            Console.Write("Enter the number to find square : ");
           

            int num = Convert.ToInt32(Console.ReadLine());

            //Create instance of the class 

            object sqrObj = myAssembly.CreateInstance("ReflectionLibrary.Test");

            // To load method from class Test

            MethodInfo sqrMethod = testType.GetMethod("DoWork");

            // Fetch the result in variable result1
            int result1 = (int)sqrMethod.Invoke(sqrObj, new object[] { num });

            Console.Write("Square of number is:" + result1);
            Console.WriteLine("\n");

       
            foreach (MethodInfo m in testMethods)
            {
                //Name of method

                Console.WriteLine("Name of methods \t" + m.Name);
                Console.WriteLine("\n");

                //Return Type of Method

                Console.WriteLine("Return Type of Method" +m.ReturnType);
                Console.WriteLine("\n");

                // Static or instance Method

                Console.WriteLine("Is method static : "+ m.IsStatic);
                Console.WriteLine("\n");

                // Names of the parameters 

                Console.WriteLine("Names of the parameters : " +m.GetParameters());
                Console.WriteLine("\n");                       
            }
        }
    }
}
