﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;   // To support regular expressions
using System.Threading.Tasks;
using PMS.Entity;              // Reference to entity class
using PMS.Exception;          // Reference to exception class
using PMS.DAL;               // Reference to DAL class 

namespace PMS.BL
{
    /// <summary>
    /// Employee ID      : 848808
    /// Employee Name    : Shraddha Pathare
    /// Description      : This is Business Layer for Patient Management System
    /// Date of Creation : 19/09/2016
    /// </summary>
    

    public class PatientBL
    {
        //Function to validate the patient data

         public static bool ValidatePatient(Patient pat)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();

            try
            {
                // To check if name is valid

                if (!Regex.IsMatch(pat.PatientName, "[A-Z][a-z ]+"))
                {
                    msg.Append("Patient Name should have alphabets and spaces only and it should start with capital letter\n");
                    validPatient = false;
                }

                // To check if phone number is valid
                if (!Regex.IsMatch(pat.PhoneNo, "[789][0-9]{9}"))
                {
                    msg.Append("Phone No should have 10 digits and it should start with 7 or 8 or 9\n");
                    validPatient = false;
                }

                // Tocheck if age is valid 
                if (pat.Age < 1 || pat.Age > 100)
                {
                    msg.Append("Please enter patient Age within 1 to 100\n");
                    validPatient = false;
                }
                // If validPatient is false throw exception  

                if (validPatient == false)

                    throw new PatientException(msg.ToString());
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validPatient;
        }


                    //Add only if Valid Patient 

         public static bool AddPatient(Patient newPat)
         {
             bool PatientAdded = false;
             try
             {
                 if (ValidatePatient(newPat))
                 {
                     PatientAdded = PatientDAL.AddPatient(newPat);                         
                 }
                 else
                 {
                     throw new PatientException("Please provide valid data for Patient");
                 }
             }
             catch (PatientException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }
             return PatientAdded;
         }

        // Search if valid Patient entered 

         public static Patient SearchEmployee(int patID)
         {
             Patient patientSearched = null;

             try
             {
                 patientSearched = PatientDAL.SearchPatient(patID);                   
             }
             catch (PatientException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }

             return patientSearched;
         }

        // To validate serialization 

         public static bool SerializePatient()
         {
             bool patSerialized = false;

             try
             {
                 patSerialized = PatientDAL.SerializePatient();
                    
             }
             catch (PatientException ex)
             {
                 Console.WriteLine(ex.Message);
             }
             catch (SystemException ex)
             {
                 Console.WriteLine(ex.Message);
             }

             return patSerialized;
         }

        // To validate Deserialization

         public static List<Patient> DeserializePatient()
         {
             List<Patient> patList = null;

             try
             {
                 patList = PatientDAL.DeserializePatient();                   
             }
             catch (PatientException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }

             return patList;
         }
    }
}
