﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Entity;       // Reference to entity class
using PMS.Exception;   // Reference to exception class
using PMS.DAL;        // Reference to DAL class 
using PMS.BL;        // Reference to BL class 

namespace PMS.PL
{
    /// <summary>
    /// Employee ID      : 848808
    /// Employee Name    : Shraddha Pathare
    /// Description      : This is Presentaion Layer for Patient Management System
    /// Date of Creation : 19/09/2016
    /// </summary>
    
    class PatientPL
    {
         public static void AddPatient()
          {
            Patient newpat = new Patient();

            try
            {
                //Console.Write("Enter Patient ID : ");
                //newpat.PatientID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Patient Name : ");
                newpat.PatientName = Console.ReadLine();

                Console.Write("Enter Phone No : ");
                newpat.PhoneNo = Console.ReadLine();

                Console.Write("Enter Age : ");
                newpat.Age = Convert.ToInt32(Console.ReadLine());
            

                bool patientAdded = PatientBL.AddPatient(newpat);
                    
                if (patientAdded)
                    Console.WriteLine("Patient Added Successfully");

                else
                    throw new PatientException("Patient not Added");
             }

                    catch (PatientException ex)
                     {
                         Console.WriteLine(ex.Message);
                     }
                    catch (SystemException ex)
                     {
                Console.WriteLine(ex.Message);
                     }
        }
                    // Function to search patient
            public static void SearchPatient()
            {
            try 
            {
                int patID;
                Console.WriteLine("Patient ID is auto generated and starts with 100");
                Console.Write("Enter Patient ID for Patient Which You Would Like to Search : ");
                patID = Convert.ToInt32(Console.ReadLine());

                Patient pat = PatientBL.SearchEmployee(patID);
                   

                if (pat != null)
                {
                    Console.WriteLine("Patient ID : " + pat.PatientID);
                    Console.WriteLine("Patient Name : " + pat.PatientName);
                    Console.WriteLine("Phone Number : " +pat.PhoneNo);
                    Console.WriteLine("Age : " +pat.Age);
                  
                }
                else
                    throw new PatientException("Patient not found with Patient ID : " + patID);
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
                // Function to serialize patient 
                
          public static void SerializePatient()
          {
            try 
            {
                bool patSerialized = PatientBL.SerializePatient();
                   
                if (patSerialized)
                    Console.WriteLine("Patient data is serialized");
                else
                    throw new PatientException("Patient Data is not Serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

            // Function to Deserialize Patient class

         public static void DeserializePatient()
        {
            try 
            {
                List<Patient> patList = PatientBL.DeserializePatient();
                   
                // If the list is not null deserialize patient list
                if (patList != null)
                {
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("Patient ID \t Patient Name \t Phone No \t Age");
                    Console.WriteLine("************************************************************************************");
                    foreach (Patient pat in patList)
                    {
                        Console.WriteLine(pat.PatientID + "\t\t" + pat.PatientName + "\t\t" + pat.PhoneNo + "\t" + pat.Age);
                    }
                }
                else
                    throw new PatientException("There is not data");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("\n************************");
            Console.WriteLine("1. Add Patient");
            Console.WriteLine("2. Search Patient");
            Console.WriteLine("3. Serialize Patient");
            Console.WriteLine("4. Deserialize Patient");
            Console.WriteLine("5. Exit");          
            Console.WriteLine("************************");
        }

        public static void Main(string[] args)
        {
             int choice = 0;
             try
             {
                 do
                 {
                     PrintMenu();

                     Console.Write("\nEnter Your Choice : ");
                     choice = Convert.ToInt32(Console.ReadLine());

                     switch (choice)
                     {
                         case 1: AddPatient();
                             PatientDAL.count++;
                             break;
                         case 2: SearchPatient();
                             break;

                         case 3: SerializePatient();
                             break;
                         case 4: DeserializePatient();
                             break;
                         case 5: Environment.Exit(0);
                             break;
                     }

                 } while (choice != 5);
             }
             catch (SystemException ex)
             {
                 Console.WriteLine(ex.Message);
             }
            Console.ReadKey();
        }
    }

}


   



    

