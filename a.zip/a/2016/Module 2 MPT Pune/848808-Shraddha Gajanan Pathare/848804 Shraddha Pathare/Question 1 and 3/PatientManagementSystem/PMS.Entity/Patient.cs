﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Entity
{

    /// <summary>
    /// Employee ID      : 848808
    /// Employee Name    : Shraddha Pathare
    /// Description      : This is Entity class for Patient  Management System
    /// Date of Creation : 19/09/2016
    /// </summary>

    [Serializable]         // To make the class serializable 
    public class Patient
    {
        //Property for Get or Set patient ID
        public int PatientID { get; set; }

        //Property for Get or Set patient Name
        public string PatientName { get; set; }

        //Property for Get or Set patient Phone number 
        public string PhoneNo { get; set; }

        //Property for Get or Set patient Age
        public int Age { get; set; } 

    }
}
