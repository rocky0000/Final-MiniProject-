﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Entity;           // Reference to entity class
using PMS.Exception;        // Reference to exception class
using System.IO;
using System.Runtime.Serialization.Formatters.Binary; // Reference to binary formatter

namespace PMS.DAL
{
    /// <summary>
    /// Employee ID      : 848808
    /// Employee Name    : Shraddha Pathare
    /// Description      : This is Data Access Layer for Patient Management System
    /// Date of Creation : 19/09/2016
    /// </summary>
    /// 
    public class PatientDAL
    {
        static List<Patient> patientList = new List<Patient>();

        public static int count = 100;

        //Function to add new Patient to the list of Patient

        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;

            try
            {
                newPatient.PatientID = count;

                //Adding Patient  to list 
                patientList.Add(newPatient);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientAdded;
        }


        //Function for searching Patient from list of Patients

        public static Patient SearchPatient(int patID)
        {
            Patient patientSearched = null;

            try
            {
                //searching patient
                if (patientList.Count > 0)
                {
                    patientSearched = patientList.Find(pat => pat.PatientID == patID);

                }

                else
                    throw new PatientException("No Patient data so cannot search");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearched;
        }

        // Function to serialize Patient Class


        public static bool SerializePatient()
        {
            bool patSerialized = false;

            try
            {
                if (patientList.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binFormat = new BinaryFormatter();
                    binFormat.Serialize(fs, patientList);
                    patSerialized = true;
                    fs.Close();
                }
                else
                    throw new PatientException("No Patient data so cannot serialize");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patSerialized;
        }

        // Function to deserialize patient class
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPat = null;

            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormat = new BinaryFormatter();
                desPat = (List<Patient>)binFormat.Deserialize(fs);
                fs.Flush();
                fs.Close();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desPat;
        }

    }
}
