﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace section2
{
    class Program
    {
        static void Main(string[] args)
        {
            //loading assembly from library
            Assembly myAssembly = Assembly.LoadFrom("TestLibraryreflection.dll");
            Type testType = myAssembly.GetType("TestLibraryreflection.Test");

            //getting the DoWork method in testMethod
            MethodInfo testMethod = testType.GetMethod("DoWork");

            Console.WriteLine("the required metadata is as follows");

            //print the method name
            Console.WriteLine("Method Name : " + testMethod.Name);
            //print return type
            Console.WriteLine("Return Type: " + testMethod.ReturnType);
            //print whether the method is static or instance
            Console.WriteLine("DoWork() is:" + testMethod.IsStatic);
            //print the parameter names of the method
            Console.WriteLine("Parameter Names of DoWork are:" + testMethod.GetParameters().ElementAt(0).Name);
            //print parameter types
            Console.WriteLine("Parameter types are:" + testMethod.GetParameters().ElementAt(0).ParameterType);

            int square;
            object testObj = myAssembly.CreateInstance("TestLibraryreflection.Test");
            //calculating square by invoking method
            square = (int)testMethod.Invoke(testObj, new object[] { 5 });
            //print the result that is square of number
            Console.WriteLine("square of the number is:"+square);
            
        }
    }
}
