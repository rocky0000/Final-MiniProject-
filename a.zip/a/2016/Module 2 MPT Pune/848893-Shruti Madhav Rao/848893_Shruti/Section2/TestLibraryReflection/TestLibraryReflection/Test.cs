﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestLibraryReflection
{
    public class Test
    {

        public int DoWork(int parameter)
        {
            int result;
            result = parameter * parameter;
            return result;
        }
    }
}
