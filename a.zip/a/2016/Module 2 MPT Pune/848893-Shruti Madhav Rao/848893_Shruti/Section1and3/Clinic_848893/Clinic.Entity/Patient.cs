﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clinic.Entity
{
    /// <summary>
    /// Employee Id:848893
    /// Employee Name:Shruti Rao
    /// Desc:Entity Class for Patient
    /// Date of creation:19/09/2016
    /// </summary>
    [Serializable]
    public class Patient
    {
        //get or set property for patient ID
        public int PatientID { get; set; }
        //get or set property for patient name
        public string PatientName { get; set; }
        //get or set property for patient Age
        public int age { get; set; }
        //get or set property for patient Phone number
        public string PhoneNumber { get; set; }
    }
}
