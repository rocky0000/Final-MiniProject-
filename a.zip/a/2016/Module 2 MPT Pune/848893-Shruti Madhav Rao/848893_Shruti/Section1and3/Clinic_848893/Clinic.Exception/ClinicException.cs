﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clinic.Exception
{
    /// <summary>
    /// Employee ID:848893
    /// Employee name:shruti Rao
    /// description:Exception Class for Clinic Management System
    /// Date of creation:19/09/2016
    /// </summary>
    public class ClinicException:ApplicationException
    {
        public ClinicException()
            : base()
        { }
        public ClinicException(string msg)
            :base(msg)
            { }

    }
}
