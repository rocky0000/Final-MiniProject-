﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clinic.Entity;
using Clinic.Exception;
using Clinic.BL;

namespace Clinic.PL
{
    /// <summary>
    /// Employee Id:848893
    /// Employee Name:Shruti Rao
    /// Description:Presentation layer of Clinic Management System
    /// Date of creation:19/09/2016
    /// </summary>
    public class ClinicPL
    {
        static int PatientID= 101;
        //Add Patient details after accepting from user
        public static void AddPatient()
        {
            Patient newPatient= new Patient();
            try
            {
                
                
                Console.WriteLine("Patient ID:"+PatientID);
                
                Console.Write("enter Patient name:");
                newPatient.PatientName = Console.ReadLine();
                Console.Write("enter Patient's phone number:");
                newPatient.PhoneNumber = Console.ReadLine();
                Console.Write("enter patient's Age:");
                newPatient.age = Convert.ToInt32(Console.ReadLine());


                bool patientAdded = ClinicBL.AddPatient(newPatient);

                if (patientAdded==true)
                {
                    newPatient.PatientID = PatientID++;
                    Console.WriteLine("Patient addded successfully");
                }
                else
                {
                    throw new ClinicException("Patient not added");
                }
            }
            catch (ClinicException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //search patient based on user input
        public static void SearchPatient()
        {
            try
            {
                int PatientId;
                Console.Write("Enter Patient Id for patient to be searched");
                PatientId = Convert.ToInt32(Console.ReadLine());
                Patient clinicpatient = ClinicBL.SearchPatient(PatientId);
                if (clinicpatient != null)
                {
                    Console.WriteLine("Patient Id"+clinicpatient.PatientID);
                    Console.WriteLine("Patient Name:" + clinicpatient.PatientName);
                    Console.WriteLine("Patient phone number:" + clinicpatient.PhoneNumber);
                    Console.WriteLine("Patient age:" + clinicpatient.age);
                }
                else
                {
                    throw new ClinicException("patient not found with id:" + PatientId);
                }

            }
            catch (ClinicException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        //serializing Patient details
        public static void SerializePatient()
        {
            try
            {
                bool patientSerialized = ClinicBL.SerializePatient();
                if (patientSerialized)
                {
                    Console.WriteLine("patient data is serialized");
                }
            }
            catch (ClinicException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //deserialize Patient details
        public static void DeserializePatient()
        {
            try
            {
                List<Patient> patientList = ClinicBL.DeserializePatient();
                if (patientList != null)
                {
                    Console.WriteLine("**********************************************");
                    Console.WriteLine("Patient Id\t Patient name\t Phone number\t Age\t ");
                    Console.WriteLine("**********************************************");
                    foreach (Patient clinicpatient in patientList)
                    {
                        Console.WriteLine(clinicpatient.PatientID + "\t" + "\t"+clinicpatient.PatientName + "\t" + "\t"+clinicpatient.PhoneNumber + "\t" + clinicpatient.age );
                    }
                }
                else
                { throw new ClinicException("no data"); }
            }
            catch (ClinicException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //menu to be displayed on user Interface
        public static void PrintMenu()
        {
            Console.WriteLine("********************");
            Console.WriteLine("1:Add Patient");           
            Console.WriteLine("2:Search Patient");           
            Console.WriteLine("3:Serialize Patient");
            Console.WriteLine("4:deserialize Patient");
            Console.WriteLine("5:exit");
            Console.WriteLine("*********************");

        }
        static void Main(string[] args)
        {
            int choice = 0;
            try
            {
                do
                {
                    PrintMenu();
                    Console.Write("\nenter your choice");
                    choice = Convert.ToInt32(Console.ReadLine());
                    //menu for patient to choose what operation to perform
                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;                        
                        case 2: SearchPatient();
                            break;                        
                        case 3: SerializePatient();
                            break;
                        case 4: DeserializePatient();
                            break;
                        case 5: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("pls provide proper input");
                            break;
                    }
                }
                while (choice != 5);
            }
           
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        }
    }

