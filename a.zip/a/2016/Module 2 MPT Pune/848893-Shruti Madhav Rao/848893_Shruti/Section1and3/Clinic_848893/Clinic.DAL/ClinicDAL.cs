﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clinic.Entity;//reference for entity class
using Clinic.Exception;//reference to exception class
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Clinic.DAL
{
    /// <summary>
    /// employee id:848893
    /// employee name:shruti rao
    /// Description:data access layer of clinic Management system
    /// Date of creation:19/09/2016
    /// </summary>
    public class ClinicDAL
    {
        static List<Patient> patientList = new List<Patient>();

        //Function to add new Patient to the list of patients in clinic
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                //Adding Patient
                patientList.Add(newPatient);
                patientAdded = true;
            }
            catch (ClinicException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }
        //function to search patient from the list
        public static Patient SearchPatient(int PatientId)
        {
            Patient patientSearched = null;
            try
            {
                //search Patient details
                patientSearched = patientList.Find(clinicpatient => clinicpatient.PatientID == PatientId);

            }
            catch (ClinicException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }
        //serialization of patient data
        public static bool SerializePatient()
        {
            bool patientSerialized = false;
            try
            {
                if (patientList.Count > 0)
                {
                    FileStream fs = new FileStream(@"..\..\Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(fs, patientList);
                    patientSerialized = true;
                    fs.Flush();
                    fs.Close();
                }
                else
                { throw new ClinicException("no patient data.so cannot serialize"); }
            }
            catch (ClinicException ex)
            { throw ex; }
            catch (SystemException ex)
            { throw ex; }
            return patientSerialized;
        }
        //deserialization of patient data
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPatient = null;
            try
            {
                FileStream fs = new FileStream(@"..\..\Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                desPatient = (List<Patient>)bf.Deserialize(fs);
                fs.Flush();
                fs.Close();
            }
            catch (ClinicException ex)
            { throw ex; }
            catch (SystemException ex)
            { throw ex; }
            return desPatient;
        }
    }
    }
