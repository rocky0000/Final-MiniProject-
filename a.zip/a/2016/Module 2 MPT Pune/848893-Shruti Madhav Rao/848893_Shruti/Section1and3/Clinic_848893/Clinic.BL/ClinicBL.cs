﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clinic.Entity;//reference to entity class
using Clinic.Exception;//reference to Exception class
using Clinic.DAL;//reference to Data Access layer
using System.Text.RegularExpressions;

namespace Clinic.BL
{
    /// <summary>
    /// Employee ID:848893
    /// Employee name:Shruti Rao
    /// Description:business logic of Patient
    /// Date of creation:19/09/2016
    /// </summary>
    public class ClinicBL
    {
        //function to validate the patient data
        public static bool ValidatePatient(Patient clinicpatient)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();
            try 
            {
             
                //validating Patient name
                if (!Regex.IsMatch(clinicpatient.PatientName, "[A-Z a-z ]+"))
                {
                    msg.Append("\nPatient name should have Alphabets and spaces only \n");
                    validPatient = false;
                }
                //validating phone number
                if (!Regex.IsMatch(clinicpatient.PhoneNumber, "[1-9][0-9]{9}")||clinicpatient.PhoneNumber.Length>10)
                {
                    msg.Append("\nphone number should have 10 digits and can have first digit from 1-9\n");
                    validPatient = false;
                }
                //validating age
                if (clinicpatient.age <=0 || clinicpatient.age > 100)
                {
                    msg.Append("\npatient age should be between 0 and 100\n");
                    validPatient = false;
                }
                if (validPatient == false)
                {
                    throw new ClinicException(msg.ToString());
                    
                }
            }
            catch (ClinicException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }
        //adding patient details
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPatient))
                {
                    patientAdded = ClinicDAL.AddPatient(newPatient);
                }
                else
                {
                    throw new ClinicException("Please provide valid data for Patient");
                }
            }
            catch (ClinicException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }
        //search patient details
        public static Patient SearchPatient(int PatientId)
        {
            Patient patientSearched = null;
            try
            {
                patientSearched = ClinicDAL.SearchPatient(PatientId);
            }
            catch (ClinicException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }
        //serialize patient data
        public static bool SerializePatient()
        {
            bool patientSerialized = false;
            try
            {
                patientSerialized = ClinicDAL.SerializePatient();
            }
            catch (ClinicException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return patientSerialized;
        }
        public static List<Patient> DeserializePatient()
        {
            List<Patient> patientList = null;
            try
            {
                patientList = ClinicDAL.DeserializePatient();
            }
            catch (ClinicException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return patientList;

        }
    }
}
