﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Question2lib;

namespace Question2
{
    /// <summary>
    /// Employee Id: 848818
    /// Employee name:Siddhi Narvekar
    /// Discription :This is a Program to display metadata about method.
    /// Date of creation :19/09/2016
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("Question2lib.dll");

            Type empType = myAssembly.GetType("Question2lib.Test");
            

            MethodInfo squareMethod = empType.GetMethod("DoWork");

            object calcobj = myAssembly.CreateInstance("Question2lib.Test");

            Console.WriteLine("Enter a number");
            int num = Convert.ToInt32(Console.ReadLine());
            int result = (int)squareMethod.Invoke(calcobj, new object[] { num });
            Console.WriteLine("The Square of number {0} is {1}\n\n ",num,result);


            Console.WriteLine("Method details are:\n\n");
            Console.WriteLine("Method Name: " + squareMethod.Name);
            Console.WriteLine("Return Type: " + squareMethod.ReturnType);
            Console.WriteLine("Is Static: " + squareMethod.IsStatic);
            Console.WriteLine("Is Virtual: " + squareMethod.IsVirtual);
            Console.WriteLine("Return Parameter: " + squareMethod.ReturnParameter);
            Console.WriteLine("Parameters: " + squareMethod.GetParameters());

            Console.ReadKey();
            
        }
    }
}
