﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2lib
{
    public class Test
    {
        public int DoWork(int parameter)
        {
            return parameter*parameter;
        }
    }
}
