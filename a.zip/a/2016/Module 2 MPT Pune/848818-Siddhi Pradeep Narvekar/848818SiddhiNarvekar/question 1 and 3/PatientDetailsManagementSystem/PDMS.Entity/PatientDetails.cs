﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDMS.Entity
{
    /// <summary>
    /// Employee ID : 848818
    /// Employee Name : SIDDHI NARVEKAR
    /// Description :This is entity class for PatientDetails
    /// Date of Creation :19/09/2016
    /// </summary>
    [Serializable]
    public class PatientDetails
    {
        public static int ID = 100;//Autogenrated ID initialized to 100
        //property for get or set Employee Id
        public int PatientID { get; set; }
        //property for get or set Employee Name
        public string PatientName { get; set; }
        //property for get or set Employee Phone number
        public string PhoneNo { get; set; }
        //property for get or set Employee Age
        public int Age { get; set; }
        
    }
}
