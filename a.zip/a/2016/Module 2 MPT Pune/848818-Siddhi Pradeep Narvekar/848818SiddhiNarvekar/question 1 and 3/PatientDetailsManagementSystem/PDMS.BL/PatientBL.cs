﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDMS.Exception;//Reference to Patient exception
using PDMS.Entity;//Reference to patient entity
using PDMS.DAL;//Reference to Patient Data Access Layer 
using System.Text.RegularExpressions;

namespace PDMS.BL
{
    /// <summary>
    /// Employee ID : 848818
    /// Employee Name : SIDDHI NARVEKAR
    /// Description :This is Bussiness Layer class for PatientDetails
    /// Date of Creation :19/09/2016
    /// </summary>
    public class PatientBL
    {
        //Function to validate the Patient data
        public static bool ValidatePatient(PatientDetails patient)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();
            try 
            {
                //validate patient ID
                if (patient.PatientID > 999)
                {
                    msg.Append("Patient ID should be 3 digits\n");
                    validPatient = false;
                }
                //validate Patient Name
                if (!Regex.IsMatch(patient.PatientName, "[A-Z][a-z ]+"))
                {
                    msg.Append("Patient name should have alphabets and spaces only and should start with capital letter\n");
                    validPatient = false;
                }
                //validate Phone number
                if (!Regex.IsMatch(patient.PhoneNo, "[1-9][0-9]{9}"))
                {
                    msg.Append("Patient phone number should have 10 digits should not start with 0\n");
                    validPatient = false;
                }
                //validate Age
                if (patient.Age < 0 || patient.Age > 100)
                {

                    msg.Append("Patient age should be between 0-100 years\n");
                    validPatient  = false;
                }
                if (validPatient == false)
                    throw new PatientException(msg.ToString());


            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            return validPatient;
        }
       
        
        //add Patient
        public static bool AddPatient(PatientDetails newPatient)
        {
            bool PatientAdded = false;

            try
            {
                if (ValidatePatient(newPatient))
                {
                    newPatient.PatientID = ++PatientDetails.ID;
                    PatientDAL.AddPatient(newPatient);
                    PatientAdded = true;
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            return PatientAdded;
        }

        //search function
        public static PatientDetails SearchPatient(int patientID)
        {
            PatientDetails PatientSearched = null;
            try
            {
                PatientSearched = PatientDAL.SearchPatient(patientID);


            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            return PatientSearched;
        }

        //serialize

        public static bool SerializePatient()
        {
            bool patientSerialized = false;

            try
            {
                patientSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            return patientSerialized;
        }
       
        //deserialize
        public static List<PatientDetails> DeserializePatient()
        {
            List<PatientDetails> patientlist = null;
            try
            {
                patientlist = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            return patientlist;
        }
    }
}
