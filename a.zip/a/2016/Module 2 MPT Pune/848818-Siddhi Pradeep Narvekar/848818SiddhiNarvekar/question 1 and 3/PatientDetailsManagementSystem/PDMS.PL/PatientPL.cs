﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDMS.BL;       //reference for Patient business layer
using PDMS.Entity;   //reference for Patient entity
using PDMS.Exception;//reference for Patient exception 


namespace PDMS.PL
{
    /// <summary>
    /// Employee Id: 848818
    /// Employee name:Siddhi Narvekar
    /// Description :This is presentation layer class for PatientDetails
    /// Date of creation :19/09/2016
    /// </summary>
    class PatientPL
    {
        //add Patient
        public static void AddPatient()
        {
            PatientDetails newPatient = new PatientDetails();
            try
            {

                newPatient.PatientID = 0;
               
                Console.WriteLine("Enter PatientName:");
                newPatient.PatientName = Console.ReadLine();
                Console.WriteLine("Enter Patient Phone No:");
                newPatient.PhoneNo = Console.ReadLine();
                Console.WriteLine("Enter Patient Age:");
                newPatient.Age = Convert.ToInt32(Console.ReadLine());
                bool PatientAdded = PatientBL.AddPatient(newPatient);

                if (PatientAdded)
                {
                    Console.WriteLine("***************************************************************");
                    Console.WriteLine("Patient ID\tPatient Name\tPhone No.\t\tAge");
                    Console.WriteLine(newPatient.PatientID + "\t\t" + newPatient.PatientName + "\t\t" + newPatient.PhoneNo + "\t\t" + newPatient.Age);
                    Console.WriteLine("***************************************************************");
                    Console.WriteLine("\n\nPatient added successfully\n\n");
                }
                else
                    throw new PatientException("Patient not added");
                
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Search Patient
        public static void SearchPatient()
        {
            PatientDetails searchPatient = new PatientDetails();
            try
            {
                int patientID;
                Console.Write("\nEnter Patient ID for Patient which you would like to search: \n");
                patientID = Convert.ToInt32(Console.ReadLine());

                PatientDetails pat = PatientBL.SearchPatient(patientID);
                if (pat != null)
                {
                    Console.WriteLine("Patient information is:\n");
                    Console.WriteLine("Patient ID: " + pat.PatientID);
                    Console.WriteLine("Patient Name: " + pat.PatientName);
                    Console.WriteLine("Patient Phone no: " + pat.PhoneNo);
                    Console.WriteLine("Patient Age: " + pat.Age);
                    
                }
                else
                    throw new PatientException("Patient information not found with patientID:" + patientID);
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //function for printing menu
        public static void Printmenu()
        {
            Console.WriteLine("***************************************");
            Console.WriteLine("1.Add Patient \n2:Search Patient \n3:Serialize \n4:Deserialize \n5:Exit");
            Console.WriteLine("***************************************\n\n");

        }
        //serialization function
        public static void SerializePatient()
        {
            try
            {
                bool patientSerialized = PatientBL.SerializePatient();
                if (patientSerialized)
                    Console.WriteLine("Patient data is serialized");
                else throw new PatientException("Patient data not serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Deserialization function
        public static void DeserializedPatient()
        {
            try
            {
                List<PatientDetails> patientlist = PatientBL.DeserializePatient();
                if (patientlist != null)
                {
                    Console.WriteLine("***************************************************************");
                    Console.WriteLine("Patient ID\tPatient Name\tPhone No.\t\tAge");
                    foreach (var p in patientlist)
                    {
                        Console.WriteLine(p.PatientID + "\t\t" + p.PatientName + "\t\t" + p.PhoneNo + "\t\t" + p.Age);

                    }
                    Console.WriteLine("***************************************************************");
                }

            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void Main(string[] args)
        {
            int choice = 0;
            
            try
            {
                do
                {
                    Printmenu();
                    Console.WriteLine("Enter ur choice");
                    choice = Convert.ToInt32(Console.ReadLine());
                    
                    switch(choice)
                    {
                        case 1: AddPatient();//function call for Adding patient
                            break;

                        case 2: SearchPatient();//function call for searching patient
                            break;

                        case 3: SerializePatient();//function call for Serialization patient
                            break;
                        case 4: DeserializedPatient();//function call for Deserialization patient
                            break;
                        case 5: break;//exit

                        default: Console.WriteLine("please provide valid choice");
                            break;



                    }

                }
                while(choice!=5);
            }

                catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
        

        
    }
}
