﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDMS.Exception
{
    /// <summary>
    /// Employee Id: 848818
    /// Employee name:Siddhi Narvekar
    /// Description :This is exception class for PatientDetails 
    /// Date of creation :19/09/2016
    /// </summary>
    public class PatientException :ApplicationException
    {
        public PatientException()
            : base()
        { }
        public PatientException(string msg)
            : base(msg)
        { }
    }
}
