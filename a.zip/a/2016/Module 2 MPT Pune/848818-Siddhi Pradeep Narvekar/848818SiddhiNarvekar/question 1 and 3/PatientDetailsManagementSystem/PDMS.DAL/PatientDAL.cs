﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDMS.Entity;//Reference to patient entity
using PDMS.Exception;//Reference to Patient exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace PDMS.DAL
{
    /// <summary>
    /// Employee ID : 848818
    /// Employee Name : SIDDHI NARVEKAR
    /// Description :This is Data Layer Application class for PatientDetails
    /// Date of Creation :19/09/2016
    /// </summary>
    public class PatientDAL
    {
        static List<PatientDetails> patientlist = new List<PatientDetails>();

        //function to add new patient to list of Patients
        public static bool AddPatient(PatientDetails newPatient)
        {
            bool PatientAdded = false;
            try
            {
                //adding Patients
                patientlist.Add(newPatient);
                PatientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            return PatientAdded;

        }

        //function to search new patient from list of patients
        public static PatientDetails SearchPatient(int pID)
        {
            PatientDetails patientSearched = null;
            try
            {
                //searching Patient
                patientSearched = patientlist.Find(p => p.PatientID == pID);


            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            return patientSearched;

        }

        //Serialization
        public static bool SerializePatient()
        {
            bool pSerialized = false;
            try
            {
                if (patientlist.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binFormat = new BinaryFormatter();
                    binFormat.Serialize(fs, patientlist);
                    pSerialized = true;
                    fs.Close();


                }
                else
                    throw new PatientException();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            return pSerialized;
        }

        //Deserialization 
        public static List<PatientDetails> DeserializePatient()
        {
            List<PatientDetails> desPatient = null;
            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormat = new BinaryFormatter();
                desPatient = (List<PatientDetails>)binFormat.Deserialize(fs);
                fs.Close();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            return desPatient;

        }
    }
}
