﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q._2TestClassConsoleApp

{
    /// <summary>
    /// Employee ID:848822
    /// Employee Name:Sonam Mishra
    /// Description: This is Exception testclass.
    /// Date of Creation:19/09/2016
    /// </summary>
    public class TestException : ApplicationException
    {
        //TesttException
        public TestException()
            : base()
        { }
        public TestException(string msg)
            : base(msg)
        { }
    }
}
