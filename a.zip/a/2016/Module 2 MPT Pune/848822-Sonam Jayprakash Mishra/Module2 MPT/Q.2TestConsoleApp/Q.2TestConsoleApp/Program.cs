﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Q._2TestClass; //Reference to test class for calculation!!!
using System.Reflection;
using Q._2TestClassConsoleApp;

namespace Q._2TestConsoleApp
{
    /// <summary>
    /// Employee ID:848822
    /// Employee Name:Sonam Mishra
    /// Description:This is Reflection Method for test class!!!
    /// Date of Creation: 19/09/2016
    /// </summary>
    public class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Assembly myAssembly = Assembly.LoadFrom("Q.2TestClass.dll");



                Type testType = myAssembly.GetType("Q.2TestClass.Test");


                //Method type
                MethodInfo testMethod = testType.GetMethod("DoWork"); 
                
                Console.WriteLine("Method Name : " + testMethod.Name);

                Console.WriteLine("Return Type : " + testMethod.ReturnType);

                Console.WriteLine("Is Static : " + testMethod.IsStatic);

                Console.WriteLine("Return Parameter : " + testMethod.ReturnParameter);

                Console.WriteLine("Parameter Name : " + testMethod.GetParameters());

                Console.WriteLine("Return Type Name : " + testMethod.ReturnType.Name);





                //creating object instance

                object calcObj = myAssembly.CreateInstance("Q.TestClass.Test");

                MethodInfo testMethod1 = testType.GetMethod("DoWork");

                int square1 = (int)testMethod1.Invoke(calcObj, new object[] { 12 });

                Console.WriteLine("\nSquare of number is :\n " + square1);
            }

            catch (TestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }



            Console.ReadKey();
        }
    }
}
