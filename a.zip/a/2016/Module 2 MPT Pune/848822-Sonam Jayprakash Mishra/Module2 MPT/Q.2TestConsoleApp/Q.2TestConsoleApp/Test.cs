﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q._2TestClass
{
    /// <summary>
    /// Employee ID:848822
    /// Employee Name:Sonam Mishra
    /// Description:This is Test class for Do Work Method!!
    /// Date of Creation: 19/09/2016
    /// </summary>
   public class Test
    {
        public static int DoWork(int num)
        {
            int result = num * num;
            return result;
        }
    }
}

