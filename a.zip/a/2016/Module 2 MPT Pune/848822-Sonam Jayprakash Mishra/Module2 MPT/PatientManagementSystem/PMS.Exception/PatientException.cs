﻿//Q.1 AND Q.3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Exception
{
    /// <summary>
    /// Employee ID:848822
    /// Employee Name:Sonam Mishra
    /// Description: This is Exception class for Patient 
    /// Date of Creation:19/09/2016
    /// </summary>
    public class PatientException : ApplicationException
    {
        //PatientException
        public PatientException()
            : base()
        { }
        public PatientException(string msg)
            : base(msg)
        { }
    }
}
