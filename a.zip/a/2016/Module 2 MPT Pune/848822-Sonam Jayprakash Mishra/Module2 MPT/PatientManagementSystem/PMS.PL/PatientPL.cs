﻿//Q.1 AND Q.3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Entity;  //reference for Patient entity
using PMS.Exception; //reference for Patient exception
using PMS.BL;    //reference for business layer

namespace PMS.PL
{
    /// <summary>
    /// Employee ID:848822
    /// Employee Name:Sonam Mishra
    /// Description: This is PL for Patient Details
    /// Date of Creation:19/09/2016
    /// </summary>
    class PatientPL
    {
        //Add Patient
        public static void AddPatient()
        {
            Patient newPnt = new Patient();
            try
            {

                Console.WriteLine("Enter Patient Name:");
                newPnt.PatientName = Console.ReadLine();
                Console.WriteLine("Enter Phone Number:");
                newPnt.PhoneNumber = (Console.ReadLine());
                Console.WriteLine("Enter Age of Patient:");
                newPnt.Age = Convert.ToInt32(Console.ReadLine());


                bool patientAdded = PatientBL.AddEmployee(newPnt);

                if (patientAdded)
                {
                    Console.WriteLine("Patient Added Successfully!!!");
                }
                else
                {
                    throw new PatientException("Patient not Added.");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Searching Patient
        public static void SearchPatient()
        {

            try
            {
                int patientID;
                Console.WriteLine("Enter Patient ID for the Patient which you would like to search:");
                patientID = Convert.ToInt32(Console.ReadLine());

                Patient pnt = PatientBL.SearchPatient(patientID);
                if (pnt != null)
                {
                    Console.WriteLine("Patient ID:" + pnt.PatientID);
                    Console.WriteLine("Patient Name:" + pnt.PatientName);
                    Console.WriteLine("Patient Phone Number:" + pnt.PhoneNumber);
                    Console.WriteLine("Age:" + pnt.Age);

                }
                else
                {
                    throw new PatientException("Patient not found with Patient ID" + patientID);
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("\n***************************************************\n");
            Console.WriteLine("1.Add Patient Details\n2.Search Patient Details\n3.Serialze Patient\n4.Deserialize Patient\n5.Exit");
            Console.WriteLine("\n***************************************************\n");
        }

        //Q.3 serialzation part
        public static void SerializePatient()
        {
            try
            {
                bool pntSerialized = PatientBL.SerializePatient();
                if (pntSerialized)
                    Console.WriteLine("Patient Detail is Serialized!!!");
                else
                    Console.WriteLine("Patient Detail is not Serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Q.3 Deseialization part
        public static void DeserializePatient()
        {
            try
            {
                List<Patient> patientList = PatientBL.DeserializePatient();

                if (patientList != null)
                {

                    Console.WriteLine("Patient data is serialized");

                    Console.WriteLine("******************************************************************************\n");
                    Console.WriteLine("Patient ID\t Patient Name\t Phone Number\t Age\n");
                    Console.WriteLine("******************************************************************************\n");
                    foreach (Patient pnt in patientList)
                    {
                        Console.WriteLine(pnt.PatientID + "\t\t" + pnt.PatientName + "\t\t" + pnt.PhoneNumber + "\t\t" + pnt.Age);
                    }
                }

                else
                {
                    throw new PatientException("There is no data available");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        static void Main(string[] args)
        {
            int choice = 0;
            try
            {

                do
                {
                    PrintMenu();
                    Console.WriteLine("\nEnter your choice");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;

                        case 2: SearchPatient();
                            break;

                        case 3: SerializePatient();
                            break;

                        case 4: DeserializePatient();
                            break;

                        case 5: Environment.Exit(0);
                            break;

                        default: Console.WriteLine("Please provide valid choice");
                            break;
                    }
                }
                while (choice != 5);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
    }

