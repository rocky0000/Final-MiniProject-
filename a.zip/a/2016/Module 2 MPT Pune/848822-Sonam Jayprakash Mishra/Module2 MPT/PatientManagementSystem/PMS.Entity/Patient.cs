﻿//Q.1 AND Q.3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Entity
{
    /// <summary>
    /// Employee ID:848822
    /// Employee Name:Sonam Mishra
    /// Description:This is Entity class for Patient
    /// Date of Creation: 19/09/2016
    /// </summary>
    [Serializable]
    public class Patient
    {
        //Property for Get or Set Employee ID
        public int PatientID { get; set; }

        //Property for Get or Set Employee Name
        public string PatientName { get; set; }

        //Property for Get or Set Phone Number
        public string PhoneNumber { get; set; }

        //Property for Get or Set Age
        public int Age { get; set; }

    }
}
