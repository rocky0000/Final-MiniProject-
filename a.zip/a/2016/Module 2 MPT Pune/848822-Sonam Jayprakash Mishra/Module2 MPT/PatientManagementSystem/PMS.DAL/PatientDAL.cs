﻿//Q.1 AND Q.3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Entity; //Reference to Patient Entity
using PMS.Exception; //Reference to Patient Exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace PMS.DAL
{

    /// <summary>
    /// Employee ID:848822
    /// Employee Name:Sonam Mishra
    /// Description: This is Patient DAL class for Patient Details
    /// Date of Creation:19/09/2016
    /// </summary>
    public class PatientDAL
    {
        static int patientID = 101;              //autogeneration

        static List<Patient> patientList = new List<Patient>();

        //Function to add new Patient to the List 
        public static bool AddPatient(Patient newPat)
        {
            bool patientAdded = false;
            try
            {
                newPat.PatientID = patientID;    //autogeneration
                patientID++;                    //autogeneration

                //adding New Patient

                patientList.Add(newPat);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function for Searching Patient
        public static Patient SearchPatient(int patientID)
        {

            Patient patientSearched = null;
            try
            {
                //Searching Patient
                patientSearched = patientList.Find(pnt => pnt.PatientID == patientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //Q.3 Serialization using Binary formatter!!!

        public static bool SerializePatient()
        {
            bool pntSerialized = false;
            try
            {
                if (patientList.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binformat = new BinaryFormatter();
                    binformat.Serialize(fs, patientList);
                    pntSerialized = true;
                    fs.Close();
                }
                else
                {
                    throw new PatientException("no Patient data");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return pntSerialized;
        }
        //Q.3   Deserialization using Binary formatter!!!
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPnt = null;
            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binformat = new BinaryFormatter();

                desPnt = (List<Patient>)binformat.Deserialize(fs);
                fs.Close();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return desPnt;
        }
    }
}
