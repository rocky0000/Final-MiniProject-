﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Exception
{
    /// <summary>
    ///  Patient ID : 
    /// Patient Name :
    /// Patient Phone No:
    /// Patient Age:
    /// Description : This is Exception class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientException:ApplicationException
    {
         public PatientException()
            : base()//using inheritance propery and inherting from ApplicationException
        { }

        public PatientException(string msg)
            : base(msg)
        { }
    }
}
