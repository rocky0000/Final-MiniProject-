﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Entity;//Reference for Patient Entity
using CMS.Exception;//Reference for Patient Exception
using CMS.BL;// Reference for Patient Business Layer

namespace CMS.PL
{
    /// <summary>
    ///  Patient ID : 
    /// Patient Name :
    /// Patient Phone No:
    /// Patient Age:
    /// Description : This is Presentation Layer application for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    class PatientPL
    {
        static int patid = 100;//Initialization of autogenerate Patient ID
        // Function to Add Patient Details 
         public static void AddPatient()
        {
            Patient newPat = new Patient();
            try
            {
                newPat.PatientID = patid++;//Incrementation of PatientID automatically
                Console.Write("Enter Patient Name : ");
                newPat.PatientName = Console.ReadLine();
                Console.Write("Enter Phone No : ");
                newPat.PhoneNo = Console.ReadLine();
                Console.Write("Enter Age : ");
                newPat.Age = Convert.ToInt32(Console.ReadLine());
               

                bool patientAdded = PatientBL.AddPatient(newPat);

                if (patientAdded)
                    Console.WriteLine("Patient Added Successfully");
                else
                    throw new PatientException("Employee not Added");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        // Function to Search Patient By Name
         public static void SearchPatient()
         {
             try
             {
                 string patName;
                 Console.Write("Enter Patient Name for patient Which You Would Like to Search : ");
                 patName = Console.ReadLine();

                 Patient pat = PatientBL.SearchPatient(patName);

                 if (pat != null)
                 {
                     Console.WriteLine("Patient ID : " + pat.PatientID);
                     Console.WriteLine("Patient Name : " + pat.PatientName);
                     Console.WriteLine("Phone Number : " + pat.PhoneNo);
                     Console.WriteLine("Age : " + pat.Age);
                    
                 }
                 else
                     throw new PatientException("Patient not found with Patient Name : " + patName);
             }
             catch (PatientException ex)
             {
                 Console.WriteLine(ex.Message);
             }
             catch (SystemException ex)
             {
                 Console.WriteLine(ex.Message);
             }
         }
        //Function to Serialize Patient Details
         public static void SerializePatient()
         {
             try
             {
                 bool patSerialized = PatientBL.SerializePatient();
                 if (patSerialized)
                     Console.WriteLine("Patient data is serialized");
                 else
                     throw new PatientException("Patient Data is not Serialized");
             }
             catch (PatientException ex)
             {
                 Console.WriteLine(ex.Message);
             }
             catch (SystemException ex)
             {
                 Console.WriteLine(ex.Message);
             }
         }
        //Function to Deserialize Patient Details
         public static void DeserializePatient()
         {
             try
             {
                 List<Patient> patList = PatientBL.DeserializePatient();

                 if (patList != null)
                 {
                     Console.WriteLine("************************************************************************************");
                     Console.WriteLine("Patient ID \t Patient Name \t Phone No \t Age");
                     Console.WriteLine("************************************************************************************");
                     foreach (Patient pat in patList)
                     {
                         Console.WriteLine(pat.PatientID + "\t\t" + pat.PatientName + "\t\t" + pat.PhoneNo + "\t" + pat.Age);
                     }
                 }
                 else
                     throw new PatientException("There is not data");
             }
             catch (PatientException ex)
             {
                 Console.WriteLine(ex.Message);
             }
             catch (SystemException ex)
             {
                 Console.WriteLine(ex.Message);
             }
         }
         public static void PrintMenu()
         {
             Console.WriteLine("\n************************");
             Console.WriteLine("a. Add Patient Details");
             Console.WriteLine("b. Search Patient Details");
             Console.WriteLine("c. Exit");
             Console.WriteLine("d. Serialize Patient Details");
             Console.WriteLine("e. Deserialize Patient Details");
           
             Console.WriteLine("************************");
         }



        static void Main(string[] args)
        {
              char choice = '0';

            try 
            {
                do 
                {
                    PrintMenu();

                    Console.Write("\nEnter Your Choice : ");//Enter your choice in smallcase alphabetic characters
                    choice = Convert.ToChar(Console.ReadLine());

                    switch (choice)
                    {
                        case 'a': AddPatient();
                            break;
                        case 'b': SearchPatient();
                            break;
                        case 'c':  Environment.Exit(0);
                            break;
                        case 'd': SerializePatient();
                            break;
                        case 'e': DeserializePatient();
                            break;
                       
                        default: Console.WriteLine("Please provide valid choice");
                            break;
                    }
                } while (choice !='c');// when choice=='c' it exits
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
        }
    }

