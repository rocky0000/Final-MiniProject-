﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Entity;// Reference to Patient Entity
using CMS.Exception;//Reference to Patient Exception 
using CMS.DAL;// Reference to Data Access Layer
using System.Text.RegularExpressions;

namespace CMS.BL
{
    /// <summary>
    ///  Patient ID : 
    /// Patient Name :
    /// Patient Phone No:
    /// Patient Age:
    /// Description : This is Business Layer class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientBL
    {
        //Function to validate the patient data
        public static bool ValidatePatient(Patient pat)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();

            try
            {
                

                if (!Regex.IsMatch(pat.PatientName, "[A-Za-z]"))
                {
                    msg.Append("Patient Name should have alphabets only \n");
                    validPatient = false;
                }

                if (!Regex.IsMatch(pat.PhoneNo, "[123456789][0-9]{9}")||pat.PhoneNo.Length>10)
                {
                    msg.Append("Phone No should have 10 digits and it should not start with 0\n");
                    validPatient = false;
                }

                if (pat.Age < 0 || pat.Age > 100)
                {
                    msg.Append("Employee Age should be within 0 to 100\n");
                    validPatient = false;
                }

                

                if (validPatient == false)
                    throw new PatientException(msg.ToString());
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validPatient;
        }

        //Function to add Patient Details
        public static bool AddPatient(Patient newPat)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPat))
                {
                    patientAdded = PatientDAL.AddPatient(newPat);
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }
        //Function to Search Patient Details
        public static Patient SearchPatient(string patName)
        {
            Patient patientSearched = null;

            try
            {
                patientSearched = PatientDAL.SearchPatient(patName);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearched;
        }
        public static bool SerializePatient()
        {
            bool patSerialized = false;

            try
            {
                patSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            return patSerialized;
        }

        public static List<Patient> DeserializePatient()
        {
            List<Patient> patList = null;

            try
            {
                patList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patList;
        }





    }
}
