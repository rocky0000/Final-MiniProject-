﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Entity; //Reference to Patient Entity
using CMS.Exception;// Reference to Patient Exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace CMS.DAL
{
    /// <summary>
    ///  Patient ID : 
    /// Patient Name :
    /// Patient Phone No:
    /// Patient Age:
    /// Description : This is Data Access class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientDAL
    {
        static List<Patient> patList = new List<Patient>();

        //Function to add new Patient to the list of employees
        public static bool AddPatient(Patient newPat)
        {
            bool patientAdded = false;

            try
            {
                //Adding Patient
                patList.Add(newPat);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientAdded;
        }
        //Function for searching patient from list of patients
        public static Patient SearchPatient(string patName)
        {
            Patient patSearched = null;

            try
            {
                //searching patient
                patSearched = patList.Find(pat => pat.PatientName == patName);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patSearched;
        }
        // Function for Serializing Patient class
        public static bool SerializePatient()
        {
            bool patSerialized = false;

            try
            {
                if (patList.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binFormat = new BinaryFormatter();
                    binFormat.Serialize(fs, patList);
                    patSerialized = true;
                    fs.Close();
                }
                else
                    throw new PatientException("No patient data so cannot serialize");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patSerialized;
        }
        //Function for Deserializng Patient class
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPat = null;

            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormat = new BinaryFormatter();
                desPat = (List<Patient>)binFormat.Deserialize(fs);
                fs.Close();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desPat;
        }



    }
}
