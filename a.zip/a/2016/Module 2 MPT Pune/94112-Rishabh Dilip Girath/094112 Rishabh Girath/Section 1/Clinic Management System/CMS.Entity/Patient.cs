﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Entity
{
    /// <summary>
    /// Patient ID : 
    /// Patient Name :
    /// Patient Phone No:
    /// Patient Age:
    /// Description : This is Entity class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    /// 
     [Serializable]
    public class Patient
    {
        //Property for Get or Set Patient ID
        public int PatientID { get; set; }
        //Property for Get or Set Patient Name
        public string PatientName { get; set; }
        //Property for Get or Set Patient Phone no
        public string PhoneNo { get; set; }
        //Property for Get or Set Patient Age
        public int Age { get; set; }
    }
}
