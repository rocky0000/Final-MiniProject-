﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibrary
{
    /// <summary>
    /// Employee ID:94112
    /// Employee Name:Rishabh Girath
    /// Description:This the Library for calculating square of the given parameter
    /// Date of Creation:19/09/2016
    /// </summary>
    /// 
    //Creating class Test
    public class Test
    {
        //Creating method DoWork
        public int DoWork(int parameter)
        {
            return parameter * parameter;//Returns parameter square
        }
    }
}
