﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ReflectionforMethod
{
    /// <summary>
    /// Employee ID:94112
    /// Employee Name:Rishabh Girath
    /// Description:This the application for printing metadata about the DoWork method
    /// Date of Creation:19/09/2016
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("ReflectionLibrary.dll");
            Type parType = myAssembly.GetType("ReflectionLibrary.Test");
            MethodInfo[] parMethod = parType.GetMethods();
            int i = 0;
            //For printing metadata of DoWork method
            foreach (MethodInfo m in parMethod)
            {
                i++;
                //Prints Method Name
                Console.WriteLine("Method Name : " + m.Name);
                //Prints Return Type 
                Console.WriteLine("Return Type : " + m.ReturnType.Name);
                //Prints whether static or not
                Console.WriteLine("Is Static : " + m.IsStatic);
                if (i == 1)
                {    //Prints parameter names
                    Console.WriteLine("Parameter Names:" + m.GetParameters().ElementAt(0).Name);
                    //Prints paramter type
                    Console.WriteLine("Parameter Type:" + m.GetParameters().ElementAt(0).ParameterType);
                }
            }
                



            
            //Hardcoded number whose square is found
            object calculateObj = myAssembly.CreateInstance("ReflectionLibrary.Test");
            MethodInfo parMethods = parType.GetMethod("DoWork");
            int result = (int)parMethods.Invoke(calculateObj, new object[] { 4 });
            Console.WriteLine("Square of the number is:" + result);

            //Value taken from user and square is found
            Console.WriteLine("Enter the number whose square is to be found:");
            int number = Convert.ToInt32(Console.ReadLine());
            MethodInfo parMethodsUser = parType.GetMethod("DoWork");
            int answer = (int)parMethodsUser.Invoke(calculateObj, new object[] { number });
            Console.WriteLine("Square of the number is:" + answer);
            Console.ReadKey();
        }
    }
}
