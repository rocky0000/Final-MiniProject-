﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SquareNumber
{
    /// <summary>
    /// Employee ID		:848831
    /// Employee Name	:Shruti Kulkarni
    /// Description		:This library file for SquareNumber
    /// Date of Creation:19/09/2016
    /// </summary>
    public class Test
    {
        public static int DoWork(int num)
        {
            return (num*num);
        }
    }
}
