﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;    //reference of System.reflection class

namespace Q2
{
    /// <summary>
    /// Employee ID		:848831
    /// Employee Name	:Shruti Kulkarni
    /// Description		:This is MathOperation class for getting information
    ///                  from SquareNumber library
    /// Date of Creation:19/09/2016
    /// </summary>
    class MathOperation
    {
        static void Main(string[] args)
        {
            //Loading the SquareNumer library file
            Assembly my_assembly = Assembly.LoadFrom("SquareNumber.dll");
            Type empType = my_assembly.GetType("SquareNumber.Test");

            MethodInfo[] empMethod = empType.GetMethods();

            //getting information about the methods present in the SquareNumber library
            foreach (MethodInfo m in empMethod)
            {
                Console.WriteLine("\n");
                Console.WriteLine("Method name      :" + m.Name);
                Console.WriteLine("ReturnType       :" + m.ReturnType);
                Console.WriteLine("Is Static        :" + m.IsStatic);
                Console.WriteLine("parameters are   :" + m.GetParameters());
                Console.WriteLine();
            }

            Console.WriteLine("\n\n");
            Console.WriteLine("DoWork method called ->");

            //calling DoWork method, it is static method so no object needed for reference
            MethodInfo doMethod = empType.GetMethod("DoWork");
            int sqr=(int)doMethod.Invoke(null, new object[] {10});
            Console.WriteLine("Square of number is :" +sqr);

            Console.ReadKey();
        }
    }
}
