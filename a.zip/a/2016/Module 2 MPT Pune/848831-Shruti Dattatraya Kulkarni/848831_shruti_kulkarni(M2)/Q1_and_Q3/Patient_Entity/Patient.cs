﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patient_Entity
{
    /// <summary>
    /// Employee ID		:848831
    /// Employee Name	:Shruti Kulkarni
    /// Description		:This is Entity class For Patient 
    /// Date of Creation:19/09/2016
    /// </summary>
    
    [Serializable]
    public class Patient
    {
        //Property for Get or Set Patient ID
        public int PatientID { get; set; }
        //Property for Get or Set Patient Name
        public string PatientName { get; set; }
        //Property for Get or Set Patient Age
        public int PatientAge { get; set; }
        //Property for Get or Set Patient Phone Number
        public string PatientPhnNo { get; set; }

    }
}
