﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Patient_Entity;   //Reference of Entity class of Patient
using Patient_Exception;//Reference of Exception class of Patient
using Patient_DAL;      //Reference of DAL class of Patient
using Patient_BL;       //Reference of BL class of Patient

namespace Patient_PL
{
    /// <summary>
    /// Employee ID		:848831
    /// Employee Name	:Shruti Kulkarni
    /// Description		:This is PresentationLayer class For Patient 
    /// Date of Creation:19/09/2016
    /// </summary>
   
    class PatientPL
    {
        static int count = 1;
        public static void AddPatient()
        {
            //object of patient class
            Patient patient = new Patient();
            try
            {
                Console.Write("Patient ID :");
                Console.WriteLine(count);
                patient.PatientID= count;
                //getting patient name from user
                Console.Write("Enter Patient Name :");
                patient.PatientName= Console.ReadLine();
                //getting patient age from user
                Console.Write("Enter the Patient age :");
                patient.PatientAge = Convert.ToInt32(Console.ReadLine());
                //getting patient phone number from user
                Console.Write("Enter phone no :");
                patient.PatientPhnNo= Console.ReadLine();

                bool patientAdded = PatientBL.AddEmployee(patient);

                if (patientAdded)
                    Console.WriteLine("patient Information Added Successfully. ");
                else
                    throw new PatException("Patient Information not Added");
            }
            //exception handling
            catch (PatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        //function for searching the patient details based on patient id
        public static void SearchpatientId()
        {
            try
            {
                int patientID;
                Console.WriteLine("Enter patient Id for the patient which you would like to search");
                patientID = Convert.ToInt32(Console.ReadLine());
                Patient patient = PatientBL.SearchpatientId(patientID);
                if (patient != null)
                {
                    Console.WriteLine("Patient Id :" + patient.PatientID);
                    Console.WriteLine("Patient Name :" + patient.PatientName);
                    Console.WriteLine("Patient Contact no :" + patient.PatientAge);
                    Console.WriteLine("Patient Relationship :" + patient.PatientPhnNo);
                }
                else
                    throw new PatException("Patient not found with patient id " + patientID+" not found");
            }
            //exception handling
            catch (PatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //function for displaying all patient data
        public static void DisplayAllPatients()
        {
            try
            {
                List<Patient> PatList = PatientBL.DisplayAllPatient();

                if (PatList.Count > 0)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("Patient ID\tPatient Name\tPatient Age\tPhone no\t");
                    Console.WriteLine("******************************************************************************");
                    foreach (Patient p in PatList)
                    {
                        Console.WriteLine(p.PatientID+ "\t\t" + p.PatientName+ "\t\t" + p.PatientAge+ "\t" + p.PatientPhnNo);
                    }
                }
                else
                {
                    throw new PatException("there is no data available for the Patient");
                }
            }
             //Exception handling
            catch (PatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //function for serializing the patient details
        public static void SerializePatient()
        {
            try
            {
                bool patSerialized = PatientBL.Serializepatient();
                if (patSerialized)
                    Console.WriteLine("patient data is serialized ");
                else
                    throw new PatException("Patient data is not serialized");
            }
            //exception handling
            catch (PatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //function to deserialize the patient details
        public static void DeserializePatient()
        {
            try
            {
                List<Patient> patList = PatientBL.DeserializePatient();
                if (patList != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("Patient ID\tPatient Name\tPatient Age\tPhone no\t");
                    Console.WriteLine("******************************************************************************");
                    foreach (Patient p in patList)
                    {
                        Console.WriteLine(p.PatientID + "\t\t" + p.PatientName + "\t\t" + p.PatientAge + "\t" + p.PatientPhnNo);
                    }
                }
                else
                    throw new PatException("There is no data");
            }
            catch (PatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void printMenu()
        {
            Console.WriteLine("\n*************************************");
            Console.WriteLine("1. Add Patient Details");
            Console.WriteLine("2. Search Patient Details");
            Console.WriteLine("3. Display All Patients");
            Console.WriteLine("4. Serialize Patient");
            Console.WriteLine("5. Deserialize Patient");
            Console.WriteLine("6. Exit");
            Console.WriteLine("**************************************");
        }


        static void Main(string[] args)
        {
            int choice = 0;
            try
            {
                do
                {
                    printMenu();
                    Console.WriteLine("Enter your choice ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            AddPatient();
                            count++;
                            break;
                        case 2:
                            SearchpatientId();
                            break;
                        case 3:
                            DisplayAllPatients();
                            break;
                        case 4:
                            SerializePatient();
                            break;
                        case 5:
                            DeserializePatient();
                            break;
                        case 6:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Enter the correct choice");
                            break;
                    }
                }
                while (choice != 6);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
