﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Patient_Entity;       //Reference of Entity class of Patient
using Patient_Exception;    //Reference of Exception class of Patient
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;//reference for serialization

namespace Patient_DAL
{
    /// <summary>
    /// Employee ID		:848831
    /// Employee Name	:Shruti Kulkarni
    /// Description		:This is DataAccessLayer class For Patient 
    /// Date of Creation:19/09/2016
    /// </summary>
    public class PatientDAL
    {
        //creating list of patients
        static List<Patient> PatList = new List<Patient>();

        //Function to add new patient to the list of patients
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                //Adding new Patient
                PatList.Add(newPatient);
                patientAdded = true;
            }
            //exception handling
            catch (PatException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientAdded;
        }

        //Function for searching Patient details from list of patients

        public static Patient Search_PateintId(int patientID)
        {
            Patient patientSearchedId = null;
            try
            {
                //searching patient id from list
                patientSearchedId = PatList.Find(patient => patient.PatientID == patientID);
            }
            //Exception handling
            catch (PatException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearchedId;
        }

        //function to display all the Patients in the list

        public static List<Patient> DisplayAllPatients()
        {
            return PatList;
        }

        //function to serialize the patient class data
        public static bool SerializePatient()
        {
            bool patSerialized = false;

            try
            {
                if (PatList.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binformat = new BinaryFormatter();
                    binformat.Serialize(fs, PatList);
                    fs.Close();
                    patSerialized = true;
                }
                else
                {
                    throw new PatException("no patients ");
                }
            }
            //Exception handling
            catch (PatException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patSerialized;
        }

        //function to deserialize the patient class data
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPat = null;
            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binformt = new BinaryFormatter();
                desPat = (List<Patient>)binformt.Deserialize(fs);
                fs.Close();
            }
            //exception handling
            catch (PatException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return desPat;

        }
    }
}
