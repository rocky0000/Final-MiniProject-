﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patient_Exception
{
    /// <summary>
    /// Employee ID		:848831
    /// Employee Name	:Shruti Kulkarni
    /// Description		:This is Exception class For Patient 
    /// Date of Creation:19/09/2016
    /// </summary>
    
    public class PatException:ApplicationException
    {
        //Default constructor for Patient Exception class
        public PatException()

            : base()

        { }

        //Parametrized constructor for Patient Exception class
        public PatException(string msg)
            : base(msg)
        { }
    
    }
}
