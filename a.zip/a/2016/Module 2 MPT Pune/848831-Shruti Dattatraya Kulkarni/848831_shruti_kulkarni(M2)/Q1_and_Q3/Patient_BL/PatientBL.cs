﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Patient_Entity;   //Reference of Entity class of Patient
using Patient_Exception;//Reference of Exception class of Patient
using Patient_DAL;      //Reference of DAL class of Patient
using System.Text.RegularExpressions;

namespace Patient_BL
{
    /// <summary>
    /// Employee ID		:848831
    /// Employee Name	:Shruti Kulkarni
    /// Description		:This is BusinessLayer class For Patient 
    /// Date of Creation:19/09/2016
    /// </summary>
    
    public class PatientBL
    {
        //Function to validate the employee data
        public static bool ValidatePatient(Patient pat)
        {
            Patient patient = new Patient();
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();
            try
            {
                //validating patient name for having only alphabets
                if (!Regex.IsMatch(pat.PatientName, "[A-Za-z ]+"))
                {
                    msg.Append("patient Name should have Alphabets & Spaces only\n");
                    validPatient = false;
                }
                //validating patient phone no for 10 digits
                if (!Regex.IsMatch(pat.PatientPhnNo, "[1-9][0-9]{9}"))
                {
                    msg.Append("Phone no should have 10 digits and it should not start with 0\n");
                    validPatient = false;
                }
                //validating employee age(it should be between 0-100)
                if (pat.PatientAge < 0 || pat.PatientAge > 100)
                {
                    msg.Append("Employee Age must be within 0 to 100 ");
                    validPatient = false;
                }
                if (validPatient == false)
                {
                    throw new PatException(msg.ToString());
                }
            }
            catch (PatException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }

        //adding patient to list if all fields are validated
        public static bool AddEmployee(Patient addpat)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(addpat))
                {
                    patientAdded = PatientDAL.AddPatient(addpat);
                }
                else
                {
                    throw new PatException("Please provide valid data for patient");
                }
            }
            catch (PatException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //searching patient details from the list
        public static Patient SearchpatientId(int patientID)
        {
            Patient patientSearchedId = null;
            try
            {
                patientSearchedId = PatientDAL.Search_PateintId(patientID);
            }
            //Excpetion handling
            catch (PatException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearchedId;
        }

        //function to display all the patients in the list
        public static List<Patient> DisplayAllPatient()
        {

            List<Patient> PatList = PatientDAL.DisplayAllPatients();

            return PatList;

        }

        //function to serialize the patient class data
        public static bool Serializepatient()
        {
            bool patSerialized = false;
            try
            {
                patSerialized = PatientDAL.SerializePatient();
            }
            catch (PatException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patSerialized;
        }

        //function to deserialize the patient class data
        public static List<Patient> DeserializePatient()
        {
            List<Patient> patList = null;

            try
            {
                patList = PatientDAL.DeserializePatient();
            }
            catch (PatException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patList;
        }
    }
}
