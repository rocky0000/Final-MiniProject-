﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientDetails.Entity;        //Reference to Patient Entity
using PatientDetails.Exception;     //Reference to Patient Exception
using PatientDetails.BL;            //Reference to Patient Business Layer

namespace PatientDetails.PL
{
    /// <summary>
    /// EmployeeID:848802
    /// EmpName:Snehal Sane
    /// Description:This is PatientPL class for Patient
    /// Date of Creation:19/09/2016
    /// </summary>
    class PatientPL
    {
        static int patientid = 101;

        //Function to add Patient Details in the list
        public static void AddPatient()
        {
           
            Patient newPatient = new Patient();
            try
            {

                newPatient.PatientID = patientid++; 
                Console.WriteLine("Enter Patient Name:");
                newPatient.PatientName = Console.ReadLine();
                Console.WriteLine("Enter Phone No:");
                newPatient.PhoneNo = Console.ReadLine();
                Console.WriteLine("Enter Age:");
                newPatient.Age = Convert.ToInt32(Console.ReadLine());

                bool employeeAdded = PatientBL.AddPatient(newPatient);

                if (employeeAdded)
                    Console.WriteLine("Patient Details Added successfully");

                else
                    throw new PatientException("Patient Details Not Added");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        //Funtion to search patients in the list
        public static void SearchPatient()
        {
            try
            {
                int patientID;
                Console.WriteLine("Enter Patient Id of the patient whose details you wish to search:");
                patientID = Convert.ToInt32(Console.ReadLine());

                Patient patient = PatientBL.SearchPatient(patientID);

                if (patient != null)
                {
                    Console.WriteLine("Patient Details Are:\n");
                    Console.WriteLine("Patient Name:" + patient.PatientName);
                    Console.WriteLine("Phone Number:" + patient.PhoneNo);
                    Console.WriteLine("Age:" + patient.Age);
                   
                }

                else
                    throw new PatientException("Patient Details Not Found with ID:"+ patientID);

            }

            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        //Function to write menu for user
        public static void PrintMenu()
        {
            Console.WriteLine("************************");
            Console.WriteLine("1.Add Patient Details\n2.Search Patient Details\n3.Display All Patients\n4.Serialize\n5.Deserialize\n6.Exit");
            Console.WriteLine("************************");
        }

        //Function to display all patients in the list
        public static void DisplayAllPatient()
        {
            try
            {
                List<Patient> patientList = PatientBL.DisplayAllPatient();

                if (patientList.Count > 0)
                {
                    Console.WriteLine("*****************************************************");
                    Console.WriteLine(" PatientID \t  PatientName \t PhoneNo \t Age");
                    Console.WriteLine("*****************************************************");
                    foreach (Patient p in patientList)
                    {
                        Console.WriteLine(p.PatientID + "\t\t" + p.PatientName + "\t\t" + p.PhoneNo + "\t" + p.Age );
                    }

                }
                else
                    Console.WriteLine("There is no data for Patient list");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
         
        //Function to serialize patient list
        public static void SerializePatient()
        {
            try
            {
                bool patientSerialized = PatientBL.SerializePatient();
                if (patientSerialized)
                    Console.WriteLine("List Serialized");
                else
                    throw new PatientException("List not serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to deserailize patient list
        public static void DeserializePatient()
        {
            try
            {
                List<Patient> patientList = PatientBL.DeserializePatient();
                if (patientList != null)
                {
                    Console.WriteLine("*****************************************************");
                    Console.WriteLine("PatientID \t Patient Name \t PhoneNo \t Age");
                    Console.WriteLine("*****************************************************");
                    foreach (Patient p in patientList)
                    {
                        Console.WriteLine(p.PatientID + "\t" + p.PatientName + "\t" + p.PhoneNo + "\t" + p.Age);
                    }
                    Console.WriteLine("List Deserialized");
                }
                else
                    throw new PatientException("No data");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void Main(string[] args)
        {
             int choice = 0;
            try
            {
                do
                {
                    PrintMenu();
                    Console.WriteLine("\nEnter your choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;
                        case 2: SearchPatient();
                            break;              
                        case 3: DisplayAllPatient();
                            break;
                        case 4: SerializePatient();
                            break;
                        case 5: DeserializePatient();
                           break;
                        case 6: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("Please provide valid choice");
                            break;

                    }
                }

                while (choice != 6);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
        
    }
}
