﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using PatientDetails.Entity;     //Reference to Patient Entity
using PatientDetails.Exception;  //Reference to Patient Exception
using PatientDetails.DAL;        //Reference to Patient Data Access Layer


namespace PatientDetails.BL
{
    /// <summary>
    /// EmployeeID:848802
    /// EmpName:Snehal Sane
    /// Description:This is PatientBL class for Patient
    /// Date of Creation:19/09/2016
    /// </summary>
    public class PatientBL
    {
        
        //Function to validate the patient data
        public static bool ValidatePatient(Patient patient)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();
            //Validating Patient Details
            try 
            {
                //Validating Patient Name for Alphabets
                if (!Regex.IsMatch(patient.PatientName, "[A-Za-z ]+"))
                {
                    msg.Append("Patient name should contain Alphabets only\n");
                    validPatient = false;
                }

                //Validating Patient PhoneNo for 10 digits
                if (!Regex.IsMatch(patient.PhoneNo, "[1-9][0-9]{9}"))
                {
                    msg.Append("Phone Number should have 10 digits and it should start with digits between 1 to 9\n");
                    validPatient = false;
                }

                //Validating Patient Age in between 1-100
                if (patient.Age < 0 || patient.Age > 100)
                {
                    msg.Append("Age should be between 1 and 100\n");
                    validPatient = false;
                }

                if (validPatient == false)
                {
                    throw new PatientException(msg.ToString());
                }

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        
    }

    //Function to add Patient details in the list
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;
            //Adding patient details
            try
            {
                if(ValidatePatient(newPatient))
                {
                    patientAdded=PatientDAL.AddPatient(newPatient);
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function for Searching Patient in the list of Patients
        public static Patient SearchPatient(int patientID)
        {
            Patient patientSearched = null;
            //Searching Patient details
            try
            {
                patientSearched = PatientDAL.SearchPatient(patientID);
            }
            catch (PatientException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //Function to Display all Patients list
        public static List<Patient> DisplayAllPatient()
        {
            List<Patient> patientList = PatientDAL.DisplayAllPatient();

            return patientList;
        }

        //Function to serialize Patient List
        public static bool SerializePatient()
        {
            bool patientSerialized = false;
            try
            {
                patientSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }

        //Function to Desrialize patient list
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPatient = null;
            try
            {
                desPatient = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return desPatient;
        }
    }
}
