﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientDetails.Entity;                         //Reference to Patient Entity
using PatientDetails.Exception;                      //Reference to Patient Exception
using System.IO;                                     //Reference to IO
using System.Runtime.Serialization.Formatters.Binary;//Reference for Binary Serialization


namespace PatientDetails.DAL
{
    /// <summary>
    /// EmployeeID:848802
    /// EmpName:Snehal Sane
    /// Description:This is PatientDAL class for Patient
    /// Date of Creation:19/09/2016
    /// </summary>
    public class PatientDAL
    {
        static List<Patient> patientList = new List<Patient>();

        //Function to add new Patient to the list of patients
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                //Adding Patient
                patientList.Add(newPatient);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientAdded;
        }

        //Function for Searching Patient in the list of Patients
        public static Patient SearchPatient(int patientID)
        {
            Patient patientSearched = null;
            //Searching Patient
            try
            {
                patientSearched =
                     patientList.Find(patient => patient.PatientID == patientID);
            }
            catch (PatientException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //Function to display all patients from the list
        public static List<Patient> DisplayAllPatient()
        {
            return patientList;
        }

        //Function to serialize the list of patients
        public static bool SerializePatient()
        {
            bool patientSerialized = false;

            //Binary Serialization of patient list
            try
            {
                if (patientList.Count > 0)
                {
                    FileStream fs = new FileStream(@"..\..\Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binformat = new BinaryFormatter();
                    binformat.Serialize(fs, patientList);
                    fs.Close();
                    patientSerialized = true;
                }
                else
                    throw new PatientException("No Patient list");
            }
            catch (PatientException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }

        //Function to Deserialize the patient list
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPatient = null;

            //Deserialization of patient list
            try
            {
                if (patientList.Count > 0)
                {
                    FileStream fs = new FileStream(@"..\..\Patient.txt", FileMode.Open, FileAccess.Read);
                    BinaryFormatter binformat = new BinaryFormatter();
                    desPatient = (List<Patient>)binformat.Deserialize(fs);
                    fs.Close();
                }
                else
                    throw new PatientException("No Patient list");
            }
            catch (PatientException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return desPatient;
        }

    }
}
