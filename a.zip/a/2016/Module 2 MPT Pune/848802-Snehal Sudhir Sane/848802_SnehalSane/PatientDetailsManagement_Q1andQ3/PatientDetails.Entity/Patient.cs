﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDetails.Entity
{
    /// <summary>
    /// EmployeeID:848802
    /// EmpName:Snehal Sane
    /// Description:This is Entity class for Patient
    /// Date of Creation:19/09/2016
    /// </summary>
   
    [Serializable]
    public class Patient
    {
     
        //Property for Get or Set PatientID
        public int PatientID{get;set;}

        //Property for Get or Set PatientName
        public string PatientName { get; set; }

        //Property for Get or Set Age
        public int Age { get; set; }

        //Property for Get or Set Phoneno.
        public string PhoneNo { get; set; }
    }
}
