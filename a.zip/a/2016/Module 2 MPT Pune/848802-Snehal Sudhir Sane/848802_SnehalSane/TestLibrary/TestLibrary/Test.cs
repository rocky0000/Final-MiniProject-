﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestLibrary
{
    /// <summary>
    /// EmployeeID:848802
    /// EmpName:Snehal Sane
    /// Description:This is Test class
    /// Date of Creation:19/09/2016
    /// </summary>
    public class Test
    {
        public int DoWork(int number)
        {
            return number * number;
        }
    }
}
