﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;       //Reference to Reflection class of System

namespace TestQ2
{
    /// <summary>
    /// EmployeeID:848802
    /// EmpName:Snehal Sane
    /// Description:This is Program class 
    /// Date of Creation:19/09/2016
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("TestLibrary.dll");    //Assembly creation and loading it from library
            Type testType = myAssembly.GetType("TestLibrary.Test");
            MethodInfo[] testMethods=testType.GetMethods();

            int index = 0;
            foreach (MethodInfo m in testMethods)
            {
                index++;
                Console.WriteLine("\n\n\n\nMethod Name:"+m.Name);
                Console.WriteLine("\nReturn type:" + m.ReturnType.Name);
                Console.WriteLine("\nIs Method Static?" + m.IsStatic);

                if (index == 1)
                {
                    Console.WriteLine("\nParameter Names:" + m.GetParameters().ElementAt(0).Name);
                    Console.WriteLine("\nParameter Types:" + m.GetParameters().ElementAt(0).ParameterType.Name);
                }
                //Console.WriteLine("\nParameter Types:" + m.ReturnParameter);
              
            }

            object test = myAssembly.CreateInstance("TestLibrary.Test");  //Object created for non static method

            MethodInfo doWork = testType.GetMethod("DoWork");
            int square = (int)doWork.Invoke(test, new object[] { 4 });     //Type cast to integer datatype
            Console.WriteLine("\n\nSquare of given number is:" + square);

        }
    }
}
