﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2Lib
{
    /// <summary>
    /// Employee ID        :   94127
    /// Employee Name      :   Rahul Yadav
    /// Description        :   This is a class Which has a method to calculate Square of a number
    /// Date of Creation   :   19/09/2016
    /// </summary>
    public class Test
    {
        public int DoWork(int num)
        {
            //Calculating The Square
            int square;
            square= num * num;
            return square;
        }
    }
}
