﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Question2Lib;  //Reference to the Library
namespace Question2
{
    /// <summary>
    /// Employee ID        :   94127
    /// Employee Name      :   Rahul Yadav
    /// Description        :   This is PL class for Test Class
    /// Date of Creation   :   19/09/2016
    /// </summary>
    class Calculate
    {
        static void Main(string[] args)
        {
            Test cal = new Test();

            //Loading The Assembly
            Assembly myAssembly = Assembly.LoadFrom("Question2Lib.dll");
            
            //Gets the type of Object
            Type calType = myAssembly.GetType("Question2Lib.Test");

            //Discovers the attributes and provide access to method metadata
            MethodInfo doworkMethod = calType.GetMethod("DoWork");

            //Read Number whose square is to be calculated
            Console.Write("Enter a number whose square is to be calculated: ");
            int num = Convert.ToInt32(Console.ReadLine());
            int result = (int)doworkMethod.Invoke(cal, new object[] { num });
            Console.WriteLine("\nSquare: " + result);

            //Displaying the metadata of DoWork Method
            Console.WriteLine("Method Name : " +doworkMethod.Name);
            Console.WriteLine("Return Type : " + doworkMethod.ReturnType);

            // Check whether the method is static or an instance
            if (doworkMethod.IsStatic)
            {
                Console.WriteLine(doworkMethod.Name+" is a Static Method  " );
            }
            else
            {
                Console.WriteLine(doworkMethod.Name + " is an Instance  ");
            }
            
          
            //Discovers the attributes of parameters and provides access to parameter metadata
            ParameterInfo[] para = doworkMethod.GetParameters();
            foreach(ParameterInfo par in para)
            {
                Console.Write("Parameter Name: "+par.Name);
                Console.Write("\nParameter Type: "+par.ParameterType);
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
