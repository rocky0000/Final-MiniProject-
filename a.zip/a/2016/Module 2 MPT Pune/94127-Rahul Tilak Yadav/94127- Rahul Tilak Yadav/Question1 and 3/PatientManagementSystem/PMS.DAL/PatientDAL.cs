﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Entity;       //Reference to Patient Entity
using PMS.Exception;    //Reference to Patient Exception
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace PMS.DAL
{
    /// <summary>
    /// Employee ID        :   94127
    /// Employee Name      :   Rahul Yadav
    /// Description        :   This is Data Access Layer class for Patient
    /// Date of Creation   :   19/09/2016
    /// </summary>
    public class PatientDAL
    {
        static List<Patient> patList = new List<Patient>();

        //Function to add new patient details to the list of patient
        public static bool AddPatient(Patient newPat)
        {
            bool patientAdded = false;

            try
            {
                //Adding Patient
                patList.Add(newPat);
                patientAdded = true;
            }
            //Catch User Defined Exception
            catch (PatientException ex)
            {
                throw ex;
            }
            //Catch System Exception
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function to search patient details from the list of patients
        public static Patient SearchPatient(int patID)
        {
            Patient patSearched = null;

            try
            {
                //Searching the Patient
                patSearched = patList.Find(emp => emp.PatID == patID);

            }
            //Catch User Defined Exception
            catch (PatientException ex)
            {
                throw ex;
            }
            //Catch system Exception
            catch (SystemException ex)
            {
                throw ex;
            }
            return patSearched;
        }

        //Function to display details of all patients from the list of patients
        public static List<Patient> DisplayAllPatient()
        {
            return patList;
        }

        //Function to perform serialization on patient details
        public static bool SerializePatient()
        {
            bool patSerialized = false;
            try
            {
                if (patList.Count > 0)
                {
                    //performing serialization
                    FileStream fs = new FileStream(@"..\..\..\Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(fs, patList);
                    patSerialized = true;

                    fs.Close();
                }
                else
                    throw new PatientException("No Patient data so cannot Serilize");
            }

            //Catch User Defined Exception
            catch (PatientException ex)
            {
                throw ex;
            }
            //Catch system Exception
            catch (SystemException ex)
            {
                throw ex;
            }
            return patSerialized;
        }

        //Function to perform Deserialization on patient details
        public static List<Patient> DeserilaizePatient()
        {
            List<Patient> desPat = null;
            try
            {
                //performing Deserialization
                FileStream fs = new FileStream(@"..\..\..\Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                desPat = (List<Patient>)bf.Deserialize(fs);
                fs.Close();
            }

            //Catch User Defined Exception
            catch (PatientException ex)
            {
                throw ex;
            }
            //Catch system Exception
            catch (SystemException ex)
            {
                throw ex;
            }
            return desPat;
        }
    }
}
