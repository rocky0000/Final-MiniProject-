﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Exception
{
    /// <summary>
    /// Employee ID        :   94127
    /// Employee Name      :   Rahul Yadav
    /// Description        :   This is Exception class for Patient
    /// Date of Creation   :   19/09/2016
    /// </summary>
    public class PatientException : ApplicationException
    {
        
        //Default constructor for Employee Exception Class
        public PatientException()
            :base()
        { }

        //Parameterized constructor for Employee Exception Class
        public PatientException(string msg)
            :base(msg)
        { }
    }
}
