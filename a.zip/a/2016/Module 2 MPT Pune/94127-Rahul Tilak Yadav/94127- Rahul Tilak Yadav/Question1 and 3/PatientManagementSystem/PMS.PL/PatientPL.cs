﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Entity;       //Reference to Patient Entity
using PMS.Exception;    //Reference to Patient Exception
using PMS.BL;           //Reference to Patient BL

namespace PMS.PL
{
    /// <summary>
    /// Employee ID        :   94127
    /// Employee Name      :   Rahul Yadav
    /// Description        :   This is Presentation Layer class for Patient
    /// Date of Creation   :   19/09/2016
    /// </summary>
    class PatientPL
    {
        // Initialize patient id to 101 so that it can be auto generated while entering the details
        static int patientid = 101;
        //Function to add new patient details to the list of patients
        public static void AddPatient()
        {
            Patient newPat = new Patient();
            try
            {
                // Reading the Patient Details
                Console.Write("Patient ID : ");
                newPat.PatID = patientid;
                Console.Write(patientid);
                Console.Write("\nEnter Patient Name : ");
                newPat.PatientName = Console.ReadLine();
                Console.Write("Enter Phone Number : ");
                newPat.PhoneNo = Console.ReadLine();
                Console.Write("Enter Age : ");
                newPat.Age = Convert.ToInt32(Console.ReadLine());
                
                bool patientAdded = PatientBL.AddPatient(newPat);

                if (patientAdded)
                {
                    //Incrementing patient id for the next patient only if current patient is added
                    patientid++;
                    Console.WriteLine("Patient Details Added Successfully");
                }
                else
                {
                    throw new PatientException("Patient Details Not Added");
                }
            }
            //Catch User Defined Exception
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            //Catch System Exception
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Function to search Patient details from the list of patients
        public static void SearchPatient()
        {
            Patient newPat = new Patient();
            try
            {
                int patID;
                //Searching Patient details on the basis of patient ID
                Console.Write("Enter Patient Id for Patient whose Information you would like to Search : ");
                patID = Convert.ToInt32(Console.ReadLine());
                Patient patientSearched = PatientBL.searchPatient(patID);

                //Check if the patient is present
                if (patientSearched != null)
                {
                    Console.WriteLine("Patient Id : " + patientSearched.PatID);
                    Console.WriteLine("Patient Name : " + patientSearched.PatientName);
                    Console.WriteLine("Phone Number : " + patientSearched.PhoneNo);
                    Console.WriteLine("Age : " + patientSearched.Age);
                   
                }
                else
                    throw new PatientException("Patient with patient ID: " + patID + " not found");
            }
            //Catch User Defined Exception
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            //Catch System Exception
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to display details of all Patients
        public static void DisplayAllPatient()
        {
            try
            {
                List<Patient> patList = PatientBL.DisplayAllPatient();
                if (patList.Count > 0)
                {
                    Console.WriteLine("***************************************************************************");
                    Console.WriteLine("Patient Id\t Patient Name\t Phone No.\t Age");
                    Console.WriteLine("***************************************************************************");
                    foreach (Patient pat in patList)
                    {
                        Console.WriteLine(pat.PatID + "\t\t" + pat.PatientName + "\t\t" + pat.PhoneNo + "\t" + pat.Age );
                    }
                }
                else
                    throw new PatientException("There is no data available for the Patient");
            }
            //Catch User Defined Exception
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            //Catch System Exception
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to perform serialization on patient details
        public static void SerializePatient()
        {
            try
            {
                bool patSerialzed = PatientBL.SerializePatient();
                if (patSerialzed)
                {
                    Console.WriteLine("\nPatient data is Serialized");
                }
                else
                    throw new PatientException("Patient data is not Serialized");
            }
            //Catch User Defined Exception
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            //Catch User Defined Exception
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to perform serialization on patient details
        public static void DeserializePatient()
        {
            try
            {
                List<Patient> patList = PatientBL.DeserializePatient();
                if (patList.Count > 0)
                {
                    Console.WriteLine("***************************************************************************");
                    Console.WriteLine("Patient Id\t Patient Name\t Phone No.\t Age");
                    Console.WriteLine("***************************************************************************");
                    foreach (Patient pat in patList)
                    {
                        Console.WriteLine(pat.PatID + "\t\t" + pat.PatientName + "\t\t" + pat.PhoneNo + "\t" + pat.Age);
                    }
                
                    Console.WriteLine("Patient data is Deserialized");
                }
                else
                    throw new PatientException("There is No Data in the list");
            }
            //Catch User Defined Exception
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            //Catch User Defined Exception
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void PrintMenu()
        {
            //Displaying the List of choices
            Console.WriteLine("\n************************************************************");
            Console.WriteLine("1. Add New Patient Details");
            Console.WriteLine("2. Search Patient Details");
            Console.WriteLine("3. Display All Patient Details");
            Console.WriteLine("4. Serialize Patient Details");
            Console.WriteLine("5. Deserialize Patient Details");
            Console.WriteLine("6. Exit");
            Console.WriteLine("************************************************************");

        }
        static void Main(string[] args)
        {
            int choice = 0;
            try
            {
                do
                {
                    //Displaying the List of choices
                    PrintMenu();
                    Console.WriteLine("Enter Your Choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;
                        case 2: SearchPatient();
                            break;
                        case 3: DisplayAllPatient();
                            break;
                        case 4: SerializePatient();
                            break;
                        case 5: DeserializePatient();
                            break;
                        case 6: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("Please provide valid choice");
                            break;
                    }
                } while (choice != 6);

            }

            //Catch System Exception
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
