﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace PMS.Entity
{
    /// <summary>
    /// Employee ID        :   94127
    /// Employee Name      :   Rahul Yadav
    /// Description        :   This is Entity class for Patient
    /// Date of Creation   :   19/09/2016
    /// </summary>
    [Serializable]
    public class Patient
    {
        //Property fot Get or Set Patient ID
        public int PatID { get; set; }

        //Property fot Get or Set Patient Name
        public String PatientName { get; set; }

        //Property fot Get or Set Phone No
        public string PhoneNo { get; set; }

        //Property fot Get or Set Age
        public int Age { get; set; }
    }
}
