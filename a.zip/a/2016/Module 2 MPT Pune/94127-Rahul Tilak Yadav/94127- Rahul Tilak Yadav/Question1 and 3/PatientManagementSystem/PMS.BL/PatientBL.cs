﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Entity;       //Reference to Patient Entity
using PMS.Exception;    //Reference to Patient Exception
using PMS.DAL;          //Reference to Patient DAL
using System.Text.RegularExpressions;

namespace PMS.BL
{
    /// <summary>
    /// Employee ID        :   94127
    /// Employee Name      :   Rahul Yadav
    /// Description        :   This is Business Layer class for Patient
    /// Date of Creation   :   19/09/2016
    /// </summary>
    public class PatientBL
    {
        //Function to validate Patient Data
        public static bool ValidatePatient(Patient pat)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();

            try
            {
               
                //Check validation of Patient Name for alphabets and spaces only with first alphabet as capital
                if (!Regex.IsMatch(pat.PatientName, "[A-Z][a-z ]+"))
                {
                    msg.Append("Patient Name should have alphabets and spaces only and it should start with capital letter \n");
                    validPatient = false;
                }
                //Check validation of phone number for  10 digits and first digit to be 7,8 or 9 
                if (!Regex.IsMatch(pat.PhoneNo, "[789][0-9]{9}"))
                {
                    msg.Append("Phone No should be of 10 Digits and first digit should be 7 or 8 or 9 \n");
                    validPatient = false;
                }
                //Check validation for Age to be within 0 and 100
                if (pat.Age < 0 || pat.Age > 100)
                {
                    msg.Append("Patient age should be within 0 yrs to 100 yrs \n");
                    validPatient = false;
                }
               
                if (validPatient == false)
                {
                    throw new PatientException(msg.ToString());
                }
            }

            //Catch User Defined Exception
            catch (PatientException ex)
            {
                throw ex;
            }

            //Catch System Exception
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }

        //Function to check validity and add new Patient details
        public static bool AddPatient(Patient newPat)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPat))
                {
                    
                    patientAdded = PatientDAL.AddPatient(newPat);
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }
            }
            //Catch User Defined Exception
            catch (PatientException ex)
            {
                throw ex;
            }
            //Catch System Exception
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }
        //Function to check validity and search Patient details
        public static Patient searchPatient(int patID)
        {
            Patient patientSearched = null;
            try
            {
                
                patientSearched = PatientDAL.SearchPatient(patID);
            }
            //Catch User Defined Exception
            catch (PatientException ex)
            {
                throw ex;
            }
            //Catch System Exception
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }
        //Function to display all Patient details
        public static List<Patient> DisplayAllPatient()
        {
            List<Patient> patList = PatientDAL.DisplayAllPatient();
            return patList;
        }

        //Function to perform serialization on patient details
        public static bool SerializePatient()
        {
            bool patSerialized = false;
            try
            {
                patSerialized = PatientDAL.SerializePatient();

            }

            //Catch User Defined Exception
            catch (PatientException ex)
            {
                throw ex;
            }
            //Catch System Exception
            catch (SystemException ex)
            {
                throw ex;
            }
            return patSerialized;
        }

        //Function to perform Deserialization on patient details
        public static List<Patient> DeserializePatient()
        {
            List<Patient> despat = null;
            try
            {
                despat = PatientDAL.DeserilaizePatient();
            }

            //Catch User Defined Exception
            catch (PatientException ex)
            {
                throw ex;
            }
            //Catch System Exception
            catch (SystemException ex)
            {
                throw ex;
            }
            return despat;
        }
    }
}
