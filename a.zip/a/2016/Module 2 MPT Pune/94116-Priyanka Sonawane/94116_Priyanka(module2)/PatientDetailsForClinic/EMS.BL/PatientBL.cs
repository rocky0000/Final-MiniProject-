﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using EMS.Entity;   //Reference to Patient Entity
using EMS.Exception; //Reference to Patient Exception
using EMS.DAL;  //Reference to Data Access Layer

namespace EMS.BL

{
    /// <summary>
    /// Employee ID :94116
    /// Employee Name : Priyanka Sonawane
    /// Description :Bussiness Layer
    /// Date of Creation :19/09/2016
    /// </summary>
    public class PatientBL
    {

        //Function to validate the patient data
        public static bool ValidatePatient(Patient pat)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();
            try
            {
                
                //To validate Patient Name
                if (!Regex.IsMatch(pat.PatientName, "[A-Z][a-z ]+"))
                {
                    msg.Append("Patient Name should have alphabets and spaces only and it should start with capital letter\n");
                    validPatient = false;
                }

                //To validate Phone NO
                if (!Regex.IsMatch(pat.PhoneNo, "[789][0-9]{9}"))
                {
                    msg.Append("Phone No should have 10 digits and it should start with 7 or 8 or 9 and the first digit cannot be 0\n");
                    validPatient = false;
                }

                //To validate Patient Age
                if (pat.Age < 0 || pat.Age > 100)
                {
                    msg.Append("Employee Age should not be negative and should not be greater than 100\n");
                    validPatient = false;
                }
             if (validPatient == false)
                    throw new PatientException(msg.ToString());
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validPatient;
        }
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;
            try 
            {
                if (ValidatePatient(newPatient))
                {
                    patientAdded  = PatientDAL.AddPatient(newPatient);
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }
        public static Patient SearchPatient(int patID)
        {
            Patient patientSearched = null;

            try 
            {
               patientSearched = PatientDAL.SearchPatient(patID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearched;
        }

        //Serialization validation
        public static bool SerializePatient()
        {
            bool patSerialized = false;

            try
            {
                patSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            return patSerialized;
        }

        //Deserailization validation
        public static List<Patient> DeserializePatient()
        {
            List<Patient> patList = null;

            try
            {
                patList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patList;
        }

      }

  }
    

