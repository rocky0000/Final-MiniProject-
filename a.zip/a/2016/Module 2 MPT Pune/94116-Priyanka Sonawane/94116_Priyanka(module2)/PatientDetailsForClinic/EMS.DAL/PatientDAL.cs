﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity; //Reference to Patient Entity.
using EMS.Exception; //Reference to Patient Exception.
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace EMS.DAL
{
    /// <summary>
    /// Employee ID :94116
    /// Employee Name :Priyanka Sonawane
    /// Description : Data Access Layer
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientDAL
    {
        static List<Patient> patientList = new List<Patient>();
        //Function to add new Patient to the list of patients
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;

            try 
            {
                //Adding Patient
                patientList.Add(newPatient);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientAdded;
        }
        //Function for searching patient from list of patient
        public static Patient SearchPatient(int PatientID)
        {
            Patient patientSearched = null;

            try
            {
                //searching patient
                patientSearched = patientList.Find(emp => emp.PatientID == PatientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearched;
        }
        //Serializing Patient Data
        public static bool SerializePatient()
        {
            bool patientSerialized = false;

            try
            {
                if (patientList.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binFormat = new BinaryFormatter();
                    binFormat.Serialize(fs, patientList);
                    patientSerialized = true;
                    fs.Close();
                }
                else
                    throw new PatientException("No patient data so cannot be serialized");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSerialized;
        }

        //Deserializing Patient Data
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPatient = null;

            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormat = new BinaryFormatter();
                desPatient = (List<Patient>)binFormat.Deserialize(fs);
                fs.Close();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desPatient;
        }

    }
}
