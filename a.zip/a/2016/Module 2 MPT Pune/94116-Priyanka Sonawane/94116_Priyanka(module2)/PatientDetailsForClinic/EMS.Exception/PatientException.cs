﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Exception
{

    /// <summary>
    /// Employee ID :94116
    /// Employee Name :Priyanka Sonawane
    /// Description :This is Exception Layer
    /// Date of Creation :19/09/2016
    /// </summary>
    public class PatientException : ApplicationException
    {
        public PatientException()
            : base()
        { }

        public PatientException(string msg)
            : base(msg)
        { }

    }
}
