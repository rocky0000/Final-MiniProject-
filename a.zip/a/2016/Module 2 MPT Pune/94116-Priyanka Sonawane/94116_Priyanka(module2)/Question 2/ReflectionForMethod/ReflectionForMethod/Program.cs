﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ReflectionForMethod
{
    /// <summary>
    /// Employee Id:94116
    /// Employee Name:Priyanka Sonawane
    /// Date of Creation:19/09/2016
    /// Description:Refection for method Do Work.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("NumberSquare.dll");

            Type empType = myAssembly.GetType("NumberSquare.Test");

            MethodInfo[] empMethods = empType.GetMethods();
            foreach (MethodInfo m in empMethods)
            {
                Console.WriteLine("Method Name : " + m.Name);
                Console.WriteLine("Contains Generic Parameters : " + m.ContainsGenericParameters);
                Console.WriteLine("Return Type:" + m.ReturnType);
                Console.WriteLine("Is Static : " + m.IsStatic);
                Console.WriteLine("Parameter name:" + m.ReturnParameter);
               


                MethodInfo subMethod = empType.GetMethod("DoWork");
                int result = (int)subMethod.Invoke(null, new object[] { 3});
                Console.WriteLine("Square result is : " + result);


                Console.ReadKey();

            }
        }
    }
}