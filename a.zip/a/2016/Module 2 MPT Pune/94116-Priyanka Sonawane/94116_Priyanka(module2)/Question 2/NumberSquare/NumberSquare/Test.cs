﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberSquare
    
{
    /// <summary>
    /// Employee Id:94116;
    /// Employee Name:Priyanka Sonawane
    /// Date of Creation:19/09/2016
    /// Description:Created a class which contains method DoWork
    /// </summary>
    public class Test
    {
        //Method which returns Square of number
        public static int DoWork(int parameter)
        {
            return parameter * parameter;
        }
    }
}
