﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PD.Entity;          //reference to patient entity
using PD.Exception;       //reference to patient exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace PD.DAL
{
    /// <summary>
    /// Employee ID:94108
    /// Employee Name:Riddhi Karandikar
    /// Description:Data Access Layer of Patient
    /// Date of Creation:19/09/2016
    /// </summary>

    public class PatientDAL
    {
        static List<Patient> pntlist = new List<Patient>();
        public static int count = 100;

        //function to add new patient to the list of patients
        public static bool AddPatient(Patient newPnt)
        {
            bool patientAdded = false;

            try
            {
                //Adding patient
                newPnt.PatientID = count;
                pntlist.Add(newPnt);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientAdded;
        }

        //function to search patient from the patient list
        public static Patient SearchPatient(int pntID)
        {
            Patient pntSearched = null;

            try
            {
                //seraching patient
                pntSearched = pntlist.Find(pnt => pnt.PatientID == pntID);
            }

            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return pntSearched;
        }

        public static bool SerializePatient()
        {
            bool pntSerialized = false;

            try
            {
                if (pntlist.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binformat = new BinaryFormatter();
                    binformat.Serialize(fs, pntlist);
                    pntSerialized = true;
                    fs.Close();
                }
                else
                {
                    throw new PatientException("No patient data so cannot be serialized");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return pntSerialized;
        }

        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPnt = null;
            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binformat = new BinaryFormatter();
                desPnt = (List<Patient>)binformat.Deserialize(fs);
                fs.Flush();
                fs.Close();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return desPnt;
        }
    }
}
        
    

