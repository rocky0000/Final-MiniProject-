﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PD.Entity;     //reference for patient entity
using PD.Exception;  //reference for patient exception
using PD.BL;         //reference for business layer
using PD.DAL;        //reference for data access layer

namespace PD.PL
{
    /// <summary>
    /// Employee ID:94108
    /// Employee Name:Riddhi Karandikar
    /// Description:Presentation layer of patient
    /// Date of Creation:16/09/2016
    /// </summary>
    
    class PatientPL
    {
        //to add patient in the list taking input from the user
        public static void AddPatient()
        {
            Patient newPnt = new Patient();

            try 
            {
                

                Console.Write("Enter Patient Name :");
                newPnt.PatientName = Console.ReadLine();

                Console.Write("Enter Phone No :");
                newPnt.PhoneNo = Console.ReadLine();

                Console.Write("Enter Age :");
                newPnt.Age =Convert.ToInt32(Console.ReadLine());

                bool patientAdded = PatientBL.AddPatient(newPnt);

                if (patientAdded)
                {
                    Console.WriteLine("Patient Added successfully");
                }
                else
                {
                    throw new PatientException("Patient not added");
                }
            }

            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        //to get the input from the user which needs to be searched
        public static void SearchPatient()
        {
            try
            {
                int pntID;
                Console.Write("Enter the patient ID for patient to be searched");
                pntID = Convert.ToInt32(Console.ReadLine());

                Patient pnt = PatientBL.SearchPatient(pntID);

                if (pnt != null)
                {
                    //Console.WriteLine("Employee ID :" + emp.EmployeeID);
                    Console.WriteLine("Patient Name :" + pnt.PatientName);
                    Console.WriteLine("Patient Phone No :" + pnt.PhoneNo);
                    Console.WriteLine("Patient Age :" + pnt.Age);
                }

                else
                {
                    throw new PatientException("Patient not found with employee ID :" + pntID);
                }

            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializePatient()
        {
            try
            {
                bool pntSerialized = PatientBL.SerializePatient();
                if (pntSerialized)
                {
                    Console.WriteLine("Patient data is serialized");
                }
                else
                {
                    throw new PatientException("Patient data is not serialized");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        public static void DeserializePatient()
        {
            try
            {
                List<Patient> pntlist = PatientBL.DeserializePatient();

                if (pntlist != null)
                {
                    Console.WriteLine("*********************************************");
                    Console.WriteLine("Patient ID \t Patient Name \t Phone No \t Age \t");
                    Console.WriteLine("*********************************************");

                    foreach (Patient pnt in pntlist)
                    {
                        Console.WriteLine(pnt.PatientID + "\t\t" + pnt.PatientName + "\t\t" + pnt.PhoneNo + "\t\t" + pnt.Age + "\t\t");
                    }
                }
                else
                {
                    throw new PatientException("Patient data is not serialized");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        //to print the data based on user's choice
        public static void PrintMenu()
        {
            Console.WriteLine("\n******************************************");
            Console.WriteLine("1. Add Patient");
            Console.WriteLine("2. Search Patient");
            Console.WriteLine("3. Serialize Patient");
            Console.WriteLine("4. Deserialize Patient");
            Console.WriteLine("5. Exit");
            Console.WriteLine("******************************************");
        }

        static void Main(string[] args)
        {
            int choice = 0;

            try
            {
                do
                {
                    PrintMenu();

                    Console.Write("Enter your Choice :");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: AddPatient();
                            PatientDAL.count++;
                            break;
                        case 2: SearchPatient();
                            break;
                        case 3: SerializePatient();
                            break;
                        case 4: DeserializePatient();
                            break;
                        case 5: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("Please provide valid choice ");
                            break;
                    }
                }
                while (choice != 6);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }


            Console.ReadKey();
        }
    }
}
