﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PD.Entity
{
    /// <summary>
    /// Employee ID:94108
    /// Employee Name:Riddhi Karandikar
    /// Description:This is Entity class for Patient
    /// Date of Creation:19/09/2016
    /// </summary>

    [Serializable]
    public class Patient
    {
        //Property for gets or sets Patient ID
        public int PatientID { get; set; }

        //Property for gets or sets Patient Name
        public string PatientName { get; set; }

        //Property for gets or sets Age
        public int Age { get; set; }

        //Property for gets or sets Phone No
        public string PhoneNo { get; set; }
       
    }
}
