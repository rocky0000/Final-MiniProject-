﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using PD.Entity;     //reference to patient entity
using PD.Exception;  //reference to patient exception
using PD.DAL;        //reference to patient Data access layer

namespace PD.BL
{
    /// <summary>
    /// Employee ID:94108
    /// Employee Name:Riddhi Karandikar
    /// Description:Business layer of patient
    /// Date of Creation:19/09/2016
    /// </summary>
    
    public class PatientBL
    {
        //function to validate the patient data
        public static bool ValidatePatient(Patient pnt)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();

            try
            {
                //function to check valid patient ID
                if (pnt.PatientID > 9999)
                {
                    msg.Append("Patient ID should not be greater than 9999\n");
                    validPatient = false;
                }

                //function to check valid patient name
                if (!Regex.IsMatch(pnt.PatientName, "[A-Z][a-z ]+"))
                {
                    msg.Append("Patient name should have alphabets and spaces only and it should start with capital letter\n");
                    validPatient = false;
                }

                //function to check valid patient phone number
                if (!Regex.IsMatch(pnt.PhoneNo, "[789][0-9]{9}"))
                {
                    msg.Append("Phone number should have 10 digits and it should start with 7 or 8 or 9");
                    validPatient = false;
                }

                //function to check valid patient age
                if (pnt.Age < 0 || pnt.Age > 100)
                {
                    msg.Append("Patient age should not be negative and age should be less than 100\n");
                    validPatient = false;
                }

                if (validPatient == false)
                {
                    throw new PatientException(msg.ToString());
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return validPatient;
        }

        //to add patient if valid
        public static bool AddPatient(Patient newPnt)
        {
            bool patientAdded = false;

            try
            {
                if (ValidatePatient(newPnt))
                {
                    patientAdded = PatientDAL.AddPatient(newPnt);
                }
                else
                {
                    throw new PatientException("Please provide valid data for patient\n");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //to search patient if vaild
        public static Patient SearchPatient(int pntID)
        {
            Patient patientSearched = null;
            try
            {
                patientSearched = PatientDAL.SearchPatient(pntID);
            }

            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearched;
        }

        public static bool SerializePatient()
        {
            bool pntSerialized = false;

            try
            {
                pntSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            return pntSerialized;
        }

        public static List<Patient> DeserializePatient()
        {
            List<Patient> pntList = null;

            try
            {
                pntList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return pntList;
        }
    }
}
