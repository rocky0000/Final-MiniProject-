﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PD.Exception
{
    /// <summary>
    /// Employee ID:94108
    /// Employee Name:Riddhi Karandikar
    /// Description:Exception Handling
    /// Date of Creation:19/09/2016
    /// </summary>
    
    public class PatientException:ApplicationException
    {
        public PatientException()
                : base()
            { }

            public PatientException(string msg)
                : base(msg)
            { }
        
    }
}
