﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WorkQ2;
using System.Reflection;

namespace DoWorkQ2
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly mass = Assembly.LoadFrom("WorkQ2.dll");
            
            Type testType = mass.GetType("WorkQ2.Test");

            MethodInfo[] empMethods = testType.GetMethods();

            object TestObj = mass.CreateInstance("WorkQ2.Test");


            Console.WriteLine("Enter the number : ");
            int parameter = Convert.ToInt32(Console.ReadLine());


            MethodInfo squareMethod = testType.GetMethod("DoWork");

            int result1 = (int)squareMethod.Invoke(TestObj, new object[] {parameter});

            Console.WriteLine("DoWork Result is:" + result1);



            foreach (MethodInfo m in empMethods)
            {
                Console.WriteLine("Method Name is : " + m.Name);
                Console.WriteLine("Return Type is : " + m.ReturnType);
                Console.WriteLine("Instance is : " + m.IsStatic);
                Console.WriteLine("Parameter Name is : " +m.ReturnType.Name);
                Console.WriteLine("Parameter type is : " +m.ReturnParameter);
            }
            
            Console.ReadKey();



        }
    }
}
