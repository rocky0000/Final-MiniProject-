﻿//Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestLibraryDemo
{

    /// <summary>
    /// Employee ID :94130
    /// Employee Name :Radhika Dehaley
    /// Description : This is Test Class with method DoWork
    /// Date of Creation : 19/09/2016
    /// </summary>
   
    //class test
    public class Test
    {
        //Dowork method with single parameter
        public static int DoWork(int number)//number is a parameter with type int
        {
            //returns the square of the number
            return (number * number);
        }
    }
}
