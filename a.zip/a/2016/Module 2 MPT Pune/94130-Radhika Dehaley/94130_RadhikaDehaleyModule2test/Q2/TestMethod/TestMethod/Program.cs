﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;//Namespace Reflection for getting the reflection Method metadata
using TestLibraryDemo;//Reference of the TestLibraryDemo

namespace TestMethod
{

    /// <summary>
    /// Employee ID :94130
    /// Employee Name :Radhika Dehaley
    /// Description : This is Main program Class that calls the Reflection Method data and the DoWork method in the TestLibraryDemo 
    /// Date of Creation : 19/09/2016
    /// </summary>

    class Program
    {
        //Main program
        static void Main(string[] args)
        {

            //Laoding the TestLibraryDemo file
            Assembly myAssembly = Assembly.LoadFrom("TestLibraryDemo.dll");//refering the TestLibraryDemo


            Type testType = myAssembly.GetType("TestLibraryDemo.Test");//refering the Test class from the TestLibraryDemo

            //creating the object for the Methodinfo
            MethodInfo[] testMethods = testType.GetMethods();

            foreach (MethodInfo m in testMethods)
            {
                //printing the metadata about the DoWork method
                Console.WriteLine();
                Console.WriteLine("***************************************************************************");
                Console.WriteLine();
                Console.WriteLine("Method Name is                               :" + m.Name);
                Console.WriteLine("Is there Special Name                        :" + m.IsSpecialName);
                Console.WriteLine("Return Type for the Method is                :" + m.ReturnType);
                Console.WriteLine("The Static or Instances of the method are    :" + m.IsStatic);
                Console.WriteLine("Is The Method Public                         :" + m.IsPublic);  
                Console.WriteLine("The Parameters name of the Method is         :" + m.ReturnParameter);
                Console.WriteLine("Does The Methos Contain generic parameters   :" + m.ContainsGenericParameters);
                Console.WriteLine("The Reflected Type of the Method             :" + m.ReflectedType);
                Console.WriteLine("Is the Method Private                        :" + m.IsPrivate);
                Console.WriteLine("Is the Method Security Critical              :" + m.IsSecurityCritical);
                Console.WriteLine("Is the method Security Transparent           :" + m.IsSecurityTransparent);
                Console.WriteLine("Is the method Virtual                        :" + m.IsVirtual);
                Console.WriteLine("Is the Method member Type                    :" + m.MemberType);
                Console.WriteLine("Is the Method Metada Token                   :" + m.MetadataToken);
                Console.WriteLine("The Module is                                :" + m.Module);
                Console.WriteLine("The Reflected Type Custom Attributes         :" +m.ReturnTypeCustomAttributes);
                Console.WriteLine("The Member Type                              :" + m.MemberType);
                Console.WriteLine();
                Console.WriteLine("***************************************************************************");
                Console.WriteLine();
            }

            //Calling the DoWork Method from the TeatLibraryDemo
            MethodInfo testMethod = testType.GetMethod("DoWork");
            int result = (int)testMethod.Invoke(null, new object[] { 70 });

            //Printing the Square of the Number
            Console.WriteLine();
            Console.WriteLine("************************************************* ");
            Console.WriteLine();
            Console.WriteLine("The Square of the Number is : " + result);
            Console.WriteLine();
            Console.WriteLine("************************************************* ");


            //Printing the result by creating the object
            object calcObj = myAssembly.CreateInstance("TestLibraryDemo.Test");
            MethodInfo test1Method = testType.GetMethod("DoWork");
            int result1 = (int)test1Method.Invoke(null, new object[] { 30 });


            //Printing the Square of the Number
            Console.WriteLine();
            Console.WriteLine("************************************************* ");
            Console.WriteLine();
            Console.WriteLine("The Square of the Number is : " + result1);
            Console.WriteLine();
            Console.WriteLine("************************************************* ");

            Console.ReadKey();
        }
    }
}
