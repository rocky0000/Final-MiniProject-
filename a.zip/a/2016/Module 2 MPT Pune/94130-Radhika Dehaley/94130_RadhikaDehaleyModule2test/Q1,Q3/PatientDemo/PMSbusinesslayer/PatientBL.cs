﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions; //namespace for calling the Regex instances
using PMSEntity; //Reference to Patient Entity
using PMSException; //Reference to Patient Exception
using PMSDAL; //Reference to Patient Data Access layer

namespace PMSBusinessLayer
{

    /// <summary>
    /// Employee ID :94130
    /// Employee Name :Radhika Dehaley
    /// Description : This is Business Layer Class Patient
    /// Date of Creation : 19/09/2016
    /// </summary>

    //Patient Business Layer Class

    public class PatientBL
    {


        //Function to Validate the Patient data
        public static bool ValidatePatient(Patient pat)
        {
            bool validatePatient = true;//by default the values will be true
            StringBuilder msg = new StringBuilder();

            try
            {
                ////validating the Patient id that should be 3 digits
                //if (emp.PatientId<100||emp.Patient>999)
                //{
                //    msg.Append("Patient Id should be 3 digits\n");
                //    validatePatient = false;
                //}

                //validating the Patient name that should be string with first letter capital
                if (!Regex.IsMatch(pat.PatientName, "[a-z]+"))//+ indicates atleast one letter
                {
                    msg.Append("\nName should have alphabets and spaces only\n");
                    validatePatient = false;
                }

                //validating the phone number that should start with 7,8,9 and should have 10 digits
                if (!Regex.IsMatch(pat.PhoneNo, "[123456789][0-9]{9}"))
                {
                    msg.Append("\nPhone Number should have 10 digits and the first digit should not be 0 \n");
                    validatePatient = false;
                }

                //validating the age to be between 18 and 60
                if (pat.Age < 0 || pat.Age > 100)
                {
                    msg.Append("\nPatient age should not be negative or greater than 100 \n");
                    validatePatient = false;
                }

                if (validatePatient == false)
                {
                    throw new PatientException(msg.ToString());
                }

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validatePatient;
        }



        //Function for validating the input for the Patient to be added
        public static bool AddPatient(Patient newPat)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPat))
                {
                    patientAdded = PatientDAL.AddPatient(newPat);
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function for validating the Patient to be searched
        public static Patient SearchPatient(int patId)
        {
            Patient patientSearched = null;

            try
            {
                patientSearched = PatientDAL.SearchPatient(patId);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (System.SystemException ex)
            {
                throw ex;
            }
            return patientSearched;

        }

        ////Function for Validating the AllPatients to be displayed
        //public static List<Patient> DisplayPatient()
        //{
        //    List<Patient> empList = PatientDAL.DisplayAllPatient();
        //    return empList;

        //}

        //Function for Validating the Serialization of Patient
        public static bool SerializePatient()
        {
            bool patSerialize = false;

            try
            {
                patSerialize = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return patSerialize;
        }

        //Function for Validating the DeSerialization of Patient
        public static List<Patient> DeserializePatient()
        {
            List<Patient> patList = null;

            try
            {
                patList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return patList;
        }

    }
}