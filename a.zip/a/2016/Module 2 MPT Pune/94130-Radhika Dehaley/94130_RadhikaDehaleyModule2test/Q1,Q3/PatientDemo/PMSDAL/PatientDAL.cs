﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO; //Namespace contains types that allow Synchronous and Asynchronous reading & writing on data streams and files
using System.Runtime.Serialization.Formatters.Binary; //Namespace for Binary Serialization
using System.Runtime.Serialization; //Namesapce for Serialization and Deserialization
using PMSEntity; //Reference to Patient Entity
using PMSException; //Reference to Patient Exception

namespace PMSDAL
{

    /// <summary>
    /// Employee ID :94130
    /// Employee Name :Radhika Dehaley
    /// Description : This is Data Access Layer Class Patient
    /// Date of Creation : 19/09/2016
    /// </summary>

    //Patient Data Access layer Class
    public class PatientDAL
    {
        //creating list of patients to be added or stored
        static List<Patient> patList = new List<Patient>();

        //Function to add new Patient to the list of Patient
        public static bool AddPatient(Patient newPat)//newPat object is created 
        {
            bool patientAdded = false;

            try
            {
                //Adding Patient
                patList.Add(newPat);
                patientAdded = true; //if the Patient is added it returns true
            }
            //Exception used that is written in the exception class Library
            catch (PatientException ex)
            {
                throw ex;
            }

            // inbuild exception
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function for Searching the Patient by using the id
        public static Patient SearchPatient(int patId)
        {
            Patient patSearch = null;

            try
            {
                //Searching the Patient
                patSearch = patList.Find(emp => emp.PatientId == patId);

            }

            //Exception used that is written in the exception class Library
            catch (PatientException Exception)
            {
                throw Exception;
            }

             // inbuild exception
            catch (SystemException ex)
            {
                throw ex;
            }
            return patSearch;
        }

        ////Function for Displaying all the Patients 
        //public static List<Patient> DisplayAllPatient()
        //{
        //    //Displaying all the employees in the list
        //    return patList;
        //}

        //Function for Serializing the Patient 
        public static bool SerializePatient()
        {
            bool patSerialized = false;

            try
            {
                //serializing the patient
                if (patList.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binForm = new BinaryFormatter();
                    binForm.Serialize(fs, patList);
                    patSerialized = true;
                    fs.Close();
                }
                else
                {
                    throw new PatientException("No Patient data ,so cannot serialize");
                }
            }

            //Exception used that is written in the exception class Library
            catch (PatientException ex)
            {
                throw ex;
            }

             // inbuild exception
            catch (SystemException ex)
            {
                throw ex;
            }
            return patSerialized;
        }

        //Function for Deserializing the Patient 
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPat = null;

            try
            {
                //Deserializing the Patient
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binForm = new BinaryFormatter();
                desPat = (List<Patient>)binForm.Deserialize(fs);
                fs.Close();
            }

            //Exception used that is written in the exception class Library
            catch (PatientException ex)
            {
                throw ex;
            }

             // inbuild exception
            catch (SystemException ex)
            {
                throw ex;
            }
            return desPat;
        }

    }
}

