﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSException
{

    /// <summary>
    /// Employee ID :94130
    /// Employee Name :Radhika Dehaley
    /// Description : This is Exception Class Patient
    /// Date of Creation : 19/09/2016
    /// </summary>

    //Patient Exception Class
    public class PatientException : ApplicationException
    {
        //Default Patient Exception Constructor.
        public PatientException()
            : base()
        { }

        //Parameterised Patient Exception Constructor with Parameter msg as string
        public PatientException(string msg)
            : base(msg)
        {

        }

    }
}
