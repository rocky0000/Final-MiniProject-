﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace PMSEntity
{

    /// <summary>
    /// Employee ID :94130
    /// Employee Name :Radhika Dehaley
    /// Description : This is Entity Class Patient
    /// Date of Creation : 19/09/2016
    /// </summary>

    //Serializing the Patient Class
    [Serializable]
    //Class Patient
    public class Patient
    {
        //Property for Get or Set Patient Id
        public int PatientId { get; set; }

        //Property for Get or Set Patient Name
        public string PatientName { get; set; }

        //Property for Get or Set Patient Phone Number
        public string PhoneNo { get; set; }

        //Property for Get or Set Patient Age
        public int Age { get; set; }

    }
}
