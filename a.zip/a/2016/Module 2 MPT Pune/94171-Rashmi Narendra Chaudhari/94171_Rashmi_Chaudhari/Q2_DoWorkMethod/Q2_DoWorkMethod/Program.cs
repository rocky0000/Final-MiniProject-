﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoWorkLibrary;
using System.Reflection;

namespace Q2_DoWorkMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            //Creating assembly to load library file
            Assembly myAssembly = Assembly.LoadFrom("DoWorkLibrary.dll");

            Type pType = myAssembly.GetType("DoWorkLibrary.Calculate");

            MethodInfo[] pMethods = pType.GetMethods();

            int n = 0;
            foreach (MethodInfo m in pMethods)
            {
                n++;

                Console.WriteLine();
                Console.WriteLine("Method Name : " + m.Name);
                Console.WriteLine("Return Type : " + m.ReturnType.Name);
                Console.WriteLine("Is Static : " + m.IsStatic);

                if (n == 1)
               {
                 Console.WriteLine("Parameter Name : " + m.GetParameters().ElementAt(0).Name);
                 Console.WriteLine("Parameter Type : " + m.GetParameters().ElementAt(0).ParameterType);
               }    
               
            }
        
            //Displaying square of the number
            object calcObj = myAssembly.CreateInstance("DoWorkLibrary.Calculate"); //creating object of assembly
            MethodInfo square= pType.GetMethod("Square_Num"); 
            square.Invoke(calcObj, new object[] { 4 });
        }
    }
}
