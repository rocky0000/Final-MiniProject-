﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoWorkLibrary
{
    public class Calculate
    {
        //Function to calculate square of the number
        public static void Square_Num(int num)
        {
            Console.WriteLine("Square of the number {0} is : {1}", num, (num * num));
        }
    }
}
