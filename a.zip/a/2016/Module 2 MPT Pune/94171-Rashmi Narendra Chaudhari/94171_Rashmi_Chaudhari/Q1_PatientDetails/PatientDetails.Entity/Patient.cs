﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDetails.Entity
{    /// <summary>
    /// Employee ID      : 94171
    /// Employee Name    : Rashmi Narendra Chaudhari
    /// Description      : This is Entity class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    [Serializable]
    public class Patient
    {
        //Property for Get or Set Patient ID
          public int PatientID { get; set; }

       //Property for Get or Set Patient Name 
         public string PatientName { get; set; }

       //Property for Get or Set Patient Age
         public int Age { get; set; }

      //Property for Get or Set Patient PhoneNo
        public string PhoneNo { get; set; }
      
    }
}