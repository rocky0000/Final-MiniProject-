﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientDetails.Entity;//Reference of Patient Entity
using PatientDetails.Exception;//Reference of Patient Exception
using PatientDetails.BL;//Reference for PatientDetails.BL

namespace PatientDetails.PL
{
    /// <summary>
    /// Employee ID      : 94171
    /// Employee Name    : Rashmi Narendra Chaudhari
    /// Description      : This is PatientPL class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    class PatientPL
    {
       static int patID = 101;
        //Taking details from patient
        public static void AddPatient()
        {
            
            Patient newPatient = new Patient();

            try
            {
                newPatient.PatientID = patID++;
             
                Console.Write("Enter Employee Name : ");
                newPatient.PatientName = Console.ReadLine();
                Console.Write("Enter Phone No : ");
                newPatient.PhoneNo = Console.ReadLine();
                Console.Write("Enter Age : ");
                newPatient.Age = Convert.ToInt32(Console.ReadLine());


                bool patientAdded = PatientBL.AddPatient(newPatient);

                if (patientAdded)
                    Console.WriteLine("Patient Added Successfully");
                else
                    throw new PatientException("Patient not Added");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Searching logic based on ID to be searched
        public static void SearchPatient()
        {
            try
            {
                int patID;
                Console.Write("Enter Patient ID for Patient Which You Would Like to Search : ");
                patID = Convert.ToInt32(Console.ReadLine());

                Patient pat = PatientBL.SearchPatient(patID);

                if (pat != null)
                {
                    Console.WriteLine("Patient ID : " + pat.PatientID);
                    Console.WriteLine("Patient Name : " + pat.PatientName);
                    Console.WriteLine("Phone Number : " + pat.PhoneNo);
                    Console.WriteLine("Age : " + pat.Age);                   
                }
                else
                    throw new PatientException("Patient not found with Patient ID : " + patID);
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializePatient()
        {
            try
            {
                bool patientSerialized = PatientBL.SerializePatient();
                if (patientSerialized)
                    Console.WriteLine("Patient data is serialized");
                else
                    throw new PatientException("Patient Data is not Serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializePatient()
        {
            try
            {
                List<Patient> empList = PatientBL.DeserializePatient();

                if (empList != null)
                {
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("Patient ID \t Patient Name \t\t Phone No \t\t Age");
                    Console.WriteLine("************************************************************************************");
                    foreach (Patient pat in empList)
                    {
                        Console.WriteLine(pat.PatientID + "\t\t" + pat.PatientName + "\t\t" + pat.PhoneNo + "\t\t" + pat.Age);
                    }
                }
                else
                    throw new PatientException("There is not data");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("\n************************");
            Console.WriteLine("1. Add Patient");
            Console.WriteLine("2. Search Patient");
            Console.WriteLine("3. Serialize Patient");
            Console.WriteLine("4. Deserialize Patient");
            Console.WriteLine("5. Exit");
            Console.WriteLine("************************");
        }


        static void Main(string[] args)
        {
            int choice = 0;

            try 
            {
                do 
                {
                    PrintMenu();

                    Console.Write("\nEnter Your Choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;

                        case 2: SearchPatient();
                            break;
                        case 3: SerializePatient();
                            break;
                        case 4: DeserializePatient();
                            break;
                        case 5: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("Please provide valid choice");
                            break;
                    }
                } while (choice != 5);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
