﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientDetails.Entity; //Reference of Patient Entity
using PatientDetails.Exception;//Reference of Patient Exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace PatientDetails.DAL
{
    /// <summary>
    /// Employee ID      : 94171
    /// Employee Name    : Rashmi Narendra Chaudhari
    /// Description      : This is PatientDAL class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientDAL
    {
        static List<Patient> pList = new List<Patient>();

        //Function to add new patient to the list of patients
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;

            try
            {
                //Adding Patient
                pList.Add(newPatient);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientAdded;
        }

        //Function for searching patient from list of patients
        public static Patient SearchPatient(int patID)
        {
            Patient patientSearched = null;

            try
            {
                //searching employee
                patientSearched = pList.Find(pat => pat.PatientID == patID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearched;
        }

        //Function for Serialization of Patients list
         public static bool SerializePatient()
        {
            bool patientSerialized = false;
            
            try 
            {
                if (pList.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binFormat = new BinaryFormatter();
                    binFormat.Serialize(fs, pList);
                    patientSerialized = true;
                    fs.Close();
                }
                else
                    throw new PatientException("No patient data so cannot serialize");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSerialized;
        }
         //Function for Deserialization
        public static List<Patient> DeserializePatient()
        {
            List<Patient> des_patient = null;

            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormat = new BinaryFormatter();
                des_patient = (List<Patient>)binFormat.Deserialize(fs);
                fs.Close();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return des_patient;
        }
    }
}


