﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

using PatientDetails.Entity; //Reference of Patient Entity
using PatientDetails.Exception;//Reference of Patient Exception
using PatientDetails.DAL;//Reference for PatientDetails.DAL

namespace PatientDetails.BL
{
    /// <summary>
    /// Employee ID      : 94171
    /// Employee Name    : Rashmi Narendra Chaudhari
    /// Description      : This is PatientBL class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientBL
    {
        //Function to validate the patient data
        public static bool ValidatePatient(Patient p)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();

            try
            {                
                //Validating Patient name to be only characters
                if (!Regex.IsMatch(p.PatientName, "[A-Z][a-z ]+"))
                {
                    msg.Append("Patient Name should have only alphabets and spaces only and it should start with capital letter\n");
                    validPatient = false;
                }

               //Validating phone no. to be 1st no. greater than 0 ant total 10 digits
                if (!Regex.IsMatch(p.PhoneNo, "[1-9][0-9]{9}"))
                {
                    msg.Append("Phone No should have 10 digits and starting digit should not be 0 n");
                    validPatient = false;
                }
                //Validating whether age is positive and not greater than 100
                if (p.Age < 0 || p.Age > 100)
                {
                    msg.Append("Patient Age should not be negative or greater than 100\n");
                    validPatient = false;
                }

                if (validPatient == false)
                    throw new PatientException(msg.ToString());
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validPatient;
        }
         
        //Function for addingpatient details if Patient provides valid details 
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPatient))
                {
                    patientAdded = PatientDAL.AddPatient(newPatient);
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Searching Patient details
            public static Patient SearchPatient(int patID)
        {
            Patient patientSearched = null;

            try 
            {
                patientSearched = PatientDAL.SearchPatient(patID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearched;
        }

        //Serialize
        public static bool SerializePatient()
        {
            bool patientSerialized = false;

            try 
            {
                patientSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            return patientSerialized;
        }
        //Deserialize
        public static List<Patient> DeserializePatient()
        {
            List<Patient> pList = null;

            try 
            {
                pList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return pList;
        }
    }
}

    