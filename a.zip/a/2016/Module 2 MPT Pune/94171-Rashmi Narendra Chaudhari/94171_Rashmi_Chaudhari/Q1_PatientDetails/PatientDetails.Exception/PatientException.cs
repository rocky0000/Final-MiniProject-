﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDetails.Exception
{
    /// <summary>
    /// Employee ID      : 94171
    /// Employee Name    : Rashmi Narendra Chaudhari
    /// Description      : This is Exception class for Patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientException : ApplicationException
    {
        public PatientException()
            : base()
            { }

        public PatientException(string msg)
            : base(msg)
            { }
    }
}
    