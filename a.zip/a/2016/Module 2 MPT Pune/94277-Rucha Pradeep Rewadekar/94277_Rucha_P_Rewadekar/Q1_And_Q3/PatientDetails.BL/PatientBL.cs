﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientDetails.Entity;    //Reference to the Patient Entity
using PatientDetails.Exception; //Reference to the Patient Exception
using PatientDetails.DAL;   //Reference to the Patient DAL
using System.Text.RegularExpressions;//Reference 

namespace PatientDetails.BL
{
    /// <summary>
    /// Employee ID : 094277
    /// Employee Name : Ms.Rucha Pradeep Rewadekar           
    /// Description : This is BL Class For Patient
    /// Date Of Creation : 19/09/2016
    /// </summary>
    public class PatientBL
    {

        //Function to Validate Patient Class
        public static bool ValidatePatient(Patient pat)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();

            try
            {
                //To Validate the Patient's ID
                //if (pat.PatientID < 100 || pat.PatientID > 999)
                //{
                //    msg.Append("Emloyee ID should be 3 digits i.e between 100 and 999.\n");
                //    validPatient = false;
                //}

                //To Validate the Patient's Name
                if (!Regex.IsMatch(pat.PatientName, "[A-Z][a-z ]+"))
                {
                    msg.Append("Employee Name should have Alphabets and spaces only and it should start with Capital Letter.\n");
                    validPatient = false;
                }

                //To Validate the Patient's Age
                if (pat.Age < 0 || pat.Age > 100)
                {
                    msg.Append("Emloyee Age should be Between 0 and 100\n");
                    validPatient = false;
                }

                //To Validate the Patient's Phone no.
                if (!Regex.IsMatch(pat.PhoneNo, "[789][0-9]{9}"))
                {
                    msg.Append("Phone Number should have 10 digits and it should start with 7,8 or 9 and not with 0.\n");
                    validPatient = false;
                }

                //To Validate Patient details
                if (validPatient == false)
                    throw new PatientException(msg.ToString());
          
            }

            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return validPatient;
        }

        //Funtion to add Pateient data in Data List after validation
        public static bool AddPatient(Patient newPat)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPat))
                {
                    patientAdded = PatientDAL.AddPatient(newPat);
                }
                else
                {
                    throw new PatientException("Please Provide Valid Details about the Patient.\n");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function to Search the Patient Details for the given Patient ID
        public static Patient SearchPatient(int patID)
        {
            Patient patientSearched = null;

            try
            {
                patientSearched = PatientDAL.SerachPatient(patID);
            }

            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //Function to Serialize the Patient Class
        public static bool SerializePatient()
        {
            bool patSerialized = false;

            try
            {
                patSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            return patSerialized;
        }

        //Function to Deserialize the Patient Class
        public static List<Patient> DeserializePatient()
        {
            List<Patient> patList = null;

            try
            {
                patList = PatientDAL.DeserialziePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            return patList;
        }
    }
}
