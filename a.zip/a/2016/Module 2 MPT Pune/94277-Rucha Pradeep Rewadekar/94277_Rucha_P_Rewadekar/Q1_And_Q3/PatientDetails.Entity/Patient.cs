﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDetails.Entity
{
    /// <summary>
    /// Employee ID : 094277
    /// Employee Name : Ms.Rucha Pradeep Rewadekar           
    /// Description : This is Entity Class For Patient
    /// Date Of Creation : 19/09/2016
    /// </summary>
    
    [Serializable]
    public class Patient
    {

        //Property to Get or Set Patient ID
        public int PatientID { get; set; }

        //Property to Get or Set Patient's Name
        public string PatientName { get; set; }

        //Property to Get or Set Patient's Age
        public int Age { get; set; }

        //Property to Get or Set Patient's Phone Number
        public string PhoneNo { get; set; }
    }
}
