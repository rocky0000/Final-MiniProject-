﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDetails.Exception
{
    /// <summary>
    /// Employee ID : 094277
    /// Employee Name : Ms.Rucha Pradeep Rewadekar           
    /// Description : This is Exception Class For Patient
    /// Date Of Creation : 19/09/2016
    /// </summary>
    
    public class PatientException : ApplicationException
    {
        public PatientException()
            : base()
        { }

        public PatientException(string msg)
            : base(msg)
        { }

    }
}
