﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientDetails.Entity;    //Reference to Patient Entity
using PatientDetails.Exception; //Reference to Patient Exception
using System.IO;    //Reference to System IO
using System.Runtime.Serialization.Formatters.Binary;   //Reference to Binary Formatter

namespace PatientDetails.DAL
{
    /// <summary>
    /// Employee ID : 094277
    /// Employee Name : Ms.Rucha Pradeep Rewadekar           
    /// Description : This is DAL Class For Patient
    /// Date Of Creation : 19/09/2016
    /// </summary>
    
    public class PatientDAL
    {
        static List<Patient> patList = new List<Patient>();

        //Function to add details of a New Patient
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;

            try
            {
                //Adding a New Patient's Details
                patList.Add(newPatient);
                patientAdded = true;
            }

            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function to Search Details of an Existing Patient
        public static Patient SerachPatient(int patID)
        {
            Patient patientSearched = null;

            try
            {
                //Searching the Patient
                patientSearched =  patList.Find(pat => pat.PatientID == patID);
            }

            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //Function To Serialize the Patient Class
        public static bool SerializePatient()
        {
            bool patSerialized = false;

            try 
            {
                //Serializing the List, if List content is not null, using Binary Formatter
                if (patList.Count > 0)
                {
                    //Serializing Patient Class int0 PatientSerialize.txt File
                    FileStream fs = new FileStream("PatientSerialize.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binFormat = new BinaryFormatter();
                    binFormat.Serialize(fs, patList);
                    patSerialized = true;
                    fs.Close();
                }
                else
                    throw new PatientException("The Patient Details List does not contain any data, so List cannot be Serialized");
            }

            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return patSerialized;
        }

        //Function to Deserialize Patient Details 
        public static List<Patient> DeserialziePatient()
        {
            List<Patient> deserialPat = null;

            try
            {
                //Deserializing the Patient class
                FileStream fs = new FileStream("PatientSerialize.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormat = new BinaryFormatter();
                deserialPat = (List<Patient>)binFormat.Deserialize(fs);
                fs.Close();
            }

            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return deserialPat;
        }

    }
}
