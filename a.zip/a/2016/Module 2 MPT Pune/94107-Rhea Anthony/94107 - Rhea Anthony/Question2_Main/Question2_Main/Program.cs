﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Question2;

namespace Question2_Main
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly mass = Assembly.LoadFrom("Question2.dll");

            Type testType = mass.GetType("Question2.Test");

            MethodInfo calMethods = testType.GetMethod("DoWork");

            Console.WriteLine("Enter the number");
            int num1 = Convert.ToInt32(Console.ReadLine());

            object testObj = mass.CreateInstance("Question2.Test");

            MethodInfo sqMethod = testType.GetMethod("DoWork");
            int result = (int)sqMethod.Invoke(testObj, new object[] { num1 });
            Console.WriteLine("The Square of the number is " + result);

            Console.WriteLine();

            Console.WriteLine("Name:" + calMethods.Name);
            Console.WriteLine("Return Type:" + calMethods.ReturnType);
            Console.WriteLine("Is it Static:" + calMethods.IsStatic);
            Console.WriteLine("Parameter type:" + calMethods.ReturnParameter);
            Console.WriteLine("Parameter Name:" + calMethods.ReturnParameter.Name);
            Console.WriteLine();
        }
    }
}
