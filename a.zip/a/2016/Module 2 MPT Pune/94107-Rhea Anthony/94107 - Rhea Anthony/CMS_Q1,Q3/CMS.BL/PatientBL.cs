﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using CMS.Entity;//Reference to Patient Entity
using CMS.Exception;//Reference to Patient Exception
using CMS.DAL;//Reference to Patient DAL

namespace CMS.BL
{
    public class PatientBL
    {
        public static bool ValidatePatient(Patient pat)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();

            try
            {
                //validate Patient name
                if (!Regex.IsMatch(pat.PatientName, "[A-Z][a-z]+"))
                {
                    msg.Append("Patient Name should have Alphabets and spaces only and it should start with Capital Letter\n");
                    validPatient = false;
                }

                //validate Patient Phone No
                if (!Regex.IsMatch(pat.PhoneNo, "[1-9][0-9]{9}")) //for Phone nos starting from 7,8 or 9 , we can use "[789][0-9]{9}"
                {
                    msg.Append("Phone no should have 10 digits and it should start with any digit other than zero\n");
                    validPatient = false;
                }

                //validate Patient's Age
                if (pat.Age < 0 || pat.Age > 100)
                {
                    msg.Append("Patient's Age should be within the range 0 to 100\n");
                    validPatient = false;
                }

                if (validPatient == false)
                {
                    throw new PatientException(msg.ToString());
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }

        //Add only if Valid
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;

            try
            {
                if (ValidatePatient(newPatient))
                {
                    patientAdded = PatientDAL.AddPatient(newPatient);
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Search by ID only if valid
        public static Patient SearchPatientByID(int patientID)
        {
            Patient patientSearched = null;

            try
            {
                patientSearched = PatientDAL.SearchPatientByID(patientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //Serialize 
        public static bool SerializePatient()
        {
            bool patientSerialized = false;

            try
            {
                patientSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }

        //Deserialize
        public static List<Patient> DeserializePatient()
        {
            List<Patient> patientlist = null;
            try
            {
                patientlist = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientlist;
        }
    }
}
