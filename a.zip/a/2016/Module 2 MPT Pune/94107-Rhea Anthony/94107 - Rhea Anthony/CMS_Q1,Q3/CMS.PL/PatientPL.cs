﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Entity;//Reference to Patient Entity
using CMS.Exception;//Reference to Patient Exception
using CMS.DAL;//Reference to Patient DAL
using CMS.BL;//Reference to Patient BL

namespace CMS.PL
{
    class PatientPL
    {
        //To Accept details of the Patient to be added in the list of Patients 
        public static void AddPatient()
        {
            Patient newPatient = new Patient();
            try
            {
                Console.Write("Enter Patient Name:");
                newPatient.PatientName = Console.ReadLine();
                Console.Write("Enter Age:");
                newPatient.Age = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Patient Phone Number:");
                newPatient.PhoneNo = Console.ReadLine();


                bool patientAdded = PatientBL.AddPatient(newPatient);

                if (patientAdded)
                {
                    Console.WriteLine("Patient Added successfully");
                }
                else
                {
                    throw new PatientException("Patient not Added");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //To Accept details of the Patient whose info is to be searched in the list of Patients 
        public static void SearchPatientByID()
        {
            try
            {
                int patientID;
                Console.WriteLine("Enter the Patient ID of the Patient that you want to search\nPatient ID starts from 100\n");
                patientID = Convert.ToInt32(Console.ReadLine());

                Patient pat = PatientBL.SearchPatientByID(patientID);

                if (pat != null)
                {
                    Console.WriteLine("Patient ID:" + pat.PatientID);
                    Console.WriteLine("Patient Name:" + pat.PatientName);
                    Console.WriteLine("Age:" + pat.Age);
                    Console.WriteLine("Phone No:" + pat.PhoneNo);
                }
                else
                {
                    throw new PatientException("Patient with Patient ID" + patientID + "not Found");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializePatient()
        {
            try
            {
                bool patSerialized = PatientBL.SerializePatient();
                if (patSerialized)
                {
                    Console.WriteLine("Patient data is serialized");
                }
                else
                {
                    Console.WriteLine("Patient data is not serialized");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializePatient()
        {
            try
            {
                List<Patient> patientlist = PatientBL.DeserializePatient();
                if (patientlist != null)
                {
                    Console.WriteLine("***********************************************************************");
                    Console.WriteLine("Patient ID \t Patient Name \t Age\t Phone No");
                    Console.WriteLine("***********************************************************************");

                    foreach (Patient pat in patientlist)
                    {
                        Console.WriteLine(pat.PatientID + "\t\t " + pat.PatientName + "\t\t" + pat.Age + "\t" + pat.PhoneNo);
                    }
                }
                else
                {
                    throw new PatientException("There is no data");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to print Menu
        public static void Printmenu()
        {
            Console.WriteLine("\n******************************");
            Console.WriteLine("1.Add Patient");
            Console.WriteLine("2.Search Patient By ID");
            Console.WriteLine("3.Serialize Patient");
            Console.WriteLine("4.Deserialize Patient");
            Console.WriteLine("5.Exit");
            Console.WriteLine("******************************");
        }

        static void Main(string[] args)
        {
            int choice;
            try
            {
                do
                {
                    Printmenu();
                    Console.WriteLine("Enter your Choice");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1: AddPatient();
                            PatientDAL.count++;
                            break;
                        case 2: SearchPatientByID();
                            break;
                        case 3: SerializePatient();
                            break;
                        case 4: DeserializePatient();
                            break;
                        case 5: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("Please provide Valid Choice");
                            break;
                    }
                } while (choice != 5);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
