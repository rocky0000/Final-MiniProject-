﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Entity;//Reference to Patient Entity
using CMS.Exception;//Reference to Patient Exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace CMS.DAL
{
    public class PatientDAL
    {
        static List<Patient> patientlist = new List<Patient>();
        public static int count = 100;

        //Function to add new Patient to the list of Patients
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;

            try
            {
                //Adding Patient
                newPatient.PatientID = count;
                patientlist.Add(newPatient);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function to search Patient in the list of Patients
        public static Patient SearchPatientByID(int PatientID)
        {
            Patient patientSearched = null;

            //searching Patient
            try
            {
                patientSearched = patientlist.Find(pat => pat.PatientID == PatientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        public static bool SerializePatient()
        {
            bool patientSerialized = false;

            try
            {
                if (patientlist.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(fs, patientlist);
                    patientSerialized = true;
                    fs.Close();
                }
                else
                {
                    throw new PatientException("No Patient data so cannot be serialized");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }

        public static List<Patient> DeserializePatient()
        {
            List<Patient> deserializePatient = null;
            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                deserializePatient = (List<Patient>)bf.Deserialize(fs); 
                fs.Flush();
                fs.Close();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return deserializePatient;
        }
    }
}
