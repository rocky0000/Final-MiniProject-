﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Entity
{
    [Serializable]
    public class Patient
    {
        int patientID;
        string patientName;
        int age;
        string phoneNo;

        public int PatientID { get; set; }
        public string PatientName { get; set; }
        public int Age { get; set; }
        public string PhoneNo { get; set; }

        public Patient()
        {
            PatientID = 0;
            PatientName = null;
            Age = 0;
            PhoneNo = null;
        }
    }
}
