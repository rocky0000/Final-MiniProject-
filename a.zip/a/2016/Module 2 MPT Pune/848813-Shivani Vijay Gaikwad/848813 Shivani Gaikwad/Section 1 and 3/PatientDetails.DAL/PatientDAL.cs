﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using PatientDetails.Entity;        //Reference for Patient Entity
using PatientDetails.Exception;     //Reference for Patient Exception
using System.Runtime.Serialization.Formatters.Binary;

namespace PatientDetails.DAL
{
    /// <summary>
    /// Employee ID : 848813
    /// Employee Name : Shivani Gaikwad
    /// Description : This is the DAL Class for Patient Details
    /// Date of Creation : 19/9/2016
    /// </summary>
    public class PatientDAL
    {
        //static int PatientID=100;
        static List<Patient> patientList = new List<Patient>();

        //Function to add new Patient to the list of Patients
        public static bool AddPatientDetails(Patient newPatient)
        {
            bool patientAdded = false;

            try
            {
                //Adding Patient
                patientList.Add(newPatient);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function for Searching a Patient in the List of Patient
        public static Patient SearchPatient(int patientID)
        {
            Patient patientSearched = null;

            try
            {
                //Searching a Patient in the list
                patientSearched = patientList.Find(patient => Patient.PatientID == patientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //Display all the Patients in the List
        public static List<Patient> DisplayAllPatients()
        {
            return patientList;
        }

        //Function to Serialize Patient Class Object
        public static bool SerializePatient()
        {
            bool patientSerialized = false;

            try
            {
                if (patientList.Count > 0)
                {
                    FileStream fs = new FileStream(@"../../Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binformat = new BinaryFormatter();
                    binformat.Serialize(fs, patientList);
                    fs.Flush();
                    fs.Close();
                    patientSerialized = true;
                }
                else
                {
                    throw new PatientException("No Patient Data so cannot Serialize");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }

        //Function to Deserialize the Patient class object
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPatient = null;

            try
            {
                FileStream fs = new FileStream(@"../../Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binformat = new BinaryFormatter();
                desPatient = (List<Patient>)binformat.Deserialize(fs);
                fs.Flush();
                fs.Close();

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return desPatient;
        }

    }
}
