﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDetails.Entity
{
    /// <summary>
    /// Employee ID : 848813
    /// Employee Name : Shivani Gaikwad
    /// Description : This is the Entity Class for Patient Details
    /// Date of Creation : 19/9/2016
    /// </summary>
    [Serializable]
    public class Patient
    {
        //static variable PatientID initialized to 100
        public static int PatientID = 100;

        //Property for Get or Set Patient Name
        public string PatientName { get; set; }

        //Property for Get or Set Patient's Age
        public int Age { get; set; }

        //Property for Get or Set Patient's Mobile Number
        public string PhoneNumber { get; set; }
    }
}
