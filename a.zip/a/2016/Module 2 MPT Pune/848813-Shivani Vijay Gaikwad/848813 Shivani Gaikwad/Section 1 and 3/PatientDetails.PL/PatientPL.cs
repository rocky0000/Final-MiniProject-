﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientDetails.Entity;        //Reference to the Patient Entity 
using PatientDetails.Exception;     //Reference to the Patient Exception
using PatientDetails.BL;            //Reference to the Patient BL

namespace PatientDetails.PL
{
    /// <summary>
    /// Employee ID : 848813
    /// Employee Name : Shivani Gaikwad
    /// Description : This is the PL class for Patient Details
    /// Date of Creation : 19/09/2016
    /// </summary>
    
    class PatientPL
    {
        public static void AddPatientDetails()
        {
            Patient newPatient = new Patient();
            try
            {
                Console.Write("Enter Patient Name: ");
                newPatient.PatientName = Console.ReadLine();

                Console.Write("Enter Phone Number. : ");
                newPatient.PhoneNumber = Console.ReadLine();

                Console.Write("Enter Age: ");
                newPatient.Age = Convert.ToInt32(Console.ReadLine());

                bool patientAdded = PatientBL.AddPatientDetails(newPatient);

                if (patientAdded)
                    Console.WriteLine("Patient Record Added Successfully!");
                else
                    throw new PatientException("Patient Record not Added");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function for Searching a Patient from the list
        public static void SearchPatient()
        {
            try
            {
                int patientID;
                Console.Write("Enter Patient ID for Patient you would like to Search: ");
                patientID = Convert.ToInt32(Console.ReadLine());

                Patient patientSearched = PatientBL.SearchPatient(patientID);

                if (patientSearched != null)
                {
                    //Print the patient details
                    Console.WriteLine("Patient ID : " + Patient.PatientID);
                    Console.WriteLine("Patient Name : " + patientSearched.PatientName);
                    Console.WriteLine("Phone Number : " + patientSearched.PhoneNumber);
                    Console.WriteLine("Age : " + patientSearched.Age);
                }
                else
                {
                    throw new PatientException("Patient not found with Patient ID : " + patientID);
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function for displaying list of all Patients
        public static void DisplayAllPatients()
        {
            try
            {
                List<Patient> patientList = PatientBL.DisplayAllPatients();

                if (patientList.Count > 0)      //Check whether is list contains elements
                {
                    Console.WriteLine("*******************************************************************");
                    Console.WriteLine("Patient ID \t Patient Name \t\t Phone No. \t\t Age");
                    Console.WriteLine("*******************************************************************");
                    foreach (var item in patientList)   //Print the elements from the list
                    {
                        Console.WriteLine(Patient.PatientID + "\t\t " + item.PatientName + " \t\t" + item.PhoneNumber + "\t\t" + item.Age);
                    }
                }
                else
                {
                    throw new PatientException("There is no data available for Patient");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        //Function for Serializing Patient object
        public static void SerializePatient()
        {
            try
            {
                bool patientSerialized = PatientBL.SerializePatient();

                if (patientSerialized)
                {
                    Console.WriteLine("Patient Data is Serialized");
                }
                else
                {
                    throw new PatientException("Patient Data is not Serialized");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function for Deserializing the Patient class object
        public static void DeserializePatient()
        {
            try
            {
                List<Patient> patientList = PatientBL.DeserializePatient();


                //check whether the patient list is not empty 
                if (patientList.Count > 0)
                {
                    //Print the patient list
                    Console.WriteLine("*******************************************************************");
                    Console.WriteLine("Patient ID \t Patient Name \t Phone No. \t Age ");
                    Console.WriteLine("*******************************************************************");
                    foreach (var item in patientList)
                    {
                        Console.WriteLine(Patient.PatientID + "\t\t " + item.PatientName + "\t\t " + item.PhoneNumber + "\t" + item.Age);
                    }
                }
                else
                    throw new PatientException("There is no data for Deserialization");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function for printing Menu
        public static void PrintMenu()
        {
            Console.WriteLine("\n*******************************");
            Console.WriteLine("a. Add Patient");
            Console.WriteLine("b. Search Patient");
            Console.WriteLine("c. Serialize Patient List");
            Console.WriteLine("d. Deserialize Patient List");
            Console.WriteLine("e. Exit");
            // Console.WriteLine("f. View All Patient List");
            Console.WriteLine("********************************");
        }
        static void Main(string[] args)
        {
            char choice;

            try
            {
                do
                {
                    PrintMenu();
                    Console.Write("\nEnter your choice: ");
                    choice = Convert.ToChar(Console.ReadLine());

                    switch (choice)
                    {
                        case 'a': AddPatientDetails();
                            break;
                        case 'b': SearchPatient();
                            break;
                        case 'c': SerializePatient();
                            break;
                        case 'd': DeserializePatient();
                            break;
                        case 'e': Environment.Exit(0);
                            break;
                        // case 'f': DisplayAllPatients();
                        //     break;
                        default: Console.WriteLine("Please provide a valid choice");
                            break;
                    }
                } while (choice != 'e');

            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
