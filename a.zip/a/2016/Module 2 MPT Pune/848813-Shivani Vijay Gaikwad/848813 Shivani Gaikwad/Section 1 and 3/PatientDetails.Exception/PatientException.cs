﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDetails.Exception
{
    /// <summary>
    /// Employee ID : 848813
    /// Employee Name : Shivani Gaikwad
    /// Description : This is the Exception Class for Patient Details
    /// Date of Creation : 19/9/2016
    /// </summary>
    public class PatientException : ApplicationException
    {
        //Default Constructor for PatientException class
        public PatientException()
            : base()
        { }

        //Parameterized Constructor for PatientException class
        public PatientException(string msg)
            : base(msg)
        { }
    }
}
