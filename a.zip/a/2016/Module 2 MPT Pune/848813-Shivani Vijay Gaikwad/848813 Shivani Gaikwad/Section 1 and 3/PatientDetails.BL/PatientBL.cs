﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using PatientDetails.Entity;        //Reference to the Patient Entity
using PatientDetails.Exception;     //Reference to the Patient Exception
using PatientDetails.DAL;           //Reference to the Patient DAL

namespace PatientDetails.BL
{
    /// <summary>
    /// Employee ID : 848813
    /// Employee Name : Shivani Gaikwad
    /// Description : This is the BL Class for Patient Details
    /// Date of Creation : 19/9/2016
    /// </summary>
    public class PatientBL
    {
        //Function to Validate the Patient Data
        public static bool ValidatePatient(Patient patient)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();

            try
            {

                //Validating Patient Name
                if (!Regex.IsMatch(patient.PatientName, "[A-Z][a-z ]+"))
                {
                    msg.Append("Patient Name should have Alphabets and spaces only and it should start with Capital Letter\n");
                    validPatient = false;
                }

                //Validating Phone No
                if (!Regex.IsMatch(patient.PhoneNumber, "[789][0-9]{9}"))
                {
                    msg.Append("Phone no. should have 10 digits and it should start with 0\n");
                    validPatient = false;
                }

                //Validating Patient's Age
                if (patient.Age < 0 || patient.Age > 100)
                {
                    msg.Append("Age of Patient should be positive and less than 100 years\n");
                    validPatient = false;
                }

                if (validPatient == false)
                {
                    throw new PatientException(msg.ToString());
                }

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }

        //Function to add new Patient to the list after validating the information submitted
        public static bool AddPatientDetails(Patient newPatient)
        {
            bool patientAdded = false;

            try
            {
                if (ValidatePatient(newPatient))
                {
                    patientAdded = PatientDAL.AddPatientDetails(newPatient);
                    Patient.PatientID++;     //Increment the patient ID when a new Patient is Added to the list
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient\n");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Function to search a Patient from the list
        public static Patient SearchPatient(int patientID)
        {
            Patient patientSearched = null;

            try
            {
                patientSearched = PatientDAL.SearchPatient(patientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //Function for displaying all Patients in the list 
        public static List<Patient> DisplayAllPatients()
        {
            List<Patient> patientList = PatientDAL.DisplayAllPatients();

            return patientList;
        }

        public static bool SerializePatient()
        {
            bool patientSerialize = false;

            try
            {
                patientSerialize = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialize;
        }

        public static List<Patient> DeserializePatient()
        {
            List<Patient> patientList = null;
            try
            {
                patientList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientList;
        }
    }
}
