﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Section2.ReflectionMetadata
{
    /// <summary>
    /// Employee ID : 848813
    /// Employee Name : Shivani Gaikwad
    /// Description : This class accepts the input from user and then returns the result as square
    ///               of the number and prints the metadata about the DoWork() method
    /// Date of Creation : 19/9/2016
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Assembly myAssembly = Assembly.LoadFrom("Section2.dll");
                Type sqType = myAssembly.GetType("Section2.Test");

                //Create instance of the class for calling the method
                object obj = myAssembly.CreateInstance("Section2.Test");

                MethodInfo doWorkMethod = sqType.GetMethod("DoWork");

                //Get the number from the user
                Console.Write("\nEnter the number which you want to square : ");
                int num = Convert.ToInt32(Console.ReadLine());

                //Invoke the method DoWork() by passing the num
                int result = (int)doWorkMethod.Invoke(obj, new object[] { num });
                Console.WriteLine("Square is: " + result);

                //Get the method DoWork()
                MethodInfo method = sqType.GetMethod("DoWork");

                Console.WriteLine("\n\n***************Metadata about the DoWork() Method******************");

                //Print the metadata of the method by using Reflection Properties for the method
                Console.WriteLine("Method Name : " + method.Name);
                Console.WriteLine("Return Type : " + method.ReturnType);
                Console.WriteLine("Is Static Method : " + method.IsStatic);
                Console.WriteLine("Parameter Names : " + method.GetParameters());
                Console.WriteLine("Parameter Type : " + method.ReturnParameter);
            }
            catch (ReflectionTypeLoadException ex)  //Catch & Handle ReflectionType Exception if any
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)              //Catch & Handle System Generated Exceptions if any
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
