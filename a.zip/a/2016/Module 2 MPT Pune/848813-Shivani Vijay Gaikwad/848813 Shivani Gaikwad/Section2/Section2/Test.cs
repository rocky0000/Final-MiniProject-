﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Section2
{
    /// <summary>
    /// Employee ID : 848813
    /// Employee Name : Shivani Gaikwad
    /// Description : This is the Test Class with a function DoWork()
    /// Date of Creation: 19/9/2016
    /// </summary>
    
    public class Test
    {
        //Function DoWork() which accepts one integer parameter and returns the square of the integer
        public int DoWork(int parameter)
        {
            return parameter * parameter;
        }
    }
}
