﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using TestClassLibrary;
namespace Ques2DoWork
{
    
    /// <summary>
    /// Employee ID :94101
    /// Employee Name : Pritesh Ghogale
    /// Description : This is Main Class to calculate square of number and print metadata about DoWork Method
    /// Date of Creation : 19/09/2016
    /// </summary>
    
    class MainClass
    {
        //Main Method
        static void Main(string[] args)
        {
            try
            {   
                //Get a number from user.
                Console.WriteLine("Enter integer number to get its square :");
                int num = Convert.ToInt32(Console.ReadLine());
                
                //Create object of Test Class.          
                Test testObj = new Test();
                
                //Call Method DoWork from Test class
                int square   = testObj.DoWork(num);
                Console.WriteLine("Square of {0} is {1}.", num, square);
                
                //Load Assembly of TestClassLibrary
                Assembly myAsem = Assembly.LoadFrom("TestClassLibrary.dll");
                
                //Get Test class of TestClassLibrary
                Type testType   = myAsem.GetType("TestClassLibrary.Test");
                
                // Create Instance of MethodInfo to get DoWork Method from test class 
                MethodInfo testMethod = testType.GetMethod("DoWork");
                
                // Create Instance of ParameterInfo to get parameters of DoWork Method  
                ParameterInfo[] parameters = testMethod.GetParameters();
                
                //Print required metadata of DoWork method and its parameter
                Console.WriteLine("*******Metadata About Methods**********");
                Console.WriteLine("Method Name : " + testMethod.Name);
                Console.WriteLine("ReturnType  : " + testMethod.ReturnType);
                Console.Write("Is Method Static or Instance ? : ");
                if (testMethod.IsStatic == true)
                {
                    Console.WriteLine("Static");
                }
                else
                {
                    Console.WriteLine("Is not Static.It is Instance.");
                }
                //print required metadata of parameters
                foreach (ParameterInfo par in parameters)
                {
                    Console.WriteLine("Parameter name : " + par.Name);
                    Console.WriteLine("Parameter type : " + par.ParameterType);
                }
            }
            catch (SystemException)
            {
                Console.WriteLine("Please enter proper integer number.");
            }

            Console.ReadKey();

        }
    }
}
