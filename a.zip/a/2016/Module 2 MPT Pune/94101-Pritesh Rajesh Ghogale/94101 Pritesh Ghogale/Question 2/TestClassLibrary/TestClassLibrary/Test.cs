﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestClassLibrary
{

        /// <summary>
        /// Employee ID :94101
        /// Employee Name : Pritesh Ghogale
        /// Description : This is Test class containing DoWork Method
        /// Date of Creation : 19/09/2016
        /// </summary>

        public class Test
        {
            //DoWork Method
            public int DoWork(int num)
            {
                //Calculate and return square of a number
                int square = num * num;
                return square;
            }

        }

}
