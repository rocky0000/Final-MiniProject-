﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CPMS.Entity;        //Reference to Entity
using CPMS.Exception;    //Reference to Exception
using CPMS.BL;          //Reference to Business Layer
namespace CPMS.PL
{
    /// <summary>
    /// Employee ID :94101
    /// Employee Name : Pritesh Ghogale
    /// Description : This is Presentation Layer of Clinic Patient Management System
    /// Date of Creation : 19/09/2016
    /// </summary>
    class PatientPL
    {
        //Static variable to auto generate PatientID
        static int count = 1;
        
        //Method To Add Patient
        public static void AddPatient()
        {
            //Created new object of Employee class
            Patient newPatient = new Patient();
            try
            {
                //Set Patient ID
                newPatient.PatientID = count;
                //Increment count 
                count++;
                //Get Patient Details to be added
                Console.WriteLine("Enter Patient Name : ");
                newPatient.PatientName = Console.ReadLine();
                Console.WriteLine("Enter Phone No. : ");
                newPatient.PhoneNo = Console.ReadLine();
                Console.WriteLine("Enter Age : ");
                newPatient.Age = Convert.ToInt32(Console.ReadLine());
                //Add Patient Details
                bool patientAdded = PatientBL.AddPatient(newPatient);
                if (patientAdded)
                {
                    Console.WriteLine("Patient Added Successfully.");
                }
                else
                {
                    //Throw exception if employee not added
                    throw new PatientException("Patient Not Added.");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Method To Search Patient
        public static void SearchPatient()
        {
            try
            {
                //Accepting Patient Name To Search Patient
                Console.WriteLine("Enter Name of Patient to be searched: ");
                string  patientName = Console.ReadLine();
                //Search Patient 
                Patient patientSearched = PatientBL.SearchPatient(patientName);
                //If patient found then print searched patient details
                if (patientSearched != null)
                {
                    Console.WriteLine("Patient ID : " + patientSearched.PatientID);
                    Console.WriteLine("Patient Name : " + patientSearched.PatientName);
                    Console.WriteLine("Phone No. : " + patientSearched.PhoneNo);
                    Console.WriteLine("Age : " + patientSearched.Age);

                }
                else
                {
                    //Throw exception if patient not found
                    throw new PatientException("Patient Not Found With Name : " + patientName);
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        
        // Method to Serialize Patient Data
        public static void SerializePatient()
        {
            try
            {
                //Serialize Patient Data
                bool patientSerialized = PatientBL.SerializePatient();
                if (patientSerialized)
                    Console.WriteLine("Patient Data is Serialized");
                else
                {
                    //Throw Exception if Patient data is not serialized
                    throw new PatientException(" Patient Data is not Serialized");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        // Method to Deserialize Patient Data
        public static void DeSerializePatient()
        {
            try
            {
                //Deserialize Patient Data to  new Patient List
                List<Patient> patientList = PatientBL.DeSerializePatient();
                if (patientList != null)
                {
                    //Display Patient Data if deserialized
                    Console.WriteLine("********************************************************");
                    Console.WriteLine("Patient ID \t Patient Name \t Phone No \t Age");
                    Console.WriteLine("********************************************************");
                    foreach (Patient pat in patientList)
                    {
                        Console.WriteLine(pat.PatientID + "\t \t " + pat.PatientName + "\t \t " + pat.PhoneNo + "\t " + pat.Age);
                    }
                }
                else
                {
                    //Throw Exception if Patient data is not Deserialized
                    throw new PatientException("Patient Data is not Deserialized");
                }            
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Method To Print Menu
        public static void PrintMenu()
        {
            Console.WriteLine("**************************************");
            Console.WriteLine("a.Add Patient");
            Console.WriteLine("b.Search Patient");
            Console.WriteLine("c.Serialize Patient Data");
            Console.WriteLine("d.DeSerialize Patient Data");
            Console.WriteLine("e.Exit");
            Console.WriteLine("**************************************");
        }
        
        //Main Method
        static void Main(string[] args)
        {
            //choice variable to get user choice
            string choice = null;
            try
            { 
                do
                {
                    PrintMenu();
                    Console.Write("\nEnter Your Choice : ");
                    choice = Console.ReadLine();
                    switch (choice)
                    {
                        case "a":   //Add Patient
                                    AddPatient();
                                    break;
                        case "b":   // Search Patient
                                    SearchPatient();
                                    break;
                        case "c":   // SerializePatient Data
                                    SerializePatient();
                                    break;
                        case "d":   //DeSerialize Patient Data
                                    DeSerializePatient();
                                    break;
                        case "e":   //Exit Application
                                    Environment.Exit(0);
                                    break;
                        default:    //Display message if user entered incorrect choice
                                    Console.WriteLine("Please Enter Proper Choice");
                                    break;
                    }
                } while (choice!="e");  //continue loop until choice is not set to "e" i.e Exit
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        
        }
    }
}
