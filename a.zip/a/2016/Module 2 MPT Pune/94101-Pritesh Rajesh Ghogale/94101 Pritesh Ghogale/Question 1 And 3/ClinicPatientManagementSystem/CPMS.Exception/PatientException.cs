﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPMS.Exception
{
   /// <summary>
    /// Employee ID :94101
    /// Employee Name : Pritesh Ghogale
    /// Description : This is Exception Class for Patient for generating execption messages
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientException : ApplicationException
    {
         // Default Constructor Employee Exeception for generating execption messages
        public PatientException()
            : base()
        { }
        // Parameterised Constructor Employee Exeception for generating execption messages
        public PatientException(string msg)
            : base(msg)
        { }
    }
}
