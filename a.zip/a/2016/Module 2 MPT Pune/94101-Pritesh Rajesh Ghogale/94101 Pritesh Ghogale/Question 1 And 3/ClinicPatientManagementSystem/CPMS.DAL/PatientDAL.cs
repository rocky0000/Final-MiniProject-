﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary; //Reference for Binary Formatters to perform Serialization and Deserialization of Patient Data
using System.IO;          //Reference for IO to use FileStream for Serialization and Deserialization of Patient Data
using CPMS.Entity;       //Reference to Patient Entity
using CPMS.Exception;   //Reference to Patient Exception
namespace CPMS.DAL
{
    /// <summary>
    /// Employee ID :94101
    /// Employee Name : Pritesh Ghogale
    /// Description : This is Data Access Layer Class PatientDAL for Patient
    /// Date of Creation : 16/09/2016
    /// </summary>
    public class PatientDAL
    {
        //Create List of Patient
        static List<Patient> patientList = new List<Patient>();
        //Method to add new Patient
        public static bool AddPatient(Patient newPatient)
        {
            //Boolean variable to check if patient is added or not
            bool patientAdded = false;
            try
            {
                //adding Patient
                patientList.Add(newPatient);
                //Set patient added to true if patient details are added
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Method to Search Patient
        public static Patient SearchPatient(string patientName)
        {
            //Object of Patient class to store details of searched patient
            Patient patientSearched = null;
            try
            {
                //Searching Patient (using Named Arguments)
                patientSearched = patientList.Find(pat => pat.PatientName == patientName);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //Method to Serialize Patient Data
        public static bool SerializePatient()
        {
            //Boolean variable to check serialization is done or not
            bool patientSerialized = false;
            try
            {
                //Serialize patient data only if patient data is available in patient list
                if (patientList.Count > 0)
                {
                    //Create FileStream object to create serialized file patient.txt and write into it
                    FileStream fstream = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    //Create BinaryFormatter object to serialize patient data
                    BinaryFormatter binformat = new BinaryFormatter();
                    //Serialize patient data to file patient.txt
                    binformat.Serialize(fstream, patientList);
                    //Close FileStream object fstream
                    fstream.Close();
                    //Set patientSerialized to true if patient data is serialized
                    patientSerialized = true;
                }
                else
                {
                    throw new PatientException("No Patient Data Available.Hence Cannot Be Seralized.");
                }

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }

        //Method to Deserialize Patient Data from Patient.txt
        public static List<Patient> DeSerializePatient()
        {
            //Create list of patient for storing deserialized patient data
            List<Patient> desPatient = new List<Patient>();
            try
            {
                //Deserialize patient data only if patient data is available in patient list
                if (patientList.Count > 0)
                {
                    
                    //Create FileStream object to open serialized file patient.txt and read from it
                    FileStream fstream = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                    //Create BinaryFormatter object to deserialize patient data
                    BinaryFormatter binformat = new BinaryFormatter();
                    //Deserialize patient data from patient.txt
                    desPatient = (List<Patient>)binformat.Deserialize(fstream);
                    //Flush FileStream object fstream
                    fstream.Flush();
                    //Close FileStream object fstream
                    fstream.Close();

                }
                else
                {
                    throw new PatientException("No Patient Data Available.Hence Cannot Be Seralized.");
                }

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return desPatient;
        }
    }
}
