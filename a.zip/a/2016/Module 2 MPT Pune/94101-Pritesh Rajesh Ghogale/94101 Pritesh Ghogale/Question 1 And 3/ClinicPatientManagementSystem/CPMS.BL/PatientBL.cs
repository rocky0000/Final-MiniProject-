﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using CPMS.Entity;     //Reference to Patient Entity
using CPMS.Exception; //Reference to Patient Exception
using CPMS.DAL;      //Reference to Data Access LAyer
namespace CPMS.BL
{
    /// <summary>
    /// Employee ID :94101
    /// Employee Name : Pritesh Ghogale
    /// Description : This is Business Layer
    /// Date of Creation : 19/09/2016
    /// </summary>
    
    public class PatientBL
    {
        //Method to validate the patient data
        public static bool ValidatePatient(Patient patient)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();
            try
            {
                //Validation of Patient Name
                if (!Regex.IsMatch(patient.PatientName, "[A-Z][a-z]+"))
                {
                    msg.Append("Patient Name should have alphabets and spaces only and should start with capital letter\n");
                    validPatient = false;
                }
                //Validation of Phone No.
                if (!Regex.IsMatch(patient.PhoneNo, "[789][0-9]{9}"))
                {
                    msg.Append("Phone No should be of ten digits and should start with 7,8 or 9\n");
                    validPatient = false;
                }
                //Validation of Age
                if (patient.Age < 0 || patient.Age > 100)
                {
                    msg.Append("Patient Age should be within range 0 to 100\n");
                    validPatient = false;
                }
                //If validPatient is set to false throw exception message 
                if (validPatient == false)
                {
                    throw new PatientException(msg.ToString());
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }

        //Method to add Patient
        public static bool AddPatient(Patient newPatient)
        {
            //Boolean variable to check if patient is added or not
            bool patientAdded = false;
            try
            {
                //Add patient only if entered Patient details are valid
                if (ValidatePatient(newPatient))
                {
                    //Adding Patient Details
                    patientAdded = PatientDAL.AddPatient(newPatient);

                }
                else
                {
                    //Throw exception if Patient details are not valid
                    throw new PatientException("Please provide valid Patient Details.");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //Method to Search Patient
        public static Patient SearchPatient(string patientName)
        {
            //Object of Patient class to store details of searched patient
            Patient patientSearched = null;
            try
            {
                //Searching Patient (using Named Arguments)        
                patientSearched = PatientDAL.SearchPatient(patientName);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //Method to serialize Patient Details
        public static bool SerializePatient()
        {
            //Boolean variable to check patient data is serialized
            bool patientSerialized = false;
            try
            {
                //Serialize Patient Data            
                patientSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }

        //Method to deserialize Patient Details
        public static List<Patient> DeSerializePatient()
        {
            //Create list of Patient to store deserialized patient data
            List<Patient> patientList = null;
            try
            {
                //Deserialize Patient Data          
                patientList = PatientDAL.DeSerializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientList;
        }
    }
}
