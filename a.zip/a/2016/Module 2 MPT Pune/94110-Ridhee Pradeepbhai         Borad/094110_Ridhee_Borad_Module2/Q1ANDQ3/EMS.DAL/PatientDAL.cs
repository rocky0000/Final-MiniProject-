﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;//Refernce to Patient Entity
using EMS.Exception;//Refernce to Patient Exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace EMS.DAL
{

    /// <summary>
    /// Employee ID : 094110
    /// Employee Name : Ridhee Borad
    /// Description : This is Patient DAL class for Patient Exception
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientDAL
    {
        static List<Patient> patientList = new List<Patient>();
        static int patientID = 100;//odd patient id genterated automatically
            


        //Function to add Patient data
        public static bool AddPatient(Patient newPatient)
        {
            newPatient.PatientId = patientID;
            patientID++;
           
            bool patientAdded = false;

            try
            {
                //Adding Employee
                patientList.Add(newPatient);
                patientAdded = true;

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientAdded;

        }

        //Function to Search Patient from the list of Patient
        public static Patient SearchPatient(int patientID)
        {
            Patient patientSearched = null;
            try
            {
                //Searching Employee
                patientSearched = patientList.Find(emp => emp.PatientId == patientID);

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearched;
        }


        //function to Serialize Patient data
        public static bool SerializePatient()
        {
            bool empSerialized = false;

            try
            {
                if (patientList.Count > 0)
                {
                    FileStream fs = new FileStream("employee.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binFormat = new BinaryFormatter();
                    binFormat.Serialize(fs, patientList);
                    empSerialized = true;
                    fs.Flush();
                    fs.Close();
                    // fs.Flush();

                }
                else
                    throw new PatientException("No Patient data Found.So cannot serialize the data");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return empSerialized;

        }

        //function to Deserialize Patient data
        public static List<Patient> DeSerializePatient()
        {
            List<Patient> desEmp = null;

            try
            {

                FileStream fs = new FileStream("employee.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormat = new BinaryFormatter();
                desEmp = (List<Patient>)binFormat.Deserialize(fs);
                fs.Flush();
                fs.Close();


            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            //return empList;
            return desEmp;
        }


    }
}
