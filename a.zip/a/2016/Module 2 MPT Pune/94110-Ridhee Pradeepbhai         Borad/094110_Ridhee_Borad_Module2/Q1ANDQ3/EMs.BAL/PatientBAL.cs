﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using EMS.Entity;//Reference to Patient Entity
using EMS.DAL;//Reference to Patient DAL
using EMS.Exception;//Reference to Patient Exception

namespace EMs.BAL
{
    /// <summary>
    /// Employee ID : 094110
    /// Employee Name : Ridhee Borad
    /// Description : This is Patient BAL class for Patient Exception
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientBAL
    {
        //function to validate the Employee Data
        public static bool ValidatePatient(Patient patient)
        {
            bool validPatient = true;

            StringBuilder msg = new StringBuilder();

            try
            {
            


                //Validating employee name 
                if (!Regex.IsMatch(patient.PatientName, "[A-Z][a-z ]+"))
                {
                    msg.Append("\nEmployee name should have alphabets and spaces only and it should start with capital letter only");
                    validPatient = false;
                }

                //validating employee phone number
                if (!Regex.IsMatch(patient.PhoneNo, "[1-9][0-9]{9}"))
                {
                    msg.Append("\nPhone number should have 10 digits and it cannot start with 0 ");
                    validPatient = false;
                }

                //validating employee age
                if (patient.Age < 0 || patient.Age > 100)
                {
                    msg.Append("\nPatient Age should be between 0 to 100");
                    validPatient = false;
                }



                if (validPatient == false)
                {
                    throw new PatientException(msg.ToString());
                }

            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }

        //Function to add Patient data
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPatient))
                {
                    patientAdded = PatientDAL.AddPatient(newPatient);
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;


        }

        //Function to search Patient data
        public static Patient SearchPatient(int patientID)
        {
            Patient patientSearched = null;
            try
            {
                //search employee
                patientSearched = PatientDAL.SearchPatient(patientID);

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }




        //function to Serialize Patient data
        public static bool SerializePatient()
        {
            bool patientSerialize = false;
            try
            {
                
                patientSerialize = PatientDAL.SerializePatient();

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialize;

        }

        //function to Deserialize Patient data
        public static List<Patient> DeSerializePatient()
        {
            List<Patient> patientList = null;
            try
            {
               
                patientList = PatientDAL.DeSerializePatient();

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientList;

        }

    }
}
