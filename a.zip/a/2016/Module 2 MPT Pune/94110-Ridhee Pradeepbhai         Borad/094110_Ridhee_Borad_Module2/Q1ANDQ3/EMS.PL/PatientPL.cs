﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;//Reference to Employee Entity
using EMs.BAL;//Reference to Employee BAL
using EMS.Exception;//Reference to Employee Exception

namespace EMS.PL
{
    /// <summary>
    /// Employee ID : 094110
    /// Employee Name : Ridhee Borad
    /// Description : This is Patient PL class for Patient Exception
    /// Date of Creation : 19/09/2016
    /// </summary>
    class PatientPL
    {
        static int Id = 100;

        //Function to add Patient data
        public static void AddPatient()
        {
             
          
             Patient newPatient = new Patient();
            try
            {
                //int a = 0;
                 
                //Console.Write("Enter Employee ID : ");
                ////int.TryParse(Console.ReadLine(), out newEmp.EmployeeId);
                //newEmp.PatientId = Convert.ToInt32(Console.ReadLine());

                //Console.WriteLine("Enter number of records to be added");
                //a = Convert.ToInt32(Console.ReadLine());
                //for (int i = 0; i < a; i++)
                //{



                //Id++;
                //Console.WriteLine("Patient Id : " + Id);
               

                    Console.Write("Enter Patient Name : ");
                    newPatient.PatientName = Console.ReadLine();

                    Console.Write("Enter phone number : ");
                    newPatient.PhoneNo = Console.ReadLine();

                    Console.Write("Enter Age : ");
                    newPatient.Age = Convert.ToInt32(Console.ReadLine());
                //}


                    bool patientAdded = PatientBAL.AddPatient(newPatient);

                if (patientAdded)
                    Console.WriteLine("Patient details added successfully");
                else
                    throw new PatientException("Patient details not added");
                bool patientAdded1 = PatientBAL.AddPatient(newPatient);

                //if (patientAdded1)
                //{
                //    Id++;
                //    Console.WriteLine("Patient Id : " + Id);
                //}


            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //function to Search Patient data
        public static void SearchPatient()
        {
            try
            {
                int patientId;
                Console.Write("Enter Patient ID for patient whose information you would like to search : ");
                patientId = Convert.ToInt32(Console.ReadLine());



                Patient emp = PatientBAL.SearchPatient(patientId);

                if (emp != null)
                {
                    Console.WriteLine("Patient ID : " + emp.PatientId);
                    Console.WriteLine("Patient Name : " + emp.PatientName);
                    Console.WriteLine("Patient Phone no. : " + emp.PhoneNo);
                    Console.WriteLine("Patient Age : " + emp.Age);
                   
                }
                else
                    throw new PatientException("Patient  not found with Patient id : " + patientId);


            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("**************************");
            Console.WriteLine("1. Add Patient");
            Console.WriteLine("2. Search Patient ");
            Console.WriteLine("3. Serialize ");
            Console.WriteLine("4. Deserialize ");
            Console.WriteLine("5. Exit ");
            Console.WriteLine("**************************");
        }

        //function to Serialize Patient data
        public static void SerializePatient()
        {

            try
            {
               
                bool patientSerialize = PatientBAL.SerializePatient();
                if (patientSerialize)
                    Console.WriteLine("Patient data serialize");
                else
                    Console.WriteLine("Patient data not serialized");

            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        //function to Deserialize Patient data
        public static void DeSerializePatient()
        {

            try
            {
                List<Patient> patientList = PatientBAL.DeSerializePatient();

                if (patientList != null)
                {

                    Console.WriteLine("************************************************************************************");

                    Console.WriteLine("Patient ID \t Patient Name \t Phoneno. \t  Age ");

                    Console.WriteLine("************************************************************************************");
                    foreach (var emp in patientList)
                    {
                        Console.WriteLine(emp.PatientId + "\t\t" + emp.PatientName + "\t\t" + emp.PhoneNo +"\t\t"+ emp.Age);
                    }
                }
                else
                {
                    throw new PatientException("There is no data Found");
                }

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

        }



        static void Main(string[] args)
        {
            int choice = 0;
            int key = 0;

            try
            {

                do
                {
                    PrintMenu();
                    Console.WriteLine("\n Enter your Choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;

                        case 2: SearchPatient();
                            break;

                        case 3: SerializePatient();
                            break;
                        case 4: DeSerializePatient();
                            break;
                        case 5: Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Please enter valid choice ");
                            break;

                    }

                    Console.WriteLine("\nDo you want to continue \n1.Yes\n2.No");
                    key = Convert.ToInt32(Console.ReadLine());

                } while (key== 1);
                //while(choice!=5)
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}

