﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;


namespace Question2
{
    /// <summary>
    /// Employee ID : 094110
    /// Employee Name : Ridhee Borad
    /// Description : This is Reflection for Methods
    /// Date of Creation : 19/09/2016
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("Question2Libraray.dll");
            Type empType = myAssembly.GetType("Question2Libraray.Calculate");

            MethodInfo empMethods = empType.GetMethod("DoWork");

            //ParameterInfo parameter = empType.GetParameter("DoWork");
            //Console.WriteLine("")
           
                Console.WriteLine("Method Name :" + empMethods.Name);
                Console.WriteLine("Method return type :" + empMethods.ReturnType);
                Console.WriteLine("Method static :" + empMethods.IsStatic);

                Console.WriteLine("Method Return parameter :" + empMethods.ReturnParameter);

                Console.WriteLine("Method Return parameter name :" + empMethods.ReturnType.Name);
                Console.WriteLine("Method Return parameter :" + empMethods.GetParameters());

          






                object CalcObj1 = myAssembly.CreateInstance("Question2Libraray.Calculate");
                MethodInfo divMethod = empType.GetMethod("DoWork");
                int result1 = (int)divMethod.Invoke(CalcObj1, new object[] { 5 });
                Console.WriteLine("\n\nSquare : " + result1);

                Console.ReadKey();
            
        }
    }
}
