﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2Libraray
{
    public class Test
    {
        int square;
        int result;
        public int Square { get; set; }
        public int Result { get; set; }

        public Test()
        {
    
    
    
        }

        public Test(int square, int result)
        {
            Square = square;
            Result = result;
        }

    }
}
