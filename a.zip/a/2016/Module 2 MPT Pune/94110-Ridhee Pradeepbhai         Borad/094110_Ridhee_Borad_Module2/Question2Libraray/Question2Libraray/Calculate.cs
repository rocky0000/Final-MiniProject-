﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2Libraray
{
    /// <summary>
    /// Employee ID : 094110
    /// Employee Name : Ridhee Borad
    /// Description : This is Libary for Reflection 
    /// Date of Creation : 19/09/2016
    /// </summary>
    class Calculate
    {
        public static int DoWork(int val1)
        {

            return (val1 * val1);

        }
    }
}
