﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;        //Reference to Reflection
using TestLibrary;              //Reference to TestLibrary.dll

namespace ReflectionForMethod
{
    /// <summary>
    /// Employee ID: 94276
    /// Employee Name: Rithu Raveendran
    /// Description: Reflection for methods are called in this class.
    /// Date of Creation: 19/09/2016
    /// </summary>
    
    class RefelctionClass
    {
        static void Main(string[] args)
        {
            //Loading Assembly 
            Assembly myAssembly = Assembly.LoadFrom("TestLibrary.dll");
            Type testType = myAssembly.GetType("TestLibrary.Test");
            
            //Get DoWork() Method in testMethod
            MethodInfo testMethod = testType.GetMethod("DoWork");

            //Invoking DoWork() Method
            int res;
            Console.WriteLine("\nInvoking the DoWork() method...");
            object testobj = myAssembly.CreateInstance("TestLibrary.Test");
            
            Console.Write("Enter a number: ");
            int num1 = Convert.ToInt32(Console.ReadLine());

            //Creating an instance
            res = (int)testMethod.Invoke(testobj, new object[] { num1 });
            Console.WriteLine("Square of the number is:" + res);

            Console.WriteLine("\nMetadata about DoWork():");
            
            // Print the Method Name
            Console.WriteLine("Method Name : \t\t" + testMethod.Name);

            // Print the Return Type
            Console.WriteLine("Return Type: \t\t" + testMethod.ReturnType);

            // Print whether the method is Static or Instance
            Console.WriteLine("Is DoWork() Static: \t" + testMethod.IsStatic);

            // Print the Parameter Names
            Console.WriteLine("Parameter Names: \t" + testMethod.GetParameters().ElementAt(0).Name);

            // Print the Parameter Type
            Console.WriteLine("Parameter Type: \t" + testMethod.GetParameters().ElementAt(0).ParameterType);

            Console.ReadKey();
       }
    }
}
