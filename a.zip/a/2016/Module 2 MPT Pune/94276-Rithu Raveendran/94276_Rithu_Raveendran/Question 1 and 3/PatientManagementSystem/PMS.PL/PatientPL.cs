﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Entity;       //Reference to Patient Entity
using PMS.Exception;    //Reference to Patient Exception
using PMS.BL;           //Reference to Patient Business Access Layer

namespace PMS.PL
{
    /// <summary>
    /// Employee ID: 94276
    /// Employee Name: Rithu Raveendran
    /// Description: This is Presentation Access Layer of Patient Management System
    /// Date of Creation: 19/09/2016
    /// </summary>
    class PatientPL
    {
        //Declaring Static variable for auto generated patient ID
        static int patientID = 100;

        //Function to add Patient in the list
        public static void AddPatient()
        {
            Patient newPatient = new Patient();
            try
            {
                //Get Patient Details from the user to Add Patient in the list
                newPatient.PatientID = ++patientID; 
                Console.Write("Enter Patient Name: ");
                newPatient.PatientName = Console.ReadLine();
                Console.Write("Enter Phone Number: ");
                newPatient.PhoneNumber = Console.ReadLine();
                Console.Write("Enter Patient's Age: ");
                newPatient.Age = Convert.ToInt32(Console.ReadLine());

                //Call AddPatient() method of PatientBL 
                bool patientAdded = PatientBL.AddPatient(newPatient);

                if (patientAdded)
                {
                    Console.WriteLine("Patient Added Successfully to the list with PatientID: "+patientID+".");
                }
                else
                {
                    patientID--;
                    throw new PatientException("Patient not Added");
                }
            }
            catch (PatientException ex)
            {
                patientID--;
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to search Patient from the Patient list
        public static void SearchPatient()
        {
            try
            {
                //Get Patient ID from the user to search
                int patientID;
                Console.Write("Enter Patient ID for Patient which you would like to search: ");
                patientID = Convert.ToInt32(Console.ReadLine());

                //Call SearchPatient() method of PatientBL 
                Patient searchedPatient = PatientBL.SearchPatient(patientID);
                if (searchedPatient != null)
                {
                    //Print the Patient Details
                    Console.WriteLine("Patient ID: \t" + searchedPatient.PatientID);
                    Console.WriteLine("Patient Name: \t" + searchedPatient.PatientName);
                    Console.WriteLine("Phone Number: \t" + searchedPatient.PhoneNumber);
                    Console.WriteLine("Age: \t\t" + searchedPatient.Age);
                }
                else
                {
                    throw new PatientException("No such record with Patient ID: " + patientID + " in the list");
                }

            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to serialize Patient list
        public static void SerializedPatient()
        {
            try
            {
                //Call SerializePatient() method of PatientBL 
                bool patientSerialized = PatientBL.SerializePatient();
                if (patientSerialized)
                {
                    Console.WriteLine("Patient data serialized");
                }
                else
                {
                    throw new PatientException("Patient data not serialized");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to deserialize Patient list
        public static void DeserializePatient()
        {
            try
            {
                //Call DeserializePatient() method of PatientBL 
                List<Patient> patientlist = PatientBL.DeserializePatient();
                if (patientlist != null)
                {
                    Console.WriteLine("**************************************************************");
                    Console.WriteLine("Patient ID \t Patient Name \t Phone No \t Age");
                    Console.WriteLine("**************************************************************");
                    foreach (Patient patient in patientlist)
                    {
                        Console.WriteLine(patient.PatientID + "\t\t " + patient.PatientName + "\t\t" + patient.PhoneNumber + "\t " + patient.Age );
                    }
                }
                else
                {
                    throw new PatientException("No data in the file");
                }
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);

            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to Print the Menu
        public static void PrintMenu()
        {
            Console.WriteLine("\n**************************************************************");
            Console.WriteLine("1.Add Patient\n2.Search Patient\n3.Serialize\n4.Deserialize\n5.Exit");
            Console.WriteLine("**************************************************************");
        }
        
        static void Main(string[] args)
        {
            Console.WriteLine("Patient Management System");
            int choice = 0;
            try
            {
                do
                {
                    PrintMenu();
                    Console.WriteLine("\nEnter your Choice");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;
                        case 2: SearchPatient();
                            break;
                        case 3: SerializedPatient();
                            break;
                        case 4: DeserializePatient();
                            break;
                        case 5: Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Please provide valid choice.");
                            break;
                    }

                } while (choice != 5);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
