﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using PMS.Entity;       //Reference to Patient Entity
using PMS.Exception;    //Reference to Patient Exception
using PMS.DAL;          //Reference to Patient Data Access Layer

namespace PMS.BL
{
    /// <summary>
    /// Employee ID: 94276
    /// Employee Name: Rithu Raveendran
    /// Description: This is Business Access Layer of Patient Management System
    /// Date of Creation: 19/09/2016
    /// </summary>
    public class PatientBL
    {
        //Function to validate the patient details
        public static bool ValidatePatient(Patient patient)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();

            try
            {
                //Validating Patient Name
                if (!Regex.IsMatch(patient.PatientName, "[A-Z a-z]+"))
                {
                    msg.Append("Patient Name should contain alphabets and spaces only\n");
                    validPatient = false;
                }
                //Validating Phone Number
                if (!Regex.IsMatch(patient.PhoneNumber, "[123456789]{1}[0-9]{9}") || patient.PhoneNumber.Length>10)
                {
                    msg.Append("Phone number should have 10 digits and it should start with 1-9\n");
                    validPatient = false;
                }
                //Validating Patient's Age
                if (patient.Age < 0 || patient.Age > 100)
                {
                    msg.Append("Age should be within 0 to 100\n");
                    validPatient = false;
                }
                
                //Check whether the patient details is invalid
                if (validPatient == false)
                {
                    throw new PatientException(msg.ToString());
                }

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }

        //Function to Add Patients in the list
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAddded = false;
            try
            {
                //Validating Patient's details
                if (ValidatePatient(newPatient))
                {
                    //Call AddPatient() method of PatientDAL 
                    patientAddded = PatientDAL.AddPatient(newPatient);
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAddded;
        }

        //Function to search Patient from list of patients
        public static Patient SearchPatient(int patientId)
        {
            Patient patientSearched = null;
            try
            {
                //Call SearchPatient() method of PatientDAL 
                patientSearched = PatientDAL.SearchPatient(patientId);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //Function to serialize Patient list
        public static bool SerializePatient()
        {
            bool patientSerialized = false;
            try
            {
                //Call SerializePatient() method of PatientDAL 
                patientSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }

        //Function to deserialize Patient list
        public static List<Patient> DeserializePatient()
        {
            List<Patient> patientlist = new List<Patient>();
            try
            {
                //Call DeserializePatient() method of PatientDAL 
                patientlist = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientlist;
        }

    }
}
