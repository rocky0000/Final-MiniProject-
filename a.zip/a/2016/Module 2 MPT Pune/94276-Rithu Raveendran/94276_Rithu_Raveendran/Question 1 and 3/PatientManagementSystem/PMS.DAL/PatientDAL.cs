﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using PMS.Entity;       //Reference to Patient Entity
using PMS.Exception;    //Reference to Patient Exception

namespace PMS.DAL
{
    /// <summary>
    /// Employee ID: 94276
    /// Employee Name: Rithu Raveendran
    /// Description: This is Data Access Layer of Patient Management System
    /// Date of Creation: 19/09/2016
    /// </summary>
    public class PatientDAL
    {
        static List<Patient> patientlist = new List<Patient>();

        //Function to add new Patient to the list of Patient
        public static bool AddPatient(Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                //Adding Patient
                patientlist.Add(newPatient);
                patientAdded = true;
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientAdded;
        }

        //Function for searching a patient from the patient list
        public static Patient SearchPatient(int patientID)
        {
            Patient patientSearched = null;
            try
            {
                //Search Patient
                patientSearched = patientlist.Find(patient => patient.PatientID == patientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;
        }

        //Function to serialize Patient list to Patient.txt
        public static bool SerializePatient()
        {
            bool patientSerialized = false;
            try
            {
                if (patientlist.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(fs, patientlist);
                    patientSerialized = true;
                    fs.Flush();
                    fs.Close();
                }
                else
                {
                    throw new PatientException("No Patient Data so cannot serialize");
                }
            }
            catch (PatientException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;
        }

        //Function to deserialize Patient.txt to Patient list
        public static List<Patient> DeserializePatient()
        {
            List<Patient> desPatient = null;
            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                desPatient = (List<Patient>)bf.Deserialize(fs);
                fs.Flush();
                fs.Close();
            }
            catch (PatientException ex)
            {

                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return desPatient;
        }

    }
}
