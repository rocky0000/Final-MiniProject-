﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Entity
{
    /// <summary>
    /// Employee ID: 94276
    /// Employee Name: Rithu Raveendran
    /// Description: This is Entity class for Patient Management System
    /// Date of Creation: 19/09/2016
    /// </summary>
    [Serializable]
    public class Patient
    {
        // Property for Get or Set PatientID
        public int PatientID { get; set; }

        // Property for Get or Set PatientName
        public string PatientName { get; set; }

        // Property for Get or Set Age
        public int Age { get; set; }

        // Property for Get or Set Phone number
        public string PhoneNumber { get; set; }

    }
}
