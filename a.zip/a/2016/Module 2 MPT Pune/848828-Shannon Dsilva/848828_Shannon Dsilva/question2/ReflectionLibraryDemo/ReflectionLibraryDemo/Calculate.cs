﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ReflectionLibraryDemo
{
    /// <summary>
    /// Employee ID:848828
    /// Employee Name: shannon dsilva
    /// Date Of Creation: 19/09/2016
    /// </summary>
    public class Calculate
    {
        public int  DoWork(int num1)
        {
            return num1 * num1;
            //Console.WriteLine("{0}*{1} => {2}"+num1 * num1);
        }

       
    }
}
