﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionLibraryDemo;

namespace ReflectionDemoforMethods
{
    class Program
    {
        /// <summary>
        /// Employee ID:848828
        /// Employee Name: Shannon dsilva
        /// Date Of Creation: 19/09/2016
        /// </summary>
     
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("ReflectionLibraryDemo.dll");

            Type empType = myAssembly.GetType("ReflectionLibraryDemo.Calculate");

            MethodInfo empMethods = empType.GetMethod("DoWork");

            //method name
            Console.WriteLine("Method Name : " + empMethods.Name);
            //return type
            Console.WriteLine("Return Type : " + empMethods.ReturnType);
            //abstract or not
            Console.WriteLine("Is Abstract : " + empMethods.IsAbstract);
            //is it static
            Console.WriteLine("Is Static : " + empMethods.IsStatic);
            //getting parameters name
            Console.WriteLine("Get Parameters : " + empMethods.GetParameters().ElementAt(0).Name);
            //getting parameter types 
            Console.WriteLine("Parameter Type : " + empMethods.ContainsGenericParameters);
            Console.WriteLine();

            //creating object of ReflectionLibraryDemo.Calculate
            object cal = myAssembly.CreateInstance("ReflectionLibraryDemo.Calculate");

            MethodInfo square = empType.GetMethod("DoWork");
            int result = (int)square.Invoke(cal, new object[]{5});

            Console.WriteLine("square of the number is: "+result);
            Console.ReadKey();
        }
    }
}

           

           
            


