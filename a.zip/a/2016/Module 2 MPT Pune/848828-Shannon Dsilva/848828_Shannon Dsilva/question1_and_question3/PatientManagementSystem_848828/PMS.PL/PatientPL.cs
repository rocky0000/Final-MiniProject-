﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.DAL;
using PMS.Entity;// reference for patient entity
using PMS.Exception;// reference for patient exception
using PMSnew.BAL;// reference for patient BAL


namespace PMS.PL
{
    /// <summary>
    /// Employee ID : 848828
    /// Employee Name : Shannon Dsilva
    /// Description : This is Entity class for Employee
    /// Date of Creation : 19/09/2016
    /// </summary>
    class PatientPL
    {
        //auto generation of patient ID from 100
        static int patID = 100;
        public static void AddPatient()
        {
            Patient newPat = new Patient();

            try
            {
                newPat.PatientID = patID++;
                //Console.Write("Enter Patient ID : ");
                //newPat.PatientID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Patient Name : ");
                newPat.PatientName = Console.ReadLine();
                Console.Write("Enter Phone No : ");
                newPat.PhoneNo = Console.ReadLine();
                Console.Write("Enter Age : ");
                newPat.Age = Convert.ToInt32(Console.ReadLine());


                bool patientAdded = PatientsBAL.AddPatient(newPat);

                if (patientAdded)
                    Console.WriteLine("\npatient Added Successfully !!!");
                else
                    throw new PatientException("Employee not Added");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //searching patient info
        public static void SearchPatient()
        {
            try
            {
                int patID;
                Console.Write("Enter Patient ID for Patient Which You Would Like to Search : ");
                patID = Convert.ToInt32(Console.ReadLine());

                Patient pat = PatientsBAL.SearchPatient(patID);

                if (pat != null)
                {
                    Console.WriteLine("Patient ID : " + pat.PatientID);
                    Console.WriteLine("Employee Name : " + pat.PatientName);
                    Console.WriteLine("Phone Number : " + pat.PhoneNo);
                    Console.WriteLine("Age : " + pat.Age);
                   
                }
                else
                    throw new PatientException("Patient not found with Employee ID : " + patID);
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //serializing process
        public static void SerializePatient()
        {
            try
            {
                bool patSerialized = PatientsBAL.SerializePatient();
                if (patSerialized)
                    Console.WriteLine("Patient data is serialized");
                else
                    throw new PatientException("Patient Data is not Serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Deserializing process
        public static void DeserializePatient()
        {
            try
            {
                List<Patient> patList = PatientsBAL.DeserializePatient();

                if (patList != null)
                {
                   
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("Patient ID \t Patient Name \t\t Phone No \t\t Age");
                    Console.WriteLine("************************************************************************************");
                    foreach (Patient pat in patList)
                    {
                        Console.WriteLine(pat.PatientID + "\t\t" + pat.PatientName + "\t\t" + pat.PhoneNo + "\t\t" + pat.Age);
                    }
                }
                else
                    throw new PatientException("There is not data");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //menu print
        public static void PrintMenu()
        {
            Console.WriteLine("\nBY DEFAULT PATIENT ID IS GENERATED STARTING FROM 100 ");
            Console.WriteLine("AND INCREMENTED BY 1 FOR EVERY NEW PATIENT ADDED !!!");

            Console.WriteLine("\n************************");
            Console.WriteLine("1. Add Patient");
            Console.WriteLine("2. Search Patient");
            Console.WriteLine("3. Serialize Patient");
            Console.WriteLine("4. Deserialize Patient");
            Console.WriteLine("5. Exit");
            Console.WriteLine("************************");
        }





        static void Main(string[] args)
        {
            int choice = 0;

            try
            {
                do
                {
                    PrintMenu();

                    Console.Write("\nEnter Your Choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;

                        case 2: SearchPatient();
                            break;

                        case 3: SerializePatient();
                            break;

                        case 4: DeserializePatient();
                            break;

                        case 5: Environment.Exit(0);
                            break;


                        default: Console.WriteLine("Please provide valid choice");
                            break;
                    }
                } while (choice != 5);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();

        }
    }
}
