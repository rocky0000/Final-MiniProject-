﻿







//**************************************************************//
//*******WRONG CODE FOR BUSINESS ACCESS LAYER******************//
//*************REFER " PMSnew.BAL" ***************************//





using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using PMS.DAL;//reference to DAL class
using PMS.Entity;//reference to Entity  class
using PMS.Exception;//reference to Exception class

namespace PMS.BAL
{
    /// <summary>
    /// Employee ID : 848828
    /// Employee Name : Shannon Dsilva
    /// Description : This is Entity class for Employee
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientBAL
    {
        //Function to validate the employee data
        public static bool ValidatePatient(Patient pat)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();

            try 
            {
                if (pat.Pa < 100 || emp.EmployeeID > 999)
                {
                    msg.Append("Employee ID should be 3 digits\n");
                    validEmployee = false;
                }

                if (!Regex.IsMatch(emp.EmployeeName, "[A-Z][a-z ]+"))
                {
                    msg.Append("Employee Name should have alphabets and spaces only and it should start with capital letter\n");
                    validEmployee = false;
                }

                if (!Regex.IsMatch(emp.PhoneNo, "[123456789][0-9]{9}"))
                {
                    msg.Append("Phone No should have 10 digits and it should start with 7 or 8 or 9\n");
                    validEmployee = false;
                }

                if (emp.Age < 18 || emp.Age > 60)
                {
                    msg.Append("Employee Age should be within 18 to 60\n");
                    validEmployee = false;
                }
                if (validEmployee == false)
                    throw new EmployeeException(msg.ToString());
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validEmployee;
        }
    }
}
