﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Entity
{
    /// <summary>
    /// Employee ID : 848828
    /// Employee Name : Shannon Dsilva
    /// Description : This is Entity class for Employee
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class Patient
    {
        public int PatientID { get; set; }

        public string PatientName { get; set; }
        
        public int Age { get; set; }

        public string PhoneNo { get; set; }

        public string City { get; set; }
     
    }
}
