﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.DAL;//REFERENCE TO DAL CLASS
using PMS.Entity;//REFERENCE TO ENTITY CLASS
using PMS.Exception;//REFERENCE TO EXCEPTION CLASS
using System.Text.RegularExpressions;

namespace PMSnew.BAL
{
    /// <summary>
    /// Employee ID : 848828
    /// Employee Name : Shannon Dsilva
    /// Description : This is new BAL class for Employee
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientsBAL
    {
        //Function to validate the patient data
        public static bool ValidatePatient(Patient pat)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();

            try
            {
                //if (pat.PatientID < 100 || pat.PatientID > 999)
                //{
                //    msg.Append("Patient ID should be 3 digits\n");
                //    validPatient = false;
                //}

                //VALIDATING NAME

                if (!Regex.IsMatch(pat.PatientName, "[A-Z][a-z ]+"))
                {
                    msg.Append("Patient Name should have alphabets and spaces only and it should start with capital letter\n");
                    validPatient = false;
                }
                //VALIDATING PHONE NUMBER
                if (!Regex.IsMatch(pat.PhoneNo, "[123456789][0-9]{9}"))
                {
                    msg.Append("Phone No should have 10 digits and it should start with 7 or 8 or 9\n");
                    validPatient = false;
                }
                //VALIDATING PATIANT AGE
                if (pat.Age < 0 || pat.Age > 100)
                {
                    msg.Append("Patient Age should be greater than 0 and less than 100\n");
                    validPatient = false;
                }
                if (validPatient == false)
                    throw new PatientException(msg.ToString());
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validPatient;
        }

        //ADDING PATIETNT CLASS
        public static bool AddPatient(Patient newPat)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPat))
                {
                    patientAdded = PatientDAL.AddPatient(newPat);
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        //SEARCH PATIENT CLASS
        public static Patient SearchPatient(int patID)
        {
            Patient patientSearched = null;

            try
            {
                patientSearched = PatientDAL.SearchPatient(patID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patientSearched;
        }

        //Serialize CLASS
        public static bool SerializePatient()
        {
            bool patSerialized = false;

            try
            {
                patSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            return patSerialized;
        }

        //DESerialize CLASS
        public static List<Patient> DeserializePatient()
        {
            List<Patient> patList = null;

            try
            {
                patList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patList;
        }


    }
}
