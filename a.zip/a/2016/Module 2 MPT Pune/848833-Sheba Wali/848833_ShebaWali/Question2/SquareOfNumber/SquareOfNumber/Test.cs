﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SquareOfNumber
{
    public class Test
    {
        public int Square(int num1)
        {
            return num1 * num1;
        }

    
    }
}

