﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace CalSquareTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("SquareOfNumber.dll");
                       Type numType = myAssembly.GetType("SquareOfNumber.Test");
                       MethodInfo[] numMethods = numType.GetMethods();
                       foreach (MethodInfo m in numMethods)
            {
                Console.WriteLine("\n*********************Method Info****************");
                //To print method name
                Console.WriteLine("\nMethod Name is : " + m.Name);
                //Print return type
                Console.WriteLine("\nThe function return Type is : " + m.ReturnType);
                //Checking if methods are static
                Console.WriteLine("\nMethod is Static : " + m.IsStatic);
                //Printing Parameter names    
                Console.WriteLine("\nIs Return Parameter name is : " + m.ReturnParameter.Name);
                //Printing Parametre types    
                Console.WriteLine("\nThe Parameter type is: " + m.ReturnParameter.ParameterType);

            }

            
        }
    }
}
