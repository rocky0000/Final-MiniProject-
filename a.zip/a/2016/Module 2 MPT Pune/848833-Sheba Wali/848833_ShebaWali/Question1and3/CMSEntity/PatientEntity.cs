﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMSEntity
{

    /// <summary>
    /// Employee ID:848833 
    /// Employee NAME:Sheba Wali
    /// Description:This is Entiy class for Patient
    /// Date of Creation:19/09/2016
    /// </summary>

    [Serializable]
    public class PatientEntity
    {
        //Property for Set Patient ID. 
        public int PatientID { get; set; }

        //Property for Get or Set Patient Nmae
        public string PatientName { get; set; }

        //Property for Get or Set Patient PhoneNo.
        public string PhoneNo { get; set; }

        //Property for Get or Set Patient Age
        public int Age { get; set; }


    }
}
