﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMSEntity; //Reference to Patient Entity
using CMSException; //Reference to Patient Exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace CMS_DAL
{
    /// <summary>
    /// Employee ID:848833 
    /// Employee NAME:Sheba Wali
    /// Description:This is DAL class for Patient
    /// Date of Creation:19/09/2016
    /// </summary>
    public class PatientDAL
    {
        static List<PatientEntity> PatientList = new List<PatientEntity>();
        //Count for id autogeneration
        public static int count = 100;

        //Function to ADD new Patient to the list of Patient
        public static bool AddPatient(PatientEntity newPatient)
        {

            bool PatientAdded = false;

            try
            {
                newPatient.PatientID = count;

                //Adding Patient
                PatientList.Add(newPatient);
                PatientAdded = true;
                count++;

            }

            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            { throw ex; }

            return PatientAdded;
        }



        //Function for searching the Patient

        public static PatientEntity SearchPatient(int patientID)
        {
            PatientEntity PatientSearched = null;

            try
            {
                //Searching the Patient
                PatientSearched = PatientList.Find(patient => patient.PatientID == patientID);
            }

            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return PatientSearched;
        }


        // Function for patient serialization 
        public static bool SerializePatient()
        {
            bool patientSerialized = false;
            try
            {
                if (PatientList.Count > 0)
                {
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binFormat = new BinaryFormatter();
                    binFormat.Serialize(fs, PatientList);
                    patientSerialized = true;
                    fs.Flush();
                    fs.Close();
                }
                else
                    throw new PatientException("No Patient data so cannot serialize!");
            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialized;

        }

        //Function for patient Deserialization 
        public static List<PatientEntity> DeserializePatient()
        {
            List<PatientEntity> desPatient = null;
            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormat = new BinaryFormatter();

                desPatient = (List<PatientEntity>)binFormat.Deserialize(fs);
                fs.Flush();
                fs.Close();

            }
            catch (PatientException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
            return desPatient;
        }
    }
}
