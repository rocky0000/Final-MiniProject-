﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using CMSEntity;
using CMSException;
using CMS_DAL;


namespace CMS_BL
{
    /// <summary>
    /// Employee ID:848833 
    /// Employee NAME:Sheba Wali
    /// Description:This is BL for Patient
    /// Date of Creation:19/09/2016
    /// </summary>
    public class PatientBL
    {
        //function to validate Patient data
        public static bool ValidatePatient(PatientEntity patient)
        {
            bool validPatient = true;
            StringBuilder msg = new StringBuilder();
            try
            {

                //validate patient name 
                if (!Regex.IsMatch(patient.PatientName, "[a-z]+"))
                {
                    msg.Append("\nPatient name should have alphabets.\n");
                    validPatient = false;
                }

                //validate phone number
                if (!Regex.IsMatch(patient.PhoneNo, "[1-9][0-9]{9}"))
                {
                    msg.Append("\nPhone no. can not start from 0 and must have 10 digits");
                    validPatient = false;
                }

                //validate age
                if (patient.Age < 0 || patient.Age > 100)
                {
                    msg.Append("\nAge should be less 100 years and cannot be negative .");
                    validPatient = false;
                }

                if (validPatient == false)
                    throw new PatientException(msg.ToString());

            }

            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validPatient;
        }

        //Only Add if all details are valid
        public static bool AddPatient(PatientEntity newPatient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPatient))
                {
                    patientAdded = PatientDAL.AddPatient(newPatient);

                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient..");
                }
            }


            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientAdded;
        }


        //Search only if valid id has been entered

        public static PatientEntity SearchPatient(int patientID)
        {
            PatientEntity patientSearched = null;
            try
            {
                patientSearched = PatientDAL.SearchPatient(patientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSearched;

        }


        //to serialize patient list only if list exists
        public static bool SerializePatient()
        {
            bool patientSerialize = false;
            try
            {
                patientSerialize = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientSerialize;
        }

        //to deserilaize patient list only if list exists
        public static List<PatientEntity> DeserializePatient()
        {
            List<PatientEntity> patientList = null;
            try
            {
                patientList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patientList;
        }
    }
}

