﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace TestReflection
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("Tests.dll");
            Type testType = myAssembly.GetType("Tests.Test");
            MethodInfo[] testMethods = testType.GetMethods();
            //getting metadata about the DoWork method
            foreach (MethodInfo m in testMethods)
            {
                Console.WriteLine("Method Name : " + m.Name);
                Console.WriteLine("Return type : " + m.ReturnType);
                Console.WriteLine("Static : " + m.IsStatic);
                Console.WriteLine("Parameter Names :" + m.GetParameters());
                Console.WriteLine("Parameter types :" + m.ReturnParameter);
                Console.WriteLine();
            }
            //calling the dowork method
            Console.WriteLine("Now calling the DoWork method");
            object calcObj=myAssembly.CreateInstance("Tests.Test");
            MethodInfo dwobj = testType.GetMethod("DoWork");
            int result = (int)dwobj.Invoke(calcObj,new object[]{3});
            Console.WriteLine("Square of number ="+ result);

            Console.ReadKey();
        }
    }
}
