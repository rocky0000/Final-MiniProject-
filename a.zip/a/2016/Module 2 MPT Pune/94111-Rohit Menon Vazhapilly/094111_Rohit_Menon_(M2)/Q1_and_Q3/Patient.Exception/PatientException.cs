﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patient.Exception
{
    /// <summary>
    /// Employee ID :094111
    /// Employee Name :Rohit Menon
    /// Description : This is the exception class for patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientException:ApplicationException
    {
        public PatientException()
            : base()
        { }

        public PatientException(string msg)
            : base(msg)
        { }
    }
}
