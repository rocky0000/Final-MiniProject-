﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Patient.Entity;   //Reference to Patient Entity
using Patient.Exception; //Reference to Patient Exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Patient.DAL
{
    /// <summary>
    /// Employee ID :094111
    /// Employee Name :Rohit Menon
    /// Description : This is the Data access layer for patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientDAL
    {
        static List<PatientDetails> patList=new List<PatientDetails>();
        //function to add patient details
        public static bool AddPatient(PatientDetails newPat)
        {
            bool patAdded = false;

            try 
            {
                //Adding patient
                patList.Add(newPat);
                patAdded = true;

            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patAdded;
        }
        //function to search patient
        public static PatientDetails SearchPatient(int patID)
        {
            PatientDetails patSearched = null;

            try 
            { 
                //Searching patient
                patSearched=patList.Find((pat => pat.PatientID == patID));
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patSearched;
        }

        //function to serialize patient class(question 3)
        public static bool SerializePatient()
        {
            bool patSerialized = false;

            try 
            {
                if (patList.Count > 0)
                {
                    //Serializing patient class
                    FileStream fs = new FileStream("Patient.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter binFormat = new BinaryFormatter();
                    binFormat.Serialize(fs, patList);
                    patSerialized = true;
                    fs.Close();
                }
                else
                    throw new PatientException("No employee data so cannot serialize");
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patSerialized;
        }

        //function to deserialize patient class
        public static List<PatientDetails> DeserializePatient()
        {
            List<PatientDetails> desPat = null;
            try
            {
                FileStream fs = new FileStream("Patient.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormat = new BinaryFormatter();
                desPat = (List<PatientDetails>)binFormat.Deserialize(fs);
                fs.Close();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desPat;
        }

    }
}
