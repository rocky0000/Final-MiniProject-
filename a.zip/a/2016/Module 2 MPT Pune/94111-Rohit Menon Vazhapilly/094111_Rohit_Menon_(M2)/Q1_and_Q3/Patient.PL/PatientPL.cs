﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Patient.Entity;//Reference to patient entity
using Patient.Exception;//Reference to patient exception
using Patient.BL;//reference to business layer of patient

namespace Patient.PL
{
    /// <summary>
    /// Employee ID :094111
    /// Employee Name :Rohit Menon
    /// Description : This is the Presentation layer for patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    class PatientPL
    {
        static int count = 101;
        //function to add patient in presentation layer
        public static void AddPatient()
        {
            PatientDetails pat=new PatientDetails();

            try
            {
                pat.PatientID = count; //autogeneration of patient id
                Console.Write("Enter Employee Name : ");
                pat.PatientName = Console.ReadLine();
                Console.Write("Enter Phone No : ");
                pat.PhoneNo = Console.ReadLine();
                Console.Write("Enter Age : ");
                pat.Age = Convert.ToInt32(Console.ReadLine());
                

                bool patAdded = PatientBL.AddPatient(pat);

                if (patAdded)
                {
                    Console.WriteLine("Patient Added Successfully");
                    count++;
                }
                else
                    throw new PatientException("Patient not Added");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //function to search patient in presentation layer
        public static void SearchPatient()
        {
            try
            {
                int patID;
                Console.Write("Enter Patient ID for patient which you would like to Search(patient id start from 101) : ");
                patID = Convert.ToInt32(Console.ReadLine());

                PatientDetails pat = PatientBL.SearchPatient(patID);

                if (pat != null)
                {
                    Console.WriteLine("Patient ID : " + pat.PatientID);
                    Console.WriteLine("Patient Name : " + pat.PatientName);
                    Console.WriteLine("Phone Number : " + pat.PhoneNo);
                    Console.WriteLine("Age : " + pat.Age);
                    
                }
                else
                    throw new PatientException("Patient not found with patient ID : " + patID);
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //function to serialize patient
        public static void SerializePatient()
        {
            try
            {
                bool patSerialized = PatientBL.SerializePatient();
                if (patSerialized)
                    Console.WriteLine("Patient data is serialized");
                else
                    throw new PatientException("Patient Data is not Serialized");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //function to deserialize patient
        public static void DeserializePatient()
        {
            try
            {
                List<PatientDetails> patList =PatientBL.DeserializePatient();

                if (patList != null)
                {
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("Patient ID \t Patient Name \t\t Phone No \t\t Age");
                    Console.WriteLine("************************************************************************************");
                    foreach (PatientDetails pat in patList)
                    {
                        Console.WriteLine(pat.PatientID+ "\t\t\t" + pat.PatientName + "\t\t" + pat.PhoneNo + "\t\t" + pat.Age );
                    }
                }
                else
                    throw new PatientException("There is no data");
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //function to print the menu
        public static void PrintMenu()
        {
            Console.WriteLine("\n************************");
            Console.WriteLine("1. Add Patient");
            Console.WriteLine("2. Search Patient");
            Console.WriteLine("3. Serialize Patient");
            Console.WriteLine("4. Deserialize Patient");
            Console.WriteLine("5. Exit");
            Console.WriteLine("************************");
        }

        static void Main(string[] args)
        {
            int choice = 0;//to take user's choice

            try
            {
                do
                {
                    PrintMenu();

                    Console.Write("\nEnter Your Choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: AddPatient();
                            break;
                        case 2: SearchPatient();
                            break;
                        case 3: SerializePatient();
                            break;
                        case 4: DeserializePatient();
                            break;
                        case 5: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("Please provide valid choice");
                            break;
                    }
                } while (choice != 5);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
