﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patient.Entity
{
    /// <summary>
    /// Employee ID :094111
    /// Employee Name :Rohit Menon
    /// Description : This is the entity class for patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    [Serializable]
    public class PatientDetails
    {
        //Property to get and set patient id
        public int PatientID { get; set; }
        //Property to get and set patient name
        public string PatientName { get; set; }
        //property to get and set phone number
        public string PhoneNo { get; set; }
        //property to get and set age of patient
        public int Age { get; set; }
    }
}
