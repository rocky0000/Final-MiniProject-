﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Patient.Entity; //Reference to patient entity
using Patient.Exception;//Reference to patient exception
using Patient.DAL;//Reference to data access layer of patient

namespace Patient.BL
{
    /// <summary>
    /// Employee ID :094111
    /// Employee Name :Rohit Menon
    /// Description : This is the Business layer for patient
    /// Date of Creation : 19/09/2016
    /// </summary>
    public class PatientBL
    {
        //function to validate the properties of patient
        public static bool ValidatePatient(PatientDetails pat)
        {
            bool validPat = true;
            StringBuilder msg = new StringBuilder();

            try 
            {
                if (!Regex.IsMatch(pat.PatientName, "[A-Z][a-z ]+"))
                {
                    msg.Append("Patient Name should have alphabets and spaces only and it should start with capital letter\n");
                    validPat = false;
                }
                if (!Regex.IsMatch(pat.PhoneNo, "[1-9][0-9]{9}"))
                {
                    msg.Append("Phone No should have 10 digits and it should not start with 0\n");
                    validPat = false;
                }
                if (pat.Age <= 0 || pat.Age > 100)
                {
                    msg.Append("Patient Age cannot be negative or cannot be greater than 100\n");
                    validPat = false;
                }
                if (validPat == false)
                    throw new PatientException(msg.ToString());
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validPat;
        }
        //function to add patient in business layer
        public static bool AddPatient(PatientDetails newPat)
        {
            bool patAdded = false;
            try
            {
                if (ValidatePatient(newPat))
                {
                    patAdded = PatientDAL.AddPatient(newPat);
                }
                else
                {
                    throw new PatientException("Please provide valid data for Patient");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return patAdded;
        }
        //function to search patient in business layer
        public static PatientDetails SearchPatient(int patID)
        {
            PatientDetails patSearched = null;

            try
            {
                patSearched = PatientDAL.SearchPatient(patID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patSearched;
        }

        public static bool SerializePatient()
        {
            bool patSerialized = false;

            try
            {
                patSerialized = PatientDAL.SerializePatient();
            }
            catch (PatientException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            return patSerialized;
        }

        public static List<PatientDetails> DeserializePatient()
        {
            List<PatientDetails> patList = null;

            try
            {
                patList = PatientDAL.DeserializePatient();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return patList;
        }
    }
}
